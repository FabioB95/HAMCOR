"""
quickstart.py — HAMCOR in five minutes, no X-ray software needed.

1. builds the coronal and disc grids and the forward model (photon transfer);
2. creates a synthetic corona and its lag-frequency spectrum, passed through the same
   cross-spectral estimator used for real data, with noise;
3. recovers the corona by minimising the Hamiltonian (multi-start projected gradient);
4. compares truth and recovery, counts the constrained parameters (Fisher N_eff);
5. fits a lamppost to the same data and compares the two with the AIC.

Usage:
    python examples/quickstart.py                       # weak-field transfer, ~1-2 min
    python examples/quickstart.py --metric schwarzschild  # exact ray tracing (first run
                                                          #  builds a cache, ~10-20 min)
"""
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
os.environ.setdefault("HAMCOR_WORK", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_work"))

from hamcor2 import build_grid, build_disc_grid, ForwardModel, PointSourceModel, OptConfig   # noqa: E402
from hamcor2.fitting import fit                                                              # noqa: E402
from hamcor2.metrics import recovery_metrics, fisher_spectrum                                # noqa: E402
from hamcor2.synthetic import compact, column, ring, make_observables                        # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--metric", default="weakfield", choices=["flat", "weakfield", "schwarzschild"])
ap.add_argument("--geometry", default="column", choices=["compact", "column", "ring"])
ap.add_argument("--incl", type=float, default=45.0)
ap.add_argument("--starts", type=int, default=8)
args = ap.parse_args()

# 1. grids (lengths in r_g = GM/c^2) and forward model ------------------------------------
grid = build_grid(r_in=3.0, r_out=30.0, z_min=0.1, z_max=20.0)     # 10 x 10 x 8 cells
disc = build_disc_grid(r_in=6.0, r_out=100.0)                     # disc from the ISCO (a=0)
fm = ForwardModel(grid, disc, args.incl, args.metric)
print(f"grid: {grid.n_cells} cells, disc: {disc.n_elements} elements, metric: {args.metric}")

# 2. synthetic truth and data --------------------------------------------------------------
w_true = {"compact": lambda: compact(grid, height=3.0, width=2.0),
          "column": lambda: column(grid, z_min=1.0, z_max=5.0, radius=5.0),
          "ring": lambda: ring(grid, R_center=8.0, z_center=3.0)}[args.geometry]()
nu_edges = np.geomspace(2e-3, 6e-2, 6)          # dimensionless frequencies nu * t_g, 5 bins
obs = make_observables(fm, w_true, nu_edges, R_s=0.6, R_h=0.15, noise_seed=1)
print("synthetic lags [r_g/c]:", np.round(obs.tau, 2), "+/-", np.round(obs.sig_tau, 2))
print(f"illumination fraction I = {obs.I_obs:.3f} +/- {obs.sig_I}")

# 3. HAMCOR fit ----------------------------------------------------------------------------
w_rec, diag, _, _ = fit(fm, obs, J=1.0, n_starts=args.starts, cfg=OptConfig(n_iter=2000))
print(f"fit: chi2_lag = {diag['chi2_lag']:.2f} for {diag['n_lag']} bins, "
      f"chi2_I = {diag.get('chi2_I') or 0:.2f}")

# 4. recovery and information content -------------------------------------------------------
m = recovery_metrics(grid, w_true, w_rec)
print(f"centroid true (R, z) = ({m['R_c_true']:.1f}, {m['z_c_true']:.1f}) r_g, "
      f"recovered ({m['R_c_rec']:.1f}, {m['z_c_rec']:.1f}) r_g, offset {m['d_centroid']:.1f} r_g")
print(f"map correlation rho_3D = {m['rho_3d']:.2f}, rho_RZ = {m['rho_rz']:.2f}")
_, dtau = fm.lag_model_binned(w_rec, obs.nu_k, obs.p_k, obs.bin_k, obs.nu, obs.R_s, obs.R_h, grad=True)
J = np.vstack([dtau.T, fm.illumination_grad(w_rec)[None]])
fs = fisher_spectrum(J, np.r_[obs.sigma_total(), obs.sig_I])
print(f"constrained parameters N_eff = {fs['N_eff']:.1f} (of {grid.n_cells - 1})")

# 5. lamppost comparison --------------------------------------------------------------------
if args.metric != "flat":
    lp = PointSourceModel(disc, args.incl, args.metric)
    H = np.geomspace(2.5, 40.0, 40)
    lp.prepare(H)
    best = None
    sig = obs.sigma_total()
    for h in H:
        W, L = lp.row(h)
        pt = (W[None] * np.exp(-2j * np.pi * obs.nu_k[:, None] * L[None])).sum(1) / W.sum()
        Zk = obs.p_k * np.conj(1 + obs.R_h * pt) * (1 + obs.R_s * pt)
        Z = np.bincount(obs.bin_k, weights=Zk.real) + 1j * np.bincount(obs.bin_k, weights=Zk.imag)
        tau = np.angle(Z) / (2 * np.pi * obs.nu)
        c = np.sum(((tau - obs.tau) / sig) ** 2) + ((lp.illumination(h) - obs.I_obs) / obs.sig_I) ** 2
        if best is None or c < best[1]:
            best = (h, c)
    chi_h = diag["chi2_lag"] + (diag.get("chi2_I") or 0.0)
    dAIC = (best[1] + 2) - (chi_h + 2 * fs["N_eff"])
    print(f"lamppost: best h = {best[0]:.1f} r_g, chi2 = {best[1]:.2f};  "
          f"Delta AIC = {dAIC:+.1f} (positive favours HAMCOR)")
