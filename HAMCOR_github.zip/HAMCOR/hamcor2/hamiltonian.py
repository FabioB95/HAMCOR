"""
hamiltonian.py — HAMCOR Hamiltonian (v2) and analytic gradient.

  H(w) = H_mag + s(t) [ H_lag + H_rad ]          (pair / energy barriers inactive:
                                                   gamma=1, l_crit=1000 never binds)

  H_mag = (J/2) kappa sum_<ij> | w_i n_i - w_j n_j |^2
        = (J/2) kappa sum_<ij> [ w_i^2 + w_j^2 - 2 w_i w_j (n_i . n_j) ]
          i.e. the nearest-neighbour coupling -J sum w_i w_j (n_i.n_j) of the submitted
          version plus the on-site self-energy that makes the term positive
          semi-definite (bounded below). kappa = N^2 / N_p (N_p = number of pairs)
          makes H_mag = O(J) for O(1) relative cell-to-cell fluctuations.
          Without polarimetry the orientation sub-problem has the aligned ground
          state n_i = z_hat, and H_mag reduces to the Dirichlet energy
          (J/2) kappa sum_<ij> (w_i - w_j)^2: a Gaussian-Markov-random-field
          (Laplacian) smoothness prior. The bare coupling alone is unbounded towards
          two-cell clumps (verified numerically) and is not used.

  Data terms are chi^2 / 2, so that with alpha = beta = 1, H_lag + H_rad is the
  negative log-likelihood and H is a MAP objective with H_mag as the prior.

  mode = "lagfreq" (default):
     H_lag = (alpha/2) sum_j [ (tau_mod(nu_j) - tau_obs,j) / sigma_j ]^2
  mode = "meanlag" (ablation, low-frequency limit only):
     H_lag = (alpha/2) [ (-D <t> - tau_obs) / sigma ]^2
  mode = "psi" (legacy prior of the submitted version, for robustness tests):
     H_lag = alpha sum_b [psi_pred(t_b) - psi_prior(t_b)]^2       (+ overflow bin)

  H_rad = (beta/2) [ (I(w) - I_obs) / sigma_I ]^2

  sigma_j^2 = sigma_tau,j^2 + (tau_obs,j * sigma_D / D)^2   (dilution uncertainty)

  Continuum (hard) lag, cont_lag=True:
     tau_mod(nu) = tau_rev(nu) + A (nu/nu_0)^(-a),   A >= 0,  a in {0, 0.5, 1, 1.5, 2}
  the intrinsic propagation lag of the continuum (Kotov+2001; Arevalo & Uttley 2006),
  which dominates at low frequency in low-flux states.  (A, a) are nuisance parameters
  profiled out analytically at every evaluation (non-negative weighted least squares in
  A for each a, minimum over a); by the envelope theorem the gradient in w is that at the
  optimal (A, a).  nu_0 = geometric mean of the fitted frequencies.  Two extra
  parameters are counted in the degrees of freedom.
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field

from .forward import ForwardModel

CONT_INDICES = (0.0, 0.5, 1.0, 1.5, 2.0)


def profile_continuum(tau_rev, tau_obs, sig, nu, indices=CONT_INDICES):
    """Best non-negative continuum lag A (nu/nu0)^-a added to tau_rev.

    Returns (A, a, tau_c) minimising sum ((tau_rev + tau_c - tau_obs)/sig)^2."""
    nu0 = float(np.exp(np.mean(np.log(nu))))
    wts = 1.0 / sig ** 2
    best = (np.inf, 0.0, 0.0, np.zeros_like(tau_rev))
    d = tau_obs - tau_rev
    for a in indices:
        b = (nu / nu0) ** (-a)
        A = max(0.0, float(np.sum(wts * b * d) / np.sum(wts * b * b)))
        c = float(np.sum(wts * (d - A * b) ** 2))
        if c < best[0]:
            best = (c, A, a, A * b)
    return best[1], best[2], best[3]


@dataclass
class ObsTargets:
    nu: np.ndarray = None            # (N_f,)  bin-mean dimensionless frequency f*GM/c^3
    nu_k: np.ndarray = None          # Fourier frequencies inside the bins (dimensionless)
    p_k: np.ndarray = None           # reference power at nu_k (estimator weights)
    bin_k: np.ndarray = None         # bin index of each nu_k
    tau: np.ndarray = None           # (N_f,)  soft-hard lag [r_g/c], negative = soft lags
    sig_tau: np.ndarray = None       # (N_f,)
    R_s: float = 0.0                 # refl/cont count ratio, soft band
    R_h: float = 0.0                 # refl/cont count ratio, hard band
    sig_D_frac: float = 0.0          # fractional uncertainty on D
    cont_lag: bool = False           # add a profiled continuum (hard) lag A (nu/nu0)^-a
    I_obs: float = None
    sig_I: float = None
    # legacy psi-prior mode
    psi_prior: np.ndarray = None     # (N_b + 1,) incl. overflow
    psi_edges: np.ndarray = None     # (N_b + 1,)
    meta: dict = field(default_factory=dict)

    @property
    def D(self):
        return self.R_s / (1 + self.R_s) - self.R_h / (1 + self.R_h)

    def sigma_total(self):
        return np.sqrt(self.sig_tau ** 2 + (self.tau * self.sig_D_frac) ** 2)


class Hamiltonian:
    def __init__(self, fm: ForwardModel, obs: ObsTargets, J=1.0, alpha=1.0, beta=1.0,
                 mode="lagfreq", use_rad=True):
        self.fm, self.obs, self.mode, self.use_rad = fm, obs, mode, use_rad
        self.J, self.alpha, self.beta = J, alpha, beta
        g = fm.grid
        self.pairs = g.pairs
        self.mag_pref = g.n_cells ** 2 / len(g.pairs)
        self._B = None
        if mode == "lagfreq" and obs.nu_k is not None:
            self._B = fm.bin_matrix(obs.bin_k, len(obs.nu))
        self.scale = 1.0                                    # continuation factor
        if mode == "lagfreq":
            self.sig = obs.sigma_total()
            fm.G(obs.nu_k if obs.nu_k is not None else obs.nu)   # precompute
        elif mode == "meanlag":
            self.sig = float(obs.sigma_total()[0])
        elif mode == "psi":
            self.A = fm.psi_binned_matrix(obs.psi_edges)
        else:
            raise ValueError(mode)

    # ── terms ───────────────────────────────────────────────────────────────
    def _mag(self, w, grad):
        if self.J == 0:
            return 0.0, (np.zeros_like(w) if grad else None)
        i, j = self.pairs[:, 0], self.pairs[:, 1]
        d = w[i] - w[j]
        c = self.J * self.mag_pref
        H = 0.5 * c * np.sum(d * d)
        if not grad:
            return H, None
        g = np.zeros_like(w)
        np.add.at(g, i, d)
        np.add.at(g, j, -d)
        return H, c * g

    def _lag(self, w, grad):
        o, fm = self.obs, self.fm
        if self.mode == "lagfreq":
            if o.nu_k is not None:
                out = fm.lag_model_binned(w, o.nu_k, o.p_k, o.bin_k, o.nu, o.R_s, o.R_h,
                                          grad=grad, B=self._B)
            else:
                out = fm.lag_model(w, o.nu, o.R_s, o.R_h, grad=grad)
            tau, dtau = (out if grad else (out, None))
            self.tau_rev = tau
            if o.cont_lag:
                self.cont_A, self.cont_a, tc = profile_continuum(tau, o.tau, self.sig, o.nu)
                tau = tau + tc
            r = (tau - o.tau) / self.sig
            H = 0.5 * self.alpha * np.sum(r * r)
            return H, (self.alpha * dtau @ (r / self.sig) if grad else None), tau
        if self.mode == "meanlag":
            m = -o.D * fm.mean_lag(w)
            r = (m - o.tau[0]) / self.sig
            H = 0.5 * self.alpha * r * r
            g = self.alpha * r / self.sig * (-o.D) * fm.mean_lag_grad(w) if grad else None
            return H, g, np.array([m])
        # legacy psi
        Q = float(w @ fm.a)
        psi = (w @ self.A) / Q
        res = psi - o.psi_prior
        H = self.alpha * np.sum(res * res)
        g = None
        if grad:
            dpsi = (self.A - fm.a[:, None] * psi[None, :]) / Q
            g = 2 * self.alpha * dpsi @ res
        return H, g, psi

    def _rad(self, w, grad):
        if not self.use_rad or self.obs.I_obs is None:
            return 0.0, (np.zeros_like(w) if grad else None), None
        I = self.fm.illumination(w)
        if self.mode == "psi":                              # legacy form
            r = I - self.obs.I_obs
            return self.beta * r * r, (2 * self.beta * r * self.fm.illumination_grad(w)
                                       if grad else None), I
        r = (I - self.obs.I_obs) / self.obs.sig_I
        H = 0.5 * self.beta * r * r
        return H, (self.beta * r / self.obs.sig_I * self.fm.illumination_grad(w)
                   if grad else None), I

    # ── public ──────────────────────────────────────────────────────────────
    def _mask(self, w):
        """Cells where no static emitter exists (Kerr ergosphere): linear barrier."""
        inv = getattr(self.fm, "invalid", None)
        if inv is None or not inv.any():
            return 0.0, 0.0
        g = np.where(inv, 1e3, 0.0)
        return float(g @ w), g

    def _le(self, w, grad):
        """Optional lag-energy term (obs.meta['le_term'], energy.LagEnergyTerm)."""
        t = self.obs.meta.get("le_term") if self.obs.meta else None
        if t is None:
            return 0.0, (np.zeros_like(w) if grad else None), None
        ch, g, model = t.chi2(w, grad)
        return 0.5 * ch, (0.5 * g if grad else None), model

    def value(self, w):
        return self._mag(w, False)[0] + self._mask(w)[0] + self.scale * (
            self._lag(w, False)[0] + self._rad(w, False)[0] + self._le(w, False)[0])

    def value_and_grad(self, w):
        Hm, gm = self._mag(w, True)
        Hl, gl, _ = self._lag(w, True)
        Hr, gr, _ = self._rad(w, True)
        Hk, gk = self._mask(w)
        He, ge, _ = self._le(w, True)
        return Hm + Hk + self.scale * (Hl + Hr + He), gm + gk + self.scale * (gl + gr + ge)

    def diagnostics(self, w) -> dict:
        s0, self.scale = self.scale, 1.0
        Hm, _ = self._mag(w, False)
        Hl, _, model = self._lag(w, False)
        Hr, _, I = self._rad(w, False)
        He, _, le_model = self._le(w, False)
        self.scale = s0
        g = self.fm.grid
        d = dict(H_total=Hm + Hl + Hr, H_mag=Hm, H_lag=Hl, H_rad=Hr,
                 I_pred=(I if I is not None else self.fm.illumination(w)),
                 mean_lag=self.fm.mean_lag(w),
                 R_c=float(w @ g.R), z_c=float(w @ g.z),
                 r_c=float(w @ np.sqrt(g.R ** 2 + g.z ** 2)))
        if self.mode in ("lagfreq", "meanlag"):
            d["tau_model"] = model
            d["chi2_lag"] = 2 * Hl / self.alpha
            d["n_lag"] = int(np.size(model))
            if self.mode == "lagfreq":
                d["tau_rev"] = self.tau_rev
                d["cont_lag"] = bool(self.obs.cont_lag)
                if self.obs.cont_lag:
                    d["cont_A"], d["cont_index"] = float(self.cont_A), float(self.cont_a)
                    d["cont_nu0"] = float(np.exp(np.mean(np.log(self.obs.nu))))
                d["n_par_nuisance"] = 2 if self.obs.cont_lag else 0
        else:
            d["psi_pred"] = model
        if I is not None and self.mode != "psi":
            d["chi2_I"] = 2 * Hr / self.beta
        if le_model is not None:
            d["chi2_le"] = 2 * He
            d["n_le"] = self.obs.meta["le_term"].n
            d["le_model"] = le_model
        return d
