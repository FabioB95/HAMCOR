"""config.py — source configuration and file layout."""
from __future__ import annotations

import copy
import json
import os
import yaml
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CONFIG = os.path.join(ROOT, "config", "sources.yaml")
WORK = os.environ.get("HAMCOR_WORK", ROOT)        # data/ and results/ live here


_KEEP_STR = {"obsid", "name", "model", "pexrav_model", "mode", "key"}


def _num(x, key=None):
    """PyYAML (YAML 1.1) reads '1.3e7' as a string: coerce numeric strings,
    except for identifier fields (ObsIDs keep their leading zeros)."""
    if key in _KEEP_STR:
        return x
    if isinstance(x, dict):
        return {k: _num(v, k) for k, v in x.items()}
    if isinstance(x, list):
        return [_num(v) for v in x]
    if isinstance(x, str):
        try:
            return float(x)
        except ValueError:
            return x
    return x


def load(path=CONFIG):
    with open(path) as f:
        cfg = _num(yaml.safe_load(f))
    out = {}
    for key, src in cfg["sources"].items():
        d = copy.deepcopy(cfg["defaults"])
        for k, v in src.items():
            if isinstance(v, dict) and isinstance(d.get(k), dict):
                d[k].update(v)
            else:
                d[k] = v
        d["key"] = key
        d.setdefault("mode", "imaging")
        out[key] = d
    return out


def data_dir(key):
    p = os.path.join(WORK, "data", key)
    os.makedirs(p, exist_ok=True)
    return p


def results_dir(*sub):
    p = os.path.join(WORK, "results", *sub)
    os.makedirs(p, exist_ok=True)
    return p


class NpEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        if isinstance(o, np.bool_):
            return bool(o)
        return super().default(o)


def dump_json(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, cls=NpEncoder)
    return path


def load_json(path):
    with open(path) as f:
        return json.load(f)
