"""io.py — build HAMCOR targets (dimensionless) from the measured products."""
from __future__ import annotations

import os
import numpy as np

from . import config as C
from .forward import t_g
from .hamiltonian import ObsTargets


def build_obs(src, M_bh=None) -> dict:
    """Combine lagfreq.json + spectral.json into dimensionless targets (r_g/c units)."""
    key = src["key"]
    lf = C.load_json(os.path.join(C.data_dir(key), "lagfreq.json"))
    sp = C.load_json(os.path.join(C.data_dir(key), "spectral.json"))
    M = M_bh or src["M_bh"]
    tg = t_g(M)
    fit = lf["fit"]
    good = np.isfinite(np.array(fit["tau"], float))
    keep_bins = np.where(good)[0]
    remap = {j: i for i, j in enumerate(keep_bins)}
    bk = np.array(fit["bin_k"], int)
    mk = np.isin(bk, keep_bins)
    le = lf["lag_energy"]
    return dict(
        key=key, name=src["name"], M_bh=M, t_g=tg, incl=src["incl"],
        nu=np.array(fit["f"])[good] * tg,
        f=np.array(fit["f"])[good],
        nu_k=np.array(fit["fk"])[mk] * tg, p_k=np.array(fit["pk"])[mk],
        bin_k=np.array([remap[b] for b in bk[mk]]),
        tau=np.array(fit["tau"])[good] / tg, sig_tau=np.array(fit["sig_tau"])[good] / tg,
        tau_s=np.array(fit["tau"])[good], sig_tau_s=np.array(fit["sig_tau"])[good],
        band_tau_s=lf["band"]["tau"][0], band_sig_s=lf["band"]["sig_tau"][0],
        R_s=sp["R_s"], R_h=sp["R_h"], D=sp["D"],
        # statistical + spin (spectral fit) and emissivity-model systematic (config, absolute)
        sig_D_frac=float(np.hypot(sp["sig_D_frac"], float(src.get("D_emiss_sys", 0.0)) / abs(sp["D"]))),
        I_obs=sp["I_obs"], sig_I=sp["sig_I"], refl_frac=sp["refl_frac"],
        le_E_lo=le["E_lo"], le_E_hi=le["E_hi"],
        le_lag=np.array(le["lag"]) / tg, le_sig=np.array(le["sig"]) / tg,
        le_nu=np.array(le["freqs"]) * tg, le_w=np.array(le["weights"]),
        le_f_mean_nu=le["f_mean"] * tg, R_E=sp["R_E"], R_ref=sp["R_ref"],
        cont_lag=bool(src.get("continuum_lag", True)),
    )


def targets(ob: dict, use_rad=True) -> ObsTargets:
    return ObsTargets(nu=ob["nu"], nu_k=ob["nu_k"], p_k=ob["p_k"], bin_k=ob["bin_k"],
                      tau=ob["tau"], sig_tau=ob["sig_tau"], R_s=ob["R_s"], R_h=ob["R_h"],
                      sig_D_frac=ob["sig_D_frac"], cont_lag=ob.get("cont_lag", False),
                      I_obs=ob["I_obs"] if use_rad else None, sig_I=ob["sig_I"],
                      meta=dict(key=ob["key"]))


def load_obs(key, M_bh=None):
    src = C.load()[key]
    return src, build_obs(src, M_bh)
