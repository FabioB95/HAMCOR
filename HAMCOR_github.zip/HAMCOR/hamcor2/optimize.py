"""
optimize.py — projected gradient descent on the probability simplex.

  w^{t+1} = Pi_Delta( w^t - eta_t grad H(w^t) )

Pi_Delta: Euclidean projection onto the simplex (Duchi et al. 2008), followed by a
floor w_i >= w_min and renormalisation. eta_t: Armijo rule along the projection
arc (Bertsekas 1999, sect. 2.3):  H(w+) <= H(w) + c1 grad H . (w+ - w).
Continuation: data couplings ramp linearly from 1% to 100% over n_cont steps.
"""
from __future__ import annotations

import os
import numpy as np
from dataclasses import dataclass, field
from concurrent.futures import ProcessPoolExecutor


def project_simplex(v: np.ndarray, w_min: float = 1e-12) -> np.ndarray:
    u = np.sort(v)[::-1]
    css = np.cumsum(u) - 1.0
    k = np.arange(1, v.size + 1)
    rho = np.nonzero(u - css / k > 0)[0][-1]
    w = np.maximum(v - css[rho] / (rho + 1.0), 0.0)
    w = np.maximum(w, w_min)
    return w / w.sum()


@dataclass
class OptConfig:
    n_iter: int = 3000
    n_cont: int = 300
    eta0: float = 1e-3
    eta_max: float = 1e2
    c1: float = 1e-4
    shrink: float = 0.5
    max_backtrack: int = 40
    tol: float = 1e-10
    w_min: float = 1e-12
    log_every: int = 0


@dataclass
class OptResult:
    w: np.ndarray
    H: float
    n_iter: int
    converged: bool
    history: np.ndarray = field(default=None)
    seed: int = -1


def pgd(H, w0: np.ndarray, cfg: OptConfig = OptConfig()) -> OptResult:
    w = project_simplex(w0, cfg.w_min)
    eta = cfg.eta0
    hist = []
    conv = False
    for t in range(cfg.n_iter):
        H.scale = 1.0 if t >= cfg.n_cont else 0.01 + 0.99 * t / cfg.n_cont
        f, g = H.value_and_grad(w)
        eta = min(eta * 2.0, cfg.eta_max)
        for _ in range(cfg.max_backtrack):
            w_new = project_simplex(w - eta * g, cfg.w_min)
            f_new = H.value(w_new)
            if f_new <= f + cfg.c1 * g @ (w_new - w):
                break
            eta *= cfg.shrink
        dw = np.abs(w_new - w).sum()
        w = w_new
        hist.append(f_new)
        if cfg.log_every and t % cfg.log_every == 0:
            print(f"  it {t:5d}  H={f_new:.6g}  eta={eta:.2e}  |dw|={dw:.2e}")
        if t > cfg.n_cont and abs(f - f_new) < cfg.tol * max(1.0, abs(f)) and dw < 1e-9:
            conv = True
            break
    H.scale = 1.0
    return OptResult(w, H.value(w), t + 1, conv, np.array(hist))


# ── multistart (process pool; Linux/WSL fork) ─────────────────────────────────
_H = None
_CFG = None


def _init(H, cfg):
    global _H, _CFG
    _H, _CFG = H, cfg
    try:                                   # one BLAS thread per worker
        from threadpoolctl import threadpool_limits
        threadpool_limits(1)
    except ImportError:
        pass


def _run(seed):
    if isinstance(seed, np.ndarray):           # explicit starting map
        w0 = np.maximum(seed, 0) + 1e-12
        seed = -1
    else:
        rng = np.random.default_rng(seed)
        w0 = rng.exponential(size=_H.fm.grid.n_cells)
    r = pgd(_H, w0 / w0.sum(), _CFG)
    r.seed = seed
    return r


def multistart(H, seeds, cfg: OptConfig = OptConfig(), n_jobs: int = None):
    seeds = list(seeds)
    n_jobs = n_jobs or min(len(seeds), os.cpu_count() or 1)
    if n_jobs <= 1:
        _init(H, cfg)
        res = [_run(s) for s in seeds]
    else:
        with ProcessPoolExecutor(n_jobs, initializer=_init, initargs=(H, cfg)) as ex:
            res = list(ex.map(_run, seeds))
    return sorted(res, key=lambda r: r.H)
