"""fitting.py — high-level fit, bootstrap and export helpers."""
from __future__ import annotations

import os
import copy
import numpy as np

from .forward import ForwardModel
from .hamiltonian import Hamiltonian, ObsTargets
from .optimize import multistart, OptConfig
from . import pgf


def fit(fm: ForwardModel, obs: ObsTargets, J=1.0, n_starts=16, seed0=0, cfg=None,
        n_jobs=None, mode="lagfreq", w_starts=None):
    H = Hamiltonian(fm, obs, J=J, mode=mode)
    seeds = list(range(seed0, seed0 + n_starts)) + [np.asarray(w) for w in (w_starts or [])]
    res = multistart(H, seeds, cfg or OptConfig(), n_jobs)
    best = res[0]
    d = H.diagnostics(best.w)
    d["n_iter"] = best.n_iter
    d["converged"] = best.converged
    d["H_spread"] = float(res[-1].H - res[0].H)
    return best.w, d, res, H


def perturb(obs: ObsTargets, rng) -> ObsTargets:
    """One bootstrap replica: resample lags, I_obs and the dilution factors."""
    o = copy.copy(obs)
    o.tau = obs.tau + rng.normal(0, obs.sig_tau)
    if obs.I_obs is not None:
        o.I_obs = float(np.clip(obs.I_obs + rng.normal(0, obs.sig_I), 1e-3, 0.999))
    f = 1 + rng.normal(0, obs.sig_D_frac)
    o.R_s, o.R_h = obs.R_s * max(f, 0.05), obs.R_h * max(f, 0.05)   # common refl. normalisation
    o.sig_D_frac = 0.0                       # already sampled
    t = (obs.meta or {}).get("le_term")
    if t is not None:                        # joint fit: resample the lag-energy spectrum too
        t2 = copy.copy(t)
        t2.lag = t.lag + rng.normal(0, np.where(t.ok, t.sig, 0.0))
        o.meta = dict(obs.meta, le_term=t2)
    return o


def bootstrap(fm, obs, J=1.0, n_boot=30, n_starts=4, seed=1234, n_jobs=None):
    rng = np.random.default_rng(seed)
    out = []
    for b in range(n_boot):
        o = perturb(obs, rng)
        w, d, _, _ = fit(fm, o, J=J, n_starts=n_starts, seed0=100 * b, n_jobs=n_jobs)
        out.append(dict(R_c=d["R_c"], z_c=d["z_c"], r_c=d["r_c"], mean_lag=d["mean_lag"],
                        chi2=d["chi2_lag"], w=w))
    return out


def summarize_boot(boot):
    keys = ["R_c", "z_c", "r_c", "mean_lag"]
    s = {}
    for k in keys:
        v = np.array([b[k] for b in boot])
        s[k] = dict(median=float(np.median(v)), p16=float(np.percentile(v, 16)),
                    p84=float(np.percentile(v, 84)))
    W = np.array([b["w"] for b in boot])
    s["w_mean"] = W.mean(0)
    s["w_std"] = W.std(0)
    return s


def export_map(grid, w, path_dat, path_tex, title="", contour_w=None):
    Rc, zc = grid.R_centers, grid.z_centers
    Z = grid.rz_map(w)
    Z = Z / Z.max()
    pgf.write_matrix_dat(path_dat, Rc, zc, Z)
    from . import config as C
    rel = "figures/" + os.path.relpath(path_dat, C.results_dir("figures")).replace(os.sep, "/")
    pgf.write_tex(path_tex, pgf.matrix_snippet(rel, len(Rc), title=title))
