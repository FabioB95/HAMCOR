"""
energy.py — energy-resolved reverberation transfer.

The reflected photon spectrum of disc element k seen by a distant observer is
    N_k,obs(E) = Omega_sky,k g_k^2 eps_k N_refl(E / g_k),
(photon-number intensity transforms as N_E / E^2 = invariant), with g_k = E_obs/E_em of a
prograde Keplerian disc (image-plane ray tracing, kerr.image_plane_disc), Omega_sky,k the
solid angle the element subtends on the observer's sky (lensing and projection included),
eps_k the illuminating photon flux per unit area and N_refl the rest-frame xillver
reflection spectrum (scripts/s11_xillver_templates.py).  Integrated over channel
[E_lo, E_hi]:
    S_kE = (Omega_sky,k / A_k) g_k^3 int_{E_lo/g_k}^{E_hi/g_k} N_refl(E') dE'.
For an emissivity w the energy-dependent transfer function is then
    psi_E(nu) = sum_i w_i sum_k Omega_ik S_kE exp(-2 pi i nu L_ik) / (same with nu = 0),
so blueshifted (approaching, inner) disc regions dominate the blue wing of the line and
gravitationally redshifted inner regions its red wing.  The channel amplitudes R_E
(reflected / continuum counts) stay those of the spectral fit; the reference band of each
channel (all other channels) responds with the reflection-count-weighted average of psi_E'.
Limitations: the incident photons' energy shift and the angular dependence of the
reflected emission (beyond the template inclination) are neglected; g is the image-ray
average over each element.
"""
import os

import numpy as np

TWO_PI = 2 * np.pi


def load_template(path):
    d = np.loadtxt(path, skiprows=1)
    E, refl = d[:, 0], d[:, 1]
    # cumulative photon integral for channel integrals (trapezoid)
    cum = np.r_[0.0, np.cumsum(0.5 * (refl[1:] + refl[:-1]) * np.diff(E))]
    return E, refl, cum


def channel_weights(disc, g, sky, template, E_lo, E_hi):
    """S (N_d, N_E): observed reflected photons of each element in each channel per unit
    illuminating photon (up to a constant)."""
    E, _, cum = template
    E_lo, E_hi = np.asarray(E_lo, float), np.asarray(E_hi, float)
    g = np.where(np.isfinite(g) & (g > 0), g, 1.0)[:, None]
    F = lambda x: np.interp(x, E, cum)
    S = g ** 3 * (F(E_hi[None] / g) - F(E_lo[None] / g))
    vis = np.where(np.isfinite(sky), sky, 0.0) / disc.areas
    return vis[:, None] * S


def disc_redshift(disc, incl, spin):
    from .kerr import disc_T_kerr_cached
    _, g, sky = disc_T_kerr_cached(disc, incl, spin)
    return g, sky


class EnergyTransfer:
    """Energy-resolved lag-energy predictions for a ForwardModel (HAMCOR map) or a
    lamppost row, sharing the per-element channel weights S."""

    def __init__(self, fm, template_path, E_lo, E_hi, R_E, R_ref, rates=None, g=None, sky=None):
        self.fm = fm
        if g is None:
            spin = fm.spin if fm.metric == "kerr" else 0.0
            g, sky = disc_redshift(fm.disc, fm.incl, spin)
        self.g, self.sky = g, sky
        self.tmpl = load_template(template_path)
        self.S = channel_weights(fm.disc, g, sky, self.tmpl, E_lo, E_hi)      # (N_d, N_E)
        self.R_E, self.R_ref = np.asarray(R_E, float), np.asarray(R_ref, float)
        R = self.R_E
        if rates is None:                         # fallback: reflected photon flux of the model
            rates = np.ones_like(R)
        self.rr = np.asarray(rates, float) * R / (1 + R)               # reflected counts per channel

    # psi_E(nu) for element-level complex weights U (N_f, N_d) and real weights U0 (N_d,)
    def _psi(self, U, U0):
        num = U @ self.S                                                # (N_f, N_E)
        den = U0 @ self.S                                               # (N_E,)
        return num / den[None]

    def _cross(self, psi, nu_w):
        """Z_E = sum_f p(f) conj(1 + R_ref psi_ref) (1 + R_E psi_E)."""
        rr = self.rr
        tot = (psi * rr[None]).sum(1, keepdims=True)
        psi_ref = (tot - psi * rr[None]) / (rr.sum() - rr)[None]
        c = np.conj(1 + self.R_ref[None] * psi_ref) * (1 + self.R_E[None] * psi)
        return (c * nu_w[:, None]).sum(0)

    def element_weights_map(self, w, nu):
        fm = self.fm
        W = fm.W
        U0 = w @ W                                                      # (N_d,)
        U = np.empty((len(nu), W.shape[1]), complex)
        for j, f in enumerate(nu):
            U[j] = w @ (W * np.exp(-1j * TWO_PI * f * fm.L))
        return U, U0

    def lag_energy_map(self, w, nu, nu_w, f_mean, mode="eres"):
        U, U0 = self.element_weights_map(w, nu)
        return self._tau(U, U0, nu_w, f_mean, mode)

    def lag_energy_row(self, Wrow, Lrow, nu, nu_w, f_mean, mode="eres"):
        U = Wrow[None] * np.exp(-1j * TWO_PI * np.asarray(nu)[:, None] * Lrow[None])
        return self._tau(U, Wrow, nu_w, f_mean, mode)

    def _tau(self, U, U0, nu_w, f_mean, mode):
        """mode: 'eres' (energy-resolved), 'visible' (one psi for all channels, elements
        weighted by their observed reflected photons summed over channels), 'grey' or
        False (one psi, elements weighted by illumination only: the s06/s08 model)."""
        if mode is True:
            mode = "eres"
        if mode == "eres":
            psi = self._psi(U, U0)
        elif mode == "visible":
            s1 = self.S.sum(1)
            psi = np.repeat(((U @ s1) / (U0 @ s1))[:, None], self.S.shape[1], axis=1)
        else:                                       # grey transfer: one psi for all channels
            psi = np.repeat((U.sum(1) / U0.sum())[:, None], self.S.shape[1], axis=1)
        Z = self._cross(psi, np.asarray(nu_w) / np.sum(nu_w))
        return -np.angle(Z) / (TWO_PI * f_mean)

    def model_line_profile(self, w=None, Wrow=None):
        """Observed time-averaged reflection spectrum per channel (for plots)."""
        U0 = (w @ self.fm.W) if w is not None else Wrow
        return U0 @ self.S


class LagEnergyTerm:
    """Lag-energy likelihood term for the HAMCOR Hamiltonian (joint fit).

    chi2_le = min_c sum_E [(tau_E(w) + c - tau_obs,E) / sig_E]^2   (c: additive offset,
    profiled; lag-energy spectra are defined up to a constant).  tau_E and d tau_E / d w
    are exact for the chosen transfer mode ('eres', 'visible', 'grey')."""

    def __init__(self, et: EnergyTransfer, nu, nu_w, f_mean, lag, sig, mode="eres"):
        fm = et.fm
        self.et, self.f_mean = et, float(f_mean)
        self.lag, self.sig = np.asarray(lag, float), np.asarray(sig, float)
        self.ok = np.isfinite(self.lag) & np.isfinite(self.sig) & (self.sig > 0)
        self.pw = np.asarray(nu_w, float) / np.sum(nu_w)
        nE = et.S.shape[1]
        if mode == "eres":
            S = et.S
        elif mode == "visible":
            S = np.repeat(et.S.sum(1, keepdims=True), nE, axis=1)
        else:
            S = np.ones_like(et.S)
        self.mode = mode
        self.D = fm.W @ S                                               # (N_c, N_E)
        self.M = np.stack([(fm.W * np.exp(-1j * TWO_PI * f * fm.L)) @ S for f in nu], 1)  # (N_c,N_f,N_E)
        rr = et.rr
        Q = np.where(np.eye(nE, dtype=bool), 0.0, rr[None, :]) / (rr.sum() - rr)[:, None]
        self.Q = Q                                                      # psi_ref = psi @ Q.T

    def tau(self, w, grad=False):
        et = self.et
        den = w @ self.D                                                # (N_E,)
        psi = np.einsum("i,ife->fe", w, self.M) / den[None]             # (N_f, N_E)
        pref = psi @ self.Q.T
        A = 1 + et.R_ref[None] * pref
        B = 1 + et.R_E[None] * psi
        Z = (np.conj(A) * B * self.pw[:, None]).sum(0)
        tau = -np.angle(Z) / (TWO_PI * self.f_mean)
        if not grad:
            return tau, None
        dpsi = (self.M - psi[None] * self.D[:, None, :]) / den[None, None]    # (N_c,N_f,N_E)
        dpref = np.einsum("ife,ge->ifg", dpsi, self.Q)
        dZ = (np.conj(et.R_ref[None, None] * dpref) * B[None] + np.conj(A)[None] * et.R_E[None, None] * dpsi)
        dZ = (dZ * self.pw[None, :, None]).sum(1)                        # (N_c, N_E)
        dtau = -np.imag(dZ / Z[None]) / (TWO_PI * self.f_mean)
        return tau, dtau

    def chi2(self, w, grad=False):
        tau, dtau = self.tau(w, grad)
        k = self.ok
        wt = 1 / self.sig[k] ** 2
        d = self.lag[k] - tau[k]
        c = float(np.sum(wt * d) / np.sum(wt))
        r = (tau[k] + c - self.lag[k]) / self.sig[k]
        ch = float(np.sum(r * r))
        if not grad:
            return ch, None, tau + c
        # envelope theorem: offset at its optimum
        return ch, 2 * dtau[:, k] @ (r / self.sig[k]), tau + c

    @property
    def n(self):
        return int(self.ok.sum())
