"""
pgf.py — export figure data as .dat tables plus ready-to-\\input PGFPlots snippets
(native vector figures for Overleaf; no raster images).
"""
from __future__ import annotations

import os
import numpy as np


def write_dat(path, **cols):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    names = list(cols)
    arr = np.column_stack([np.asarray(cols[n], float) for n in names])
    np.savetxt(path, arr, header=" ".join(names), comments="", fmt="%.6e")
    return path


def write_matrix_dat(path, x, y, Z):
    """Rows ordered for 'matrix plot*' with mesh/cols = len(x)."""
    X, Y = np.meshgrid(x, y)            # y slow, x fast
    return write_dat(path, x=X.ravel(), y=Y.ravel(), c=np.asarray(Z).T.ravel())


def matrix_snippet(datfile, ncols, xlabel=r"$R\;[r_g]$", ylabel=r"$z\;[r_g]$",
                   clabel=r"$\sum_\phi w_i$", title="", xmode="log", ymode="log",
                   width="0.30\\textwidth", contour_dat=None):
    s = [r"\begin{tikzpicture}",
         rf"\begin{{axis}}[width={width}, height={width}, xmode={xmode}, ymode={ymode},",
         rf"  xlabel={{{xlabel}}}, ylabel={{{ylabel}}}, title={{{title}}},",
         r"  colorbar, colormap name=hamcor, colorbar style={ylabel={" + clabel + "}},",
         r"  enlargelimits=false, axis on top, tick label style={font=\scriptsize},",
         r"  log ticks with fixed point, xtick={3,5,8,12}, ytick={0.1,0.3,1,3},",
         r"  label style={font=\small}, title style={font=\small}]",
         rf"\addplot[matrix plot*, mesh/cols={ncols}, point meta=explicit]",
         rf"  table[x=x, y=y, meta=c] {{{datfile}}};"]
    if contour_dat:
        s += [r"\addplot[contour prepared, contour prepared format=matlab, black, thin]",
              rf"  table {{{contour_dat}}};"]
    s += [r"\end{axis}", r"\end{tikzpicture}"]
    return "\n".join(s)


def band_fill(lo, hi, color="red!12"):
    """Shaded x-interval spanning the full y-range (put before the plots)."""
    return (rf"\fill[{color}] ({{axis cs:{lo},0}}|-{{rel axis cs:0,0}}) rectangle "
            rf"({{axis cs:{hi},0}}|-{{rel axis cs:0,1}});")


def errorbar_snippet(datfile, x="f", y="tau", e="sig", model_dat=None, mx="f", my="tau",
                     xlabel=r"$f$ [Hz]", ylabel=r"$\tau$ [s]", xmode="log", title="",
                     width="0.45\\textwidth", height="0.32\\textwidth", extra="", pre=""):
    s = [r"\begin{tikzpicture}",
         rf"\begin{{axis}}[width={width}, height={height}, xmode={xmode},",
         rf"  xlabel={{{xlabel}}}, ylabel={{{ylabel}}}, title={{{title}}},",
         r"  extra y ticks={0}, extra y tick labels={},",
         r"  extra y tick style={grid=major, major grid style={dashed, gray}},",
         r"  tick label style={font=\scriptsize}, label style={font=\small},",
         r"  legend style={font=\scriptsize, draw=none}, legend pos=south west]",
         pre,
         rf"\addplot[only marks, mark=*, mark size=1.2pt, black, error bars/.cd, y dir=both, y explicit]",
         rf"  table[x={x}, y={y}, y error={e}] {{{datfile}}};",
         r"\addlegendentry{data}"]
    if model_dat:
        s += [rf"\addplot[thick, blue!70!black] table[x={mx}, y={my}] {{{model_dat}}};",
              r"\addlegendentry{model}"]
    s += [extra, r"\end{axis}", r"\end{tikzpicture}"]
    return "\n".join(s)


PREAMBLE = r"""% ---- add once to the LaTeX preamble ----
\usepackage{pgfplots}
\pgfplotsset{compat=1.18}
\usepgfplotslibrary{colormaps}
\pgfplotsset{colormap={hamcor}{rgb255(0cm)=(255,255,255) rgb255(1cm)=(254,224,144)
  rgb255(2cm)=(253,141,60) rgb255(3cm)=(215,48,31) rgb255(4cm)=(127,0,0)}}
"""


def write_tex(path, body):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        f.write(body + "\n")
    return path
