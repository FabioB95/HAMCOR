"""
schwarzschild_lags.py  (v2)
───────────────────────────
First-order (weak-field, O(r_g/r)) Schwarzschild correction to the
corona -> disc -> observer reverberation lag matrix.

Units: G = c = M = 1  ->  lengths in r_g, times in r_g/c.

Lag of the reflected path (corona cell i -> disc element k -> observer)
relative to the direct path (corona cell i -> observer):

    tau_ik = [ l_ik + S(x_i, x_k) ]                (leg i -> k)
           + [ -x_k . n + S_inf(x_k) ]             (leg k -> obs)
           - [ -x_i . n + S_inf(x_i) ]             (leg i -> obs)

    l_ik         = |x_k - x_i|
    S(A, B)      = 2 ln[(r_A + r_B + l_AB) / (r_A + r_B - l_AB)]
    S_inf(x)     = -2 ln[ r (1 + cos theta) ]  + const,   cos theta = x.n / r
    n            = unit vector towards the observer

S(A,B) is the exact line integral of the weak-field term  int 2/r ds  along
the straight segment AB. It holds for BOTH segment classes:
  * monotonic  : closest approach to the hole at an endpoint;
  * V-shaped   : closest approach at an interior point;
so no case split (and no impact-parameter clipping) is required.
S_inf is the D -> inf limit of S(x, D n) with the divergent 2 ln(2D)
removed; the constant cancels identically in tau_ik.

Visibility Xi_ik (Eq. 10 of the paper) is set to 0 for any leg whose
straight segment passes within b_min of the hole (default b_min = 2 r_g:
geometric occultation by the event horizon). Paths with 2 < b < 3 r_g are
kept but are outside the weak-field regime; b_min = 3 r_g (photon sphere) is
run as a systematic. Returned separately so that the caller multiplies the
solid-angle matrix by Xi (illumination AND transfer function).

Changes with respect to v1 (bugs fixed)
  1. Sign of the observer projection: v1 used  l_ik + x_k.n - x_i.n,
     the correct far-field expansion is  l_ik - x_k.n + x_i.n.
  2. v1 evaluated 2 ln[(r_A+sqrt(r_A^2-b^2))(r_B+sqrt(r_B^2-b^2))/b^2]
     with b clipped to the segment; for monotonic segments b = r_A and the
     argument degenerates, so v1 returned the 20 r_g/c cap for those legs.
  3. v1 observer-leg delay 2 ln(2 r / b) has no correct r-dependence;
     replaced by the exact limit S_inf above.
  4. Fully vectorised (v1: Python double loop).

References: Shapiro (1964) PRL 13, 789; Misner, Thorne & Wheeler (1973)
sect. 40.4; Weinberg (1972) sect. 8.7.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass

B_MIN_DEFAULT = 2.0      # r_g, event horizon (occultation); 3.0 = photon sphere (systematic)
_EPS = 1e-12


@dataclass
class SchwarzschildLagResult:
    lag_matrix: np.ndarray        # (N_c, N_d)  tau_ik  [r_g/c]
    visibility: np.ndarray        # (N_c, N_d)  Xi_ik in {0,1}
    lag_flat: np.ndarray          # (N_c, N_d)  Euclidean part
    shapiro: np.ndarray           # (N_c, N_d)  total Shapiro part
    b_ik: np.ndarray              # (N_c, N_d)  impact parameter, leg i->k
    b_k_obs: np.ndarray           # (N_d,)
    b_i_obs: np.ndarray           # (N_c,)
    n_hat: np.ndarray             # (3,)


# ─────────────────────────────────────────────────────────────────────────────
def observer_hat(incl_deg: float) -> np.ndarray:
    th = np.radians(incl_deg)
    return np.array([np.sin(th), 0.0, np.cos(th)])


def shapiro_segment(r_a, r_b, ell):
    """2 ln[(r_a + r_b + l)/(r_a + r_b - l)]  — exact int 2/r ds on a segment."""
    s = r_a + r_b
    return 2.0 * np.log((s + ell) / np.maximum(s - ell, _EPS))


def shapiro_to_infinity(x, r, n_hat):
    """-2 ln[r (1+cos theta)]  (additive constant dropped)."""
    one_plus_cos = 1.0 + (x @ n_hat) / np.maximum(r, _EPS)
    return -2.0 * np.log(np.maximum(r * one_plus_cos, _EPS))


def impact_segment(x_a, x_b):
    """Distance from the origin to the segment [x_a, x_b] (broadcasting)."""
    ab = x_b - x_a
    L2 = np.sum(ab * ab, axis=-1)
    t = np.clip(-np.sum(x_a * ab, axis=-1) / np.maximum(L2, _EPS), 0.0, 1.0)
    return np.linalg.norm(x_a + t[..., None] * ab, axis=-1)


def impact_to_infinity(x, n_hat):
    """Distance from the origin to the ray x + s n, s >= 0."""
    proj = x @ n_hat
    perp = np.linalg.norm(x - proj[:, None] * n_hat[None, :], axis=1)
    return np.where(proj >= 0.0, np.linalg.norm(x, axis=1), perp)


# ─────────────────────────────────────────────────────────────────────────────
def compute_lag_matrix_schwarzschild(
    grid,
    disk,
    observer_inclination: float = 30.0,
    b_min: float = B_MIN_DEFAULT,
    return_components: bool = False,
):
    """
    Returns
    -------
    (lag_matrix, visibility)                     if return_components is False
    SchwarzschildLagResult                       otherwise
    """
    n = observer_hat(observer_inclination)
    xi = np.asarray(grid.get_cartesian(), dtype=float)   # (N_c, 3)
    xk = np.asarray(disk.get_cartesian(), dtype=float)   # (N_d, 3)
    ri = np.linalg.norm(xi, axis=1)
    rk = np.linalg.norm(xk, axis=1)

    d = xk[None, :, :] - xi[:, None, :]                  # (N_c, N_d, 3)
    ell = np.linalg.norm(d, axis=2)

    lag_flat = ell - (xk @ n)[None, :] + (xi @ n)[:, None]

    S_ik = shapiro_segment(ri[:, None], rk[None, :], ell)
    S_k = shapiro_to_infinity(xk, rk, n)
    S_i = shapiro_to_infinity(xi, ri, n)
    shapiro = S_ik + S_k[None, :] - S_i[:, None]

    lag = lag_flat + shapiro

    b_ik = impact_segment(xi[:, None, :], xk[None, :, :])
    b_k = impact_to_infinity(xk, n)
    b_i = impact_to_infinity(xi, n)
    vis = ((b_ik >= b_min)
           & (b_k >= b_min)[None, :]
           & (b_i >= b_min)[:, None]).astype(float)

    if return_components:
        return SchwarzschildLagResult(lag, vis, lag_flat, shapiro,
                                      b_ik, b_k, b_i, n)
    return lag, vis


# ─────────────────────────────────────────────────────────────────────────────
def correction_statistics(res: SchwarzschildLagResult, solid_angles=None) -> dict:
    """
    Fractional Shapiro correction. If solid_angles is given, statistics are
    weighted by Omega_ik * Xi_ik (what actually enters psi(t)); otherwise
    unweighted over visible pairs.
    """
    m = res.visibility > 0
    frac = res.shapiro[m] / np.maximum(res.lag_flat[m], 1e-6)
    w = (solid_angles[m] if solid_angles is not None else np.ones(m.sum()))
    w = w / w.sum()
    order = np.argsort(frac)
    cdf = np.cumsum(w[order])
    wmed = frac[order][np.searchsorted(cdf, 0.5)]
    return dict(
        visible_fraction=float(m.mean()),
        n_negative_lags=int((res.lag_matrix[m] < 0).sum()),
        mean_abs_correction_rgc=float(np.sum(w * res.shapiro[m])),
        mean_frac_correction=float(np.sum(w * frac)),
        median_frac_correction=float(wmed),
        lag_flat_range=(float(res.lag_flat[m].min()), float(res.lag_flat[m].max())),
        lag_gr_range=(float(res.lag_matrix[m].min()), float(res.lag_matrix[m].max())),
    )
