"""HAMCOR v2 — Hamiltonian inference of X-ray coronal geometry from reverberation."""
__version__ = "2.0.0"

from .grid import build_grid, build_disc_grid, solid_angles          # noqa: F401
from .forward import ForwardModel, PointSourceModel, t_g             # noqa: F401
from .hamiltonian import Hamiltonian, ObsTargets                     # noqa: F401
from .optimize import pgd, multistart, OptConfig, project_simplex    # noqa: F401
