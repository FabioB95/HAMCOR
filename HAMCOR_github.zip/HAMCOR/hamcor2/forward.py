"""
forward.py — HAMCOR forward model.

Definitions (units G = c = M = 1: lengths r_g, times r_g/c, frequencies c^3/GM)

  W_ik   = Omega_ik * Xi_ik            illumination weight of pair (i,k)
  L_ik   = tau_ik                      corona->disc->observer delay (flat or Schwarzschild)
  a_i    = sum_k W_ik                  solid angle of the visible disc seen from cell i

Impulse response (transfer function) of the reflected component to a
delta-function flare of the continuum (Blandford & McKee 1982;
Reynolds et al. 1999; Uttley et al. 2014):

  psi(t) = sum_{i,k} w_i W_ik delta(t - L_ik) / sum_{i,k} w_i W_ik ,   int psi dt = 1

Fourier transform (numpy sign convention, X(f) = sum x e^{-2 pi i f t}):

  psi~(nu) = sum_i w_i G_i(nu) / sum_i w_i a_i ,   G_i(nu) = sum_k W_ik e^{-2 pi i nu L_ik}

Linear two-band reverberation model. Band X (soft s, hard h) light curve:
  x(t) = c(t) + R_X (psi * c)(t)     R_X = (reflected / continuum) count rate in band X
so that X~ = C~ (1 + R_X psi~). Cross spectrum <H~* S~> = |C~|^2 (1+R_h psi~)^* (1+R_s psi~),
and the soft-minus-hard time lag (negative = soft lags hard, the convention of eq. 7 of the paper)

  tau_sh(nu) = { arg[1 + R_s psi~(nu)] - arg[1 + R_h psi~(nu)] } / (2 pi nu).

Low-frequency limit (2 pi nu <t> << 1):
  tau_sh -> - D <t>,     D = R_s/(1+R_s) - R_h/(1+R_h) = F_s^refl/F_s^tot - F_h^refl/F_h^tot,
which is the dilution of the reverberation lag by the continuum in both bands
(e.g. Wilkins & Fabian 2013; Uttley et al. 2014; Kara et al. 2016).

Illumination fraction (photons reaching the disc over photons reaching the disc or
infinity; photons captured by the hole excluded), the observable of the relxill
reflection fraction R_f = I/(1-I) (Dauser et al. 2016):
  I(w) = sum_i w_i a_i / sum_i w_i (a_i + E_i)
E_i is the solid angle escaping to infinity from cell i.

Metrics:
  "schwarzschild"  exact null geodesics (raytrace.py): light bending, capture, Shapiro
                   delay and occultation from the integrated orbits      [baseline]
  "weakfield"      straight rays + first-order Shapiro delay + photon-sphere
                   occultation (gr.py); E = 4 pi - a                    [comparison]
  "flat"           straight rays, Euclidean delays; E = 4 pi - a       [comparison]
"""
from __future__ import annotations

import numpy as np

from .grid import CoronalGrid, DiscGrid, solid_angles
from .gr import compute_lag_matrix_schwarzschild, observer_hat

TWO_PI = 2.0 * np.pi
T_G_SUN = 4.925490947e-6          # GM_sun / c^3  [s]


def t_g(M_bh_sun: float) -> float:
    """GM/c^3 in seconds."""
    return T_G_SUN * M_bh_sun


def flat_lag_matrix(grid: CoronalGrid, disc: DiscGrid, incl_deg: float) -> np.ndarray:
    """Observer at infinity: tau = |x_k - x_i| - x_k.n + x_i.n."""
    n = observer_hat(incl_deg)
    xi, xk = grid.get_cartesian(), disc.get_cartesian()
    ell = np.linalg.norm(xk[None] - xi[:, None], axis=2)
    return ell - (xk @ n)[None, :] + (xi @ n)[:, None]


class ForwardModel:
    """Precomputes geometry for one (grid, disc, inclination, metric)."""

    def __init__(self, grid: CoronalGrid, disc: DiscGrid, incl_deg: float,
                 metric: str = "schwarzschild", b_min: float = 2.0, spin: float = 0.0):
        self.grid, self.disc, self.incl, self.metric = grid, disc, incl_deg, metric
        self.spin = spin
        self.invalid = np.zeros(grid.n_cells, bool)
        if metric == "kerr":
            from .kerr import (disc_response_kerr, observer_delays_kerr_cached, disc_T_kerr_cached)
            Om, tsp, E, valid = disc_response_kerr(grid, disc, spin, verbose=False)
            T_d, self.g_disc, _ = disc_T_kerr_cached(disc, incl_deg, spin)
            T_c = np.zeros(grid.n_cells)
            T_c[valid] = observer_delays_kerr_cached(grid.get_cartesian()[valid], incl_deg, spin)
            self.Omega = Om
            self.Xi = (Om > 0).astype(float)
            self.L = np.where(Om > 0, np.maximum(tsp + T_d[None, :] - T_c[:, None], 0.0), 0.0)
            self.E = E
            self.invalid = ~valid
        elif metric == "schwarzschild":
            from .raytrace import disc_response, observer_delays_cached
            Om, tsp, E = disc_response(grid, disc)
            T_d = observer_delays_cached(disc.get_cartesian(), incl_deg)
            T_c = observer_delays_cached(grid.get_cartesian(), incl_deg)
            self.Omega = Om
            self.Xi = (Om > 0).astype(float)
            # residual negatives (|L| < 1 r_g/c) come from evaluating T at the element
            # centre instead of the hit point; causality fixes L >= 0
            self.L = np.where(Om > 0, np.maximum(tsp + T_d[None, :] - T_c[:, None], 0.0), 0.0)
            self.E = E
        elif metric == "weakfield":
            self.Omega = solid_angles(grid, disc)
            self.L, self.Xi = compute_lag_matrix_schwarzschild(grid, disc, incl_deg, b_min)
        elif metric == "flat":
            self.Omega = solid_angles(grid, disc)
            self.L = flat_lag_matrix(grid, disc, incl_deg)
            self.Xi = np.ones_like(self.L)
        else:
            raise ValueError(metric)
        self.W = self.Omega * self.Xi
        self.a = self.W.sum(axis=1)                  # (N_c,)
        if metric not in ("schwarzschild", "kerr"):
            self.E = 4 * np.pi - self.a
        self.aL = (self.W * self.L).sum(axis=1)      # (N_c,)  for <t>
        self._G_cache = {}

    # ── illumination ────────────────────────────────────────────────────────
    def illumination(self, w):
        return float(w @ self.a) / float(w @ (self.a + self.E))

    def illumination_grad(self, w):
        A, B = float(w @ self.a), float(w @ (self.a + self.E))
        return self.a / B - A * (self.a + self.E) / B ** 2

    # ── first moment ────────────────────────────────────────────────────────
    def mean_lag(self, w):
        return float(w @ self.aL) / float(w @ self.a)

    def mean_lag_grad(self, w):
        Q = float(w @ self.a)
        return (self.aL - self.mean_lag(w) * self.a) / Q

    # ── Fourier transfer function ───────────────────────────────────────────
    def G(self, nu: np.ndarray) -> np.ndarray:
        """G_i(nu) = sum_k W_ik exp(-2 pi i nu L_ik), shape (N_c, N_f)."""
        nu = np.atleast_1d(np.asarray(nu, float))
        key = nu.tobytes()
        if key not in self._G_cache:
            out = np.empty((self.grid.n_cells, nu.size), complex)
            for j, f in enumerate(nu):
                out[:, j] = (self.W * np.exp(-1j * TWO_PI * f * self.L)).sum(axis=1)
            self._G_cache[key] = out
        return self._G_cache[key]

    def psi_tilde(self, w, nu):
        G = self.G(nu)
        return (w @ G) / float(w @ self.a)

    def lag_model(self, w, nu, R_s, R_h, grad: bool = False):
        """Soft-minus-hard lag tau(nu) [r_g/c] and optionally d tau / d w (N_c, N_f)."""
        nu = np.atleast_1d(np.asarray(nu, float))
        G = self.G(nu)
        Q = float(w @ self.a)
        pt = (w @ G) / Q
        Xs, Xh = 1 + R_s * pt, 1 + R_h * pt
        tau = (np.angle(Xs) - np.angle(Xh)) / (TWO_PI * nu)
        if not grad:
            return tau
        dpt = (G - self.a[:, None] * pt[None, :]) / Q                 # (N_c, N_f)
        dphi = np.imag(dpt * (R_s / Xs - R_h / Xh)[None, :])
        return tau, dphi / (TWO_PI * nu)[None, :]

    @staticmethod
    def bin_matrix(bin_k, nb):
        B = np.zeros((len(bin_k), nb))
        B[np.arange(len(bin_k)), bin_k] = 1.0
        return B

    def lag_model_binned(self, w, nu_k, p_k, bin_k, nu_bar, R_s, R_h, grad=False, B=None):
        """
        Model passed through the same estimator as the data: in bin j
          Z_j = sum_{k in j} p_k (1 + R_h psi~_k)^* (1 + R_s psi~_k),
          tau_j = arg Z_j / (2 pi nu_bar_j),
        p_k = (noise-subtracted) reference power at the Fourier frequencies used.
        """
        if B is None:
            B = self.bin_matrix(bin_k, len(nu_bar))
        G = self.G(nu_k)
        Q = float(w @ self.a)
        pt = (w @ G) / Q
        A, Bs = 1 + R_h * pt, 1 + R_s * pt
        Z = (p_k * np.conj(A) * Bs) @ B
        tau = np.angle(Z) / (TWO_PI * nu_bar)
        if not grad:
            return tau
        dpt = (G - self.a[:, None] * pt[None, :]) / Q                     # (N_c, N_k)
        # d/dw_i [conj(A) Bs] = conj(R_h dpt) Bs + conj(A) R_s dpt
        dZ = ((np.conj(R_h * dpt) * Bs[None, :] + np.conj(A)[None, :] * R_s * dpt)
              * p_k[None, :]) @ B
        dtau = np.imag(dZ / Z[None, :]) / (TWO_PI * nu_bar)[None, :]
        return tau, dtau

    def band_cross(self, w, nu_grid, weights, R_x, R_ref):
        """
        Band-averaged model cross spectrum  sum_f p(f) (1+R_ref psi~)^* (1+R_x psi~)
        for lag-energy predictions; p(f) are continuum-power weights.
        R_x, R_ref may be arrays (one per channel of interest).
        """
        pt = self.psi_tilde(w, nu_grid)                               # (N_f,)
        R_x = np.atleast_1d(R_x)[:, None]
        R_ref = np.atleast_1d(R_ref)[:, None]
        c = np.conj(1 + R_ref * pt[None]) * (1 + R_x * pt[None])      # (N_E, N_f)
        return (c * weights[None]).sum(axis=1)

    # ── binned psi (legacy prior mode and plots) ────────────────────────────
    def psi_binned_matrix(self, edges: np.ndarray) -> np.ndarray:
        """A_ib = sum_{k: L_ik in bin b} W_ik ; last column = overflow (L >= edges[-1])."""
        nb = len(edges) - 1
        idx = np.digitize(self.L, edges) - 1
        idx = np.where(self.L >= edges[-1], nb, idx)
        idx = np.where(self.L < edges[0], nb, idx)        # underflow merged with overflow
        A = np.zeros((self.grid.n_cells, nb + 1))
        for b in range(nb + 1):
            A[:, b] = (self.W * (idx == b)).sum(axis=1)
        return A

    def psi_binned(self, w, A):
        return (w @ A) / float(w @ self.a)


class PointSourceModel:
    """
    Lamppost: isotropic point source on the axis at height h (not grid-limited).
    row(h) returns W_k, L_k (one row) so the same Fourier machinery applies;
    escape(h) the solid angle escaping to infinity.  For the ray-traced metric call
    prepare(h_values) once (one trace per height, cached on disk).
    """

    def __init__(self, disc: DiscGrid, incl_deg: float, metric="schwarzschild", b_min=2.0, spin=0.0):
        self.disc, self.incl, self.metric, self.b_min, self.spin = disc, incl_deg, metric, b_min, spin
        self._rt = {}

    def prepare(self, h_values):
        if self.metric == "kerr":
            from .kerr import point_response_kerr, observer_delays_kerr_cached, disc_T_kerr_cached
            h_values = np.atleast_1d(np.asarray(h_values, float))
            Om, tsp, E = point_response_kerr(h_values, self.disc, self.spin)
            T_d = disc_T_kerr_cached(self.disc, self.incl, self.spin)[0]
            T_s = observer_delays_kerr_cached(np.column_stack([0 * h_values, 0 * h_values, h_values]),
                                              self.incl, self.spin)
            for j, h in enumerate(h_values):
                L = np.where(Om[j] > 0, np.maximum(tsp[j] + T_d - T_s[j], 0.0), 0.0)
                self._rt[round(float(h), 9)] = (Om[j], L, float(E[j]))
            return
        if self.metric != "schwarzschild":
            return
        from .raytrace import point_response, observer_delays_cached
        h_values = np.atleast_1d(np.asarray(h_values, float))
        Om, tsp, E = point_response(h_values, self.disc)
        T_d = observer_delays_cached(self.disc.get_cartesian(), self.incl)
        T_s = observer_delays_cached(np.column_stack([0 * h_values, 0 * h_values, h_values]),
                                     self.incl)
        for j, h in enumerate(h_values):
            L = np.where(Om[j] > 0, np.maximum(tsp[j] + T_d - T_s[j], 0.0), 0.0)
            self._rt[round(float(h), 9)] = (Om[j], L, float(E[j]))

    def _get(self, h):
        k = round(float(h), 9)
        if k not in self._rt:
            self.prepare([h])
        return self._rt[k]

    def row(self, h):
        if self.metric in ("schwarzschild", "kerr"):
            W, L, _ = self._get(h)
            return W, L
        class _G:  # minimal grid with one cell on the axis
            pass
        g = _G()
        g.R, g.z, g.phi = np.array([0.0]), np.array([h]), np.array([0.0])
        g.n_cells = 1
        g.get_cartesian = lambda: np.array([[0.0, 0.0, h]])
        d = self.disc.get_cartesian() - np.array([0, 0, h])
        d2 = (d * d).sum(1)
        Om = h / np.sqrt(d2) * self.disc.areas / d2
        if self.metric == "weakfield":
            L, Xi = compute_lag_matrix_schwarzschild(g, self.disc, self.incl, self.b_min)
            L, Xi = L[0], Xi[0]
        else:
            n = observer_hat(self.incl)
            xk = self.disc.get_cartesian()
            L = np.sqrt(d2) - xk @ n + h * n[2]
            Xi = np.ones_like(L)
        return Om * Xi, L

    def escape(self, h):
        if self.metric in ("schwarzschild", "kerr"):
            return self._get(h)[2]
        return 4 * np.pi - self.row(h)[0].sum()

    def lag_model(self, h, nu, R_s, R_h):
        W, L = self.row(h)
        nu = np.atleast_1d(nu)
        pt = (W[None, :] * np.exp(-1j * TWO_PI * nu[:, None] * L[None, :])).sum(1) / W.sum()
        return (np.angle(1 + R_s * pt) - np.angle(1 + R_h * pt)) / (TWO_PI * nu)

    def illumination(self, h):
        W, _ = self.row(h)
        return W.sum() / (W.sum() + self.escape(h))
