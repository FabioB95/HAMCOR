"""
metrics.py — recovery metrics, parity decomposition, Fisher information.
"""
from __future__ import annotations

import numpy as np

from .grid import CoronalGrid


def pearson(a, b) -> float:
    a, b = np.ravel(a), np.ravel(b)
    if np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def overlap(a, b) -> float:
    """Bhattacharyya coefficient of the normalised distributions."""
    a, b = a / a.sum(), b / b.sum()
    return float(np.sum(np.sqrt(a * b)))


def mirror_index(grid: CoronalGrid) -> np.ndarray:
    """Index map for phi -> -phi (y -> -y), the reflection about the observer plane."""
    ir, iz, ip = np.unravel_index(np.arange(grid.n_cells), (grid.n_r, grid.n_z, grid.n_phi))
    return np.ravel_multi_index((ir, iz, (grid.n_phi - 1 - ip) % grid.n_phi),
                                (grid.n_r, grid.n_z, grid.n_phi))


def parity_split(grid, w):
    m = w[mirror_index(grid)]
    return 0.5 * (w + m), 0.5 * (w - m)


def azimuthal_average(grid, w):
    """Cell-wise azimuthal mean (projects out all phi structure)."""
    rz = w.reshape(grid.n_r, grid.n_z, grid.n_phi).mean(axis=2, keepdims=True)
    return np.broadcast_to(rz, (grid.n_r, grid.n_z, grid.n_phi)).ravel()


def recovery_metrics(grid: CoronalGrid, w_true, w_rec) -> dict:
    ev_t, od_t = parity_split(grid, w_true)
    ev_r, od_r = parity_split(grid, w_rec)
    Rt, zt = float(w_true @ grid.R), float(w_true @ grid.z)
    Rr, zr = float(w_rec @ grid.R), float(w_rec @ grid.z)
    return dict(
        rho_3d=pearson(w_true, w_rec),
        rho_rz=pearson(grid.rz_map(w_true), grid.rz_map(w_rec)),
        rho_even=pearson(ev_t, ev_r),
        odd_power_true=float(np.sum(od_t ** 2) / np.sum(w_true ** 2)),
        odd_power_rec=float(np.sum(od_r ** 2) / np.sum(w_rec ** 2)),
        phi_power_true=float(np.sum((w_true - azimuthal_average(grid, w_true)) ** 2)
                             / np.sum((w_true - w_true.mean()) ** 2)),
        overlap=overlap(w_true, w_rec),
        R_c_true=Rt, z_c_true=zt, R_c_rec=Rr, z_c_rec=zr,
        d_centroid=float(np.hypot(Rr - Rt, zr - zt)),
    )


def fisher_spectrum(jac: np.ndarray, sigma: np.ndarray) -> dict:
    """
    jac: (N_obs, N_c) derivatives of the observables w.r.t. w at the truth.
    Restricted to the simplex tangent space (sum dw = 0).
    Returns eigenvalues of F = J^T Sigma^-1 J and the effective number of
    data-constrained modes N_eff = sum lambda/(lambda+1) (unit-variance prior on
    each mode) and the rank at tolerance 1e-8 * lambda_max.
    """
    N = jac.shape[1]
    P = np.eye(N) - np.ones((N, N)) / N
    Js = (jac / sigma[:, None]) @ P
    s = np.linalg.svd(Js, compute_uv=False)
    lam = s ** 2
    return dict(eigvals=lam, N_obs=jac.shape[0], N_params=N - 1,
                rank=int(np.sum(lam > 1e-8 * lam.max())),
                N_eff=float(np.sum(lam / (lam + 1.0))))


def entropy_fraction(w) -> float:
    """exp(Shannon entropy)/N : fraction of cells effectively emitting."""
    p = w / w.sum()
    return float(np.exp(-np.sum(p * np.log(p + 1e-300))) / p.size)
