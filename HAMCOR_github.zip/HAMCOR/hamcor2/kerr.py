"""
kerr.py — photon transfer in Kerr spacetime (G = c = M = 1) for HAMCOR.

Coordinates: Cartesian Kerr-Schild (t, x, y, z), regular on the axis and across the
horizon.  The metric is g_{mu nu} = eta_{mu nu} + f k_mu k_nu with
    f   = 2 r^3 / (r^4 + a^2 z^2),
    k_mu = (1, (r x + a y)/(r^2 + a^2), (r y - a x)/(r^2 + a^2), z/r),
and r the Boyer-Lindquist radius, (x^2 + y^2)/(r^2 + a^2) + z^2/r^2 = 1.  The inverse is
g^{mu nu} = eta^{mu nu} - f k^mu k^nu with k^mu = (-1, k_x, k_y, k_z).  Null geodesics
follow Hamilton's equations for H = (1/2) g^{mu nu} p_mu p_nu; the force term
-dH/dx^i is obtained by central differences of H (vectorised RK4, step eta*r).

Emitters are static (u proportional to the Killing vector d/dt; valid outside the
ergosphere) and isotropic in their rest frame (orthonormal tetrad built by Gram-Schmidt).
The equatorial disc z = 0 extends from the prograde ISCO; hits are recorded at the
first crossing of z = 0 with Boyer-Lindquist radius in [r_in, r_out].

Arrival-time offsets towards a distant observer, T(x) = lim [t - x.n - c ln r], are
found by 2D Newton shooting on the emission direction.  Kerr-Schild time differs from
Boyer-Lindquist time by a function of r only, which cancels in the lags
L_ik = t_SP + T(x_k) - T(x_i); the logarithmic coefficient c = 4 (Kerr-Schild ingoing
time) is verified numerically.  For a = 0 the module reproduces raytrace.py.
"""
from __future__ import annotations

import hashlib
import os

import numpy as np

from .raytrace import fibonacci_sphere

R_ESC = 600.0
R_FAR = 2.0e4
CLOG = 4.0


def r_isco(a):
    z1 = 1 + (1 - a * a) ** (1 / 3) * ((1 + a) ** (1 / 3) + (1 - a) ** (1 / 3))
    z2 = np.sqrt(3 * a * a + z1 * z1)
    return 3 + z2 - np.sqrt((3 - z1) * (3 + z1 + 2 * z2))


def r_horizon(a):
    return 1 + np.sqrt(1 - a * a)


def bl_r(x, y, z, a):
    rho2 = x * x + y * y + z * z - a * a
    return np.sqrt(0.5 * (rho2 + np.sqrt(rho2 * rho2 + 4 * a * a * z * z)))


def _fk(X, a):
    """f and covariant k (spatial part) at positions X (n,3)."""
    x, y, z = X[:, 0], X[:, 1], X[:, 2]
    r = bl_r(x, y, z, a)
    r2a2 = r * r + a * a
    f = 2 * r ** 3 / (r ** 4 + a * a * z * z)
    k = np.column_stack([(r * x + a * y) / r2a2, (r * y - a * x) / r2a2, z / r])
    return f, k, r


def g_lower(X, a):
    f, k, _ = _fk(X, a)
    n = len(X)
    K = np.column_stack([np.ones(n), k])                 # k_mu
    g = np.tile(np.diag([-1.0, 1, 1, 1]), (n, 1, 1)) + f[:, None, None] * K[:, :, None] * K[:, None, :]
    return g


def _H2(X, P, a):
    """2H = g^{mu nu} p_mu p_nu (P = (p_t, p_x, p_y, p_z))."""
    f, k, _ = _fk(X, a)
    kp = -P[:, 0] + np.einsum("ij,ij->i", k, P[:, 1:])     # k^mu p_mu, k^t = -1
    eta = -P[:, 0] ** 2 + np.einsum("ij,ij->i", P[:, 1:], P[:, 1:])
    return eta - f * kp * kp


def _rhs(X, P, a):
    f, k, r = _fk(X, a)
    kp = -P[:, 0] + np.einsum("ij,ij->i", k, P[:, 1:])
    # dx^mu/dl = g^{mu nu} p_nu = eta^{mu nu} p_nu - f k^mu (k.p)
    dt = -P[:, 0] + f * kp                                # k^t = -1
    dx = P[:, 1:] - (f * kp)[:, None] * k
    # dp_i/dl = -(1/2) d(2H)/dx^i / 1  (H = 2H/2)
    h = 1e-6 * np.maximum(r, 1.0)
    dp = np.empty_like(X)
    for i in range(3):
        e = np.zeros(3); e[i] = 1.0
        Hp = _H2(X + h[:, None] * e, P, a)
        Hm = _H2(X - h[:, None] * e, P, a)
        dp[:, i] = -0.25 * (Hp - Hm) / h
    return dt, dx, dp


def _step(X, P, t, a, eta):
    r = bl_r(X[:, 0], X[:, 1], X[:, 2], a)
    hh = eta * np.clip(r, 1.0, None)
    H = hh[:, None]
    t1, x1, p1 = _rhs(X, P, a)
    t2, x2, p2 = _rhs(X + 0.5 * H * x1, P + _pad(0.5 * H * p1), a)
    t3, x3, p3 = _rhs(X + 0.5 * H * x2, P + _pad(0.5 * H * p2), a)
    t4, x4, p4 = _rhs(X + H * x3, P + _pad(H * p3), a)
    Xn = X + H / 6 * (x1 + 2 * x2 + 2 * x3 + x4)
    Pn = P + _pad(H / 6 * (p1 + 2 * p2 + 2 * p3 + p4))
    tn = t + hh / 6 * (t1 + 2 * t2 + 2 * t3 + t4)
    return Xn, Pn, tn


def _pad(dp):
    """spatial momentum increment -> 4-momentum increment (p_t is conserved)."""
    return np.column_stack([np.zeros(len(dp)), dp])


def static_tetrad(X, a, observer="static"):
    """Orthonormal tetrad at X (n,3): e[n, 4(index a), 4(mu)] (upper mu).

    observer="static": u along the Killing vector d/dt (emitters; outside the ergosphere).
    observer="normal": u normal to the t_KS = const slices (defined down to the horizon);
    used only to parametrise ray directions when shooting towards the observer."""
    g = g_lower(X, a)
    n = len(X)
    e = np.zeros((n, 4, 4))
    gtt = g[:, 0, 0]
    if observer == "static":
        if np.any(gtt >= 0):
            raise ValueError("static observer inside the ergosphere")
        e[:, 0, 0] = 1 / np.sqrt(-gtt)
    else:
        # zero-angular-momentum observer: u_mu proportional to -grad t_BL,
        # t_BL = t_KS - G(r), G'(r) = 2r/Delta (defined outside the horizon)
        gi = np.linalg.inv(g)
        r = bl_r(X[:, 0], X[:, 1], X[:, 2], a)
        Dl = r * r - 2 * r + a * a
        h = 1e-6 * np.maximum(r, 1.0)
        dr = np.column_stack([(bl_r(*(X + h[:, None] * np.eye(3)[i]).T, a) -
                               bl_r(*(X - h[:, None] * np.eye(3)[i]).T, a)) / (2 * h) for i in range(3)])
        ul = np.column_stack([-np.ones(n), (2 * r / Dl)[:, None] * dr])
        uu = np.einsum("nij,nj->ni", gi, ul)
        nrm = np.sqrt(-np.einsum("ni,nij,nj->n", uu, g, uu))
        e[:, 0] = uu / nrm[:, None]
    basis = [np.array([0, 1.0, 0, 0]), np.array([0, 0, 1.0, 0]), np.array([0, 0, 0, 1.0])]
    for j, v in enumerate(basis, start=1):
        w = np.tile(v, (n, 1))
        for i in range(j):
            ip = np.einsum("ni,nij,nj->n", w, g, e[:, i])
            sgn = -1.0 if i == 0 else 1.0
            w = w - (sgn * ip)[:, None] * e[:, i]
        nrm = np.sqrt(np.einsum("ni,nij,nj->n", w, g, w))
        e[:, j] = w / nrm[:, None]
    return e, g


def initial_momenta(x0, nloc, a, observer="static"):
    """Covariant momenta of photons leaving x0 with local directions nloc (m,3)."""
    X = np.repeat(np.asarray(x0, float)[None], len(nloc), 0)
    e, g = static_tetrad(X[:1], a, observer)
    pu = e[0, 0][None] + nloc @ e[0, 1:]                  # p^mu (E_loc = 1)
    pl = pu @ g[0]                                        # p_mu
    return X, pl


def trace_to_disc_kerr(x0, a, n_rays=20000, r_in=None, r_out=100.0, eta=0.01, max_steps=40000):
    r_in = r_isco(a) if r_in is None else r_in
    rh = r_horizon(a)
    nloc = fibonacci_sphere(n_rays)
    X, P = initial_momenta(x0, nloc, a)
    t = np.zeros(n_rays)
    act = np.arange(n_rays)
    z0 = X[:, 2].copy()
    if abs(x0[2]) < 1e-9:
        z0 = np.full(n_rays, 1e-9)
    hr, hp, ht, hidx = [], [], [], []
    n_esc = n_cap = 0
    for _ in range(max_steps):
        if act.size == 0:
            break
        Xn, Pn, tn = _step(X, P, t, a, eta)
        zc = Xn[:, 2]
        cross = np.sign(zc) != np.sign(z0)
        hit = np.zeros(act.size, bool)
        if cross.any():
            ci = np.where(cross)[0]
            fr = z0[ci] / (z0[ci] - zc[ci])
            xc = X[ci] + fr[:, None] * (Xn[ci] - X[ci])
            rc = bl_r(xc[:, 0], xc[:, 1], 0 * xc[:, 2], a)
            ok = (rc >= r_in) & (rc <= r_out)
            if ok.any():
                k = ci[ok]
                hr.append(rc[ok]); hp.append(np.arctan2(xc[ok, 1], xc[ok, 0]))
                ht.append(t[k] + fr[ok] * (tn[k] - t[k])); hidx.append(act[k])
                hit[k] = True
        rn = bl_r(Xn[:, 0], Xn[:, 1], Xn[:, 2], a)
        cap = (rn < rh + 0.02) & ~hit
        esc = (rn > R_ESC) & ~hit & ~cap
        n_cap += int(cap.sum()); n_esc += int(esc.sum())
        keep = ~(hit | cap | esc)
        X, P, t, act = Xn[keep], Pn[keep], tn[keep], act[keep]
        z0 = np.where(zc[keep] == 0, 1e-12, zc[keep])
    n_esc += act.size
    cat = lambda L: np.concatenate(L) if L else np.zeros(0)
    return dict(r=cat(hr), phi=cat(hp), t=cat(ht), n_rays=n_rays, n_hit=sum(len(v) for v in hr),
                n_esc=n_esc, n_cap=n_cap)


def _shoot(Pts, dirs, a, eta, r_far=None, grow=None):
    """Integrate one ray per point with coordinate-ish initial local direction dirs (n,3)."""
    n = len(Pts)
    r_far = R_FAR if r_far is None else r_far
    grow = _GROW[0] if grow is None else grow
    X = Pts.copy(); P = np.zeros((n, 4))
    uq, inv = np.unique(np.round(Pts, 12), axis=0, return_inverse=True)
    inv = np.ravel(inv)
    for q in range(len(uq)):                 # one tetrad per distinct emission point
        jj = np.where(inv == q)[0]
        _, pl = initial_momenta(Pts[jj[0]], dirs[jj], a, "zamo")
        P[jj] = pl
    t = np.zeros(n)
    out_dir = np.full((n, 3), np.nan); T = np.full(n, np.nan); dead = np.zeros(n, bool)
    act = np.arange(n)
    rh = r_horizon(a)
    r = bl_r(X[:, 0], X[:, 1], X[:, 2], a)
    for _ in range(60000):
        if act.size == 0:
            break
        # weak field far out: relative step grows to 0.1 (RK4 error negligible there)
        X, P, t = _step(X, P, t, a, eta * np.clip(r / 20.0, 1.0, 0.1 / eta) if grow else eta)
        r = bl_r(X[:, 0], X[:, 1], X[:, 2], a)
        cap = r < rh + 0.02
        fin = r > r_far
        if cap.any():
            dead[act[cap]] = True
        if fin.any():
            k = act[fin]
            dx = _rhs(X[fin], P[fin], a)[1]
            d = dx / np.linalg.norm(dx, axis=1)[:, None]
            out_dir[k] = d
            T[k] = t[fin] - X[fin] @ _NH[0] - CLOG * np.log(r[fin])
        keep = ~(cap | fin)
        X, P, t, act, r = X[keep], P[keep], t[keep], act[keep], r[keep]
    return out_dir, T, dead


_NH = [None]
_GROW = [True]


def observer_delay_kerr(Pts, incl_deg, a, eta=0.004, n_iter=12, n_alt=4):
    """T(x) for points Pts (n,3) towards an observer at inclination incl (x-z plane).

    Shooting: find the local direction whose photon reaches infinity along n_hat (Newton on
    a 2-D exponential-map parametrisation, backtracking line search).  Points whose direct
    guess fails (behind the hole) are solved from several starts (cone scan and a dense
    Fibonacci scan, starts at least 0.5 rad apart); among the converged solutions the
    earliest arrival is kept: that is the primary image (higher-order images loop around
    the hole and arrive later)."""
    th = np.radians(incl_deg)
    nh = np.array([np.sin(th), 0.0, np.cos(th)])
    _NH[0] = nh
    Pts = np.atleast_2d(np.asarray(Pts, float))
    n = len(Pts)
    _e1 = np.cross(nh, [0, 1.0, 0]); _e1 /= np.linalg.norm(_e1)
    _e2 = np.cross(nh, _e1)

    def dirs_of(u):
        t_ = np.linalg.norm(u, axis=1)
        c = np.where(t_ > 1e-12, np.sin(t_) / np.maximum(t_, 1e-12), 1.0)
        d = np.cos(t_)[:, None] * nh[None] + (c * u[:, 0])[:, None] * _e1[None] + (c * u[:, 1])[:, None] * _e2[None]
        return d / np.linalg.norm(d, axis=1)[:, None]

    def logmap(d):
        c1, c2 = d @ _e1, d @ _e2
        t_ = np.arccos(np.clip(d @ nh, -1, 1))
        s_ = np.hypot(c1, c2)
        f = np.where(s_ > 1e-12, t_ / np.maximum(s_, 1e-12), 1.0)
        return np.column_stack([f * c1, f * c2])

    def errs(P_, u_, rf=None):
        d_, T_, dd_ = _shoot(P_, dirs_of(u_), a, eta, rf)
        e_ = logmap(d_)
        en = np.where(dd_, np.inf, np.nan_to_num(np.linalg.norm(e_, axis=1), nan=np.inf))
        return e_, en, T_

    RF = 2000.0                               # Newton iterations; final T at R_FAR

    def newton(P_, u_):
        u_ = u_.copy()
        m = len(P_)
        for _it in range(n_iter):
            e_, en, _ = errs(P_, u_, RF)
            if np.max(np.where(np.isfinite(en), en, 0)) < 1e-7 and np.isfinite(en).all():
                break
            h = 1e-4
            J = np.zeros((m, 2, 2))
            for c in range(2):
                du = np.zeros((m, 2)); du[:, c] = h
                e1_, _, _ = errs(P_, u_ + du, RF)
                J[:, :, c] = (e1_ - e_) / h
            with np.errstate(all="ignore"):
                step = np.linalg.solve(J + 1e-12 * np.eye(2)[None], -np.nan_to_num(e_)[:, :, None])[:, :, 0]
            step = np.clip(np.nan_to_num(step), -0.5, 0.5)
            todo = np.arange(m); fac = 1.0
            for _bt in range(6):
                ut = u_[todo] + fac * step[todo]
                _, et_, _ = errs(P_[todo], ut, RF)
                acc = (et_ < en[todo]) | ~np.isfinite(en[todo])
                u_[todo[acc]] = ut[acc]
                todo = todo[~acc]
                if todo.size == 0:
                    break
                fac *= 0.5
        _, en, T_ = errs(P_, u_)
        return u_, en, T_

    # 1) direct start (towards the observer) for every point
    u = np.zeros((n, 2))
    _, e0, _ = errs(Pts, u, 300.0)
    u, res, T0 = newton(Pts, u)
    # 2) multi-start for points whose direct guess was poor (photon must bend strongly)
    hard = np.where(e0 > 0.2)[0]
    if hard.size:
        from .raytrace import fibonacci_sphere
        cand = np.array([(t_ * np.cos(p_), t_ * np.sin(p_)) for t_ in (0.4, 0.9, 1.4, 1.9, 2.4, 2.9)
                         for p_ in np.linspace(0, 2 * np.pi, 12, endpoint=False)])
        cand = np.vstack([cand, logmap(fibonacci_sphere(200))])
        Ph = Pts[hard]
        E = np.full((hard.size, len(cand)), np.inf)
        for c in range(len(cand)):
            pass
        # all candidates of all hard points in one integration (stopped at r = 300)
        Pall = np.repeat(Ph, len(cand), 0)
        Uall = np.tile(cand, (hard.size, 1))
        _, Eall, _ = errs(Pall, Uall, 300.0)
        E = Eall.reshape(hard.size, len(cand))
        starts = []
        for j in range(hard.size):
            order = np.argsort(E[j]); sel = []
            for c in order:
                if not np.isfinite(E[j, c]) or len(sel) >= n_alt:
                    break
                if all(np.linalg.norm(cand[c] - cand[s_]) > 0.5 for s_ in sel):
                    sel.append(c)
            starts.append(sel)
        for k in range(n_alt):
            jj = np.array([j for j in range(hard.size) if len(starts[j]) > k], int)
            if jj.size == 0:
                break
            uk = np.array([cand[starts[j][k]] for j in jj])
            uk, rk, Tk = newton(Ph[jj], uk)
            idx = hard[jj]
            ok_new = rk < 5e-3
            ok_old = res[idx] < 5e-3
            take = ok_new & (~ok_old | (Tk < T0[idx]))
            u[idx[take]], res[idx[take]], T0[idx[take]] = uk[take], rk[take], Tk[take]
    bad = ~np.isfinite(res) | np.isnan(T0) | (res > 1e-2)
    if bad.any():
        print(f"    observer_delay_kerr: {int(bad.sum())} of {n} points unresolved "
              f"(max angular error {np.nanmax(np.where(np.isfinite(res), res, np.nan)):.2g} rad); "
              f"their T is interpolated from neighbours", flush=True)
        good = ~bad
        if good.sum() >= 3:
            from scipy.interpolate import NearestNDInterpolator
            T0[bad] = NearestNDInterpolator(Pts[good], T0[good])(Pts[bad])
    return T0


def _cache(tag):
    from . import config as C
    d = os.path.join(C.WORK, "cache"); os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"kerr_{hashlib.md5(tag.encode()).hexdigest()[:12]}.npz")


def _trace_task(args):
    x0, a, n_rays, r0, r1 = args
    return trace_to_disc_kerr(np.asarray(x0), a, n_rays, r0, r1)


def disc_response_kerr(grid, disc, a, n_rays=20000, verbose=True, n_jobs=None):
    """Omega (N_c,N_d), mean t_SP (N_c,N_d), escape E (N_c,), valid mask (static allowed)."""
    import multiprocessing as mp
    rc = disc.R[::disc.n_phi]
    q = np.sqrt(rc[1] / rc[0])
    r_e = np.r_[rc / q, rc[-1] * q]
    p_e = np.linspace(0, 2 * np.pi, disc.n_phi + 1)
    tag = (f"resp|{a}|{np.round(grid.r_edges,6).tolist()}|{np.round(grid.z_edges,6).tolist()}|"
           f"{grid.n_phi}|{np.round(r_e,6).tolist()}|{disc.n_phi}|{n_rays}")
    cp = _cache(tag)
    if os.path.exists(cp):
        z = np.load(cp)
        return z["Omega"], z["tsp"], z["E"], z["valid"]
    nc, nd = grid.n_cells, disc.n_elements
    Om, TS, E = np.zeros((nc, nd)), np.zeros((nc, nd)), np.zeros(nc)
    valid = np.ones(nc, bool)
    tasks, idx = [], []
    for ir in range(grid.n_r):
        for iz in range(grid.n_z):
            i0 = ir * grid.n_z * grid.n_phi + iz * grid.n_phi
            x0 = np.array([grid.R[i0], 0.0, grid.z[i0]])
            g = g_lower(x0[None], a)
            if g[0, 0, 0] >= -2e-2 or bl_r(*x0, a) < r_horizon(a) + 0.1:
                valid[i0:i0 + grid.n_phi] = False
                E[i0:i0 + grid.n_phi] = 4 * np.pi
                continue
            tasks.append((x0, a, n_rays, r_e[0], r_e[-1])); idx.append(i0)
    with mp.get_context("fork").Pool(n_jobs or os.cpu_count()) as pool:
        results = pool.map(_trace_task, tasks, chunksize=1)
    for i0, res in zip(idx, results):
        for ip in range(grid.n_phi):
            i = i0 + ip
            ph = np.mod(res["phi"] + grid.phi[i], 2 * np.pi)
            jr = np.clip(np.searchsorted(r_e, res["r"]) - 1, 0, disc.n_r - 1)
            jp = np.clip(np.searchsorted(p_e, ph) - 1, 0, disc.n_phi - 1)
            k = jr * disc.n_phi + jp
            cnt = np.bincount(k, minlength=nd).astype(float)
            Om[i] = 4 * np.pi * cnt / n_rays
            TS[i] = np.where(cnt > 0, np.bincount(k, weights=res["t"], minlength=nd) / np.maximum(cnt, 1), 0)
            E[i] = 4 * np.pi * res["n_esc"] / n_rays
        if verbose:
            print(f"    Kerr a={a}: (R,z)=({grid.R[i0]:.2f},{grid.z[i0]:.2f}) hit "
                  f"{res['n_hit']/n_rays:.3f} esc {res['n_esc']/n_rays:.3f} cap {res['n_cap']/n_rays:.3f}",
                  flush=True)
    np.savez(cp, Omega=Om, tsp=TS, E=E, valid=valid)
    return Om, TS, E, valid


def disc_points_ks(disc, a):
    """Kerr-Schild Cartesian positions of the disc elements (BL radius, KS azimuth)."""
    rho = np.sqrt(disc.R ** 2 + a * a)
    return np.column_stack([rho * np.cos(disc.phi), rho * np.sin(disc.phi), 0 * rho])


def _T_task(args):
    P, incl, a = args
    return observer_delay_kerr(P, incl, a)


def observer_delays_kerr_cached(P, incl, a, n_jobs=None):
    import multiprocessing as mp
    P = np.atleast_2d(np.asarray(P, float))
    tag = f"T2|{hashlib.md5(np.round(P,6).tobytes()).hexdigest()}|{incl}|{a}"
    cp = _cache(tag)
    if os.path.exists(cp):
        return np.load(cp)["T"]
    nj = n_jobs or os.cpu_count()
    # interleaved chunks: the hard points (behind the hole) are spread over the workers
    chunks = [c for c in (np.arange(i, len(P), nj) for i in range(nj)) if len(c)]
    with mp.get_context("fork").Pool(nj) as pool:
        parts = pool.map(_T_task, [(P[c], incl, a) for c in chunks])
    T = np.empty(len(P))
    for c, t_ in zip(chunks, parts):
        T[c] = t_
    np.savez(cp, T=T)
    return T


def point_response_kerr(h_values, disc, a, n_rays=20000, n_jobs=None):
    import multiprocessing as mp
    h_values = np.asarray(h_values, float)
    rc = disc.R[::disc.n_phi]
    q = np.sqrt(rc[1] / rc[0])
    r_e = np.r_[rc / q, rc[-1] * q]
    p_e = np.linspace(0, 2 * np.pi, disc.n_phi + 1)
    tag = f"lp|{a}|{np.round(h_values,6).tolist()}|{np.round(r_e,6).tolist()}|{disc.n_phi}|{n_rays}"
    cp = _cache(tag)
    if os.path.exists(cp):
        z = np.load(cp)
        return z["Omega"], z["tsp"], z["E"]
    nd = disc.n_elements
    with mp.get_context("fork").Pool(n_jobs or os.cpu_count()) as pool:
        results = pool.map(_trace_task, [(np.array([0, 0, h]), a, n_rays, r_e[0], r_e[-1])
                                         for h in h_values], chunksize=1)
    Om, TS, E = np.zeros((len(h_values), nd)), np.zeros((len(h_values), nd)), np.zeros(len(h_values))
    for j, res in enumerate(results):
        ph = np.mod(res["phi"], 2 * np.pi)
        jr = np.clip(np.searchsorted(r_e, res["r"]) - 1, 0, disc.n_r - 1)
        jp = np.clip(np.searchsorted(p_e, ph) - 1, 0, disc.n_phi - 1)
        k = jr * disc.n_phi + jp
        cnt = np.bincount(k, minlength=nd).astype(float)
        Om[j] = 4 * np.pi * cnt / n_rays
        TS[j] = np.where(cnt > 0, np.bincount(k, weights=res["t"], minlength=nd) / np.maximum(cnt, 1), 0)
        E[j] = 4 * np.pi * res["n_esc"] / n_rays
    np.savez(cp, Omega=Om, tsp=TS, E=E)
    return Om, TS, E


def image_plane_disc(incl_deg, a, disc, D=1.0e3, n_b=160, n_ang=180, b_min=0.3, b_max=125.0,
                     eta=0.01, max_steps=40000):
    """Backward ray tracing from a distant observer (image-plane polar grid).

    Rays start at X0 = D n_hat + alpha e1 + beta e2 with the momentum of a photon moving
    towards the observer and are integrated backwards in the affine parameter until they
    first cross z = 0 inside the disc.  For each disc element returns the mean
    T = -t_cross - D - CLOG ln|X0| (same convention as observer_delay_kerr), the mean
    redshift g = E_obs/E_em of a Keplerian disc (for energy-resolved transfer) and the
    number of image rays (for averaging); elements never hit get NaN."""
    th = np.radians(incl_deg)
    nh = np.array([np.sin(th), 0.0, np.cos(th)])
    e1 = np.cross(nh, [0, 1.0, 0]); e1 /= np.linalg.norm(e1)
    e2 = np.cross(nh, e1)
    b = np.geomspace(b_min, b_max, n_b)
    ang = np.linspace(0, 2 * np.pi, n_ang, endpoint=False)
    B, A = np.meshgrid(b, ang, indexing="ij")
    al, be = (B * np.cos(A)).ravel(), (B * np.sin(A)).ravel()
    # solid-angle weight on the sky ~ b db dang
    wgt = (B * np.gradient(b)[:, None] * (2 * np.pi / n_ang)).ravel()
    X = D * nh[None] + al[:, None] * e1[None] + be[:, None] * e2[None]
    n = len(X)
    # photon moving along +n_hat, E = 1: p_i = +n_hat (flat asymptotics), p_t from H = 0
    P = np.zeros((n, 4)); P[:, 1:] = nh[None]
    f, k, r = _fk(X, a)
    kp_s = np.einsum("ij,ij->i", k, P[:, 1:])
    # 2H = -pt^2 + |p|^2 - f (-pt + k.p)^2 = 0  -> quadratic in pt
    A2 = -1 - f; B2 = 2 * f * kp_s; C2 = 1 - f * kp_s ** 2
    disc_ = B2 * B2 - 4 * A2 * C2
    P[:, 0] = (-B2 + np.sqrt(disc_)) / (2 * A2)          # root with p_t < 0 (E > 0)
    t = np.zeros(n)
    z0 = X[:, 2].copy()
    act = np.arange(n)
    rh = r_horizon(a)
    rc = disc.R[::disc.n_phi]; q = np.sqrt(rc[1] / rc[0])
    r_e = np.r_[rc / q, rc[-1] * q]
    p_e = np.linspace(0, 2 * np.pi, disc.n_phi + 1)
    nd = disc.n_elements
    sT, sg, sw, sgw = np.zeros(nd), np.zeros(nd), np.zeros(nd), np.zeros(nd)
    T0 = -D - CLOG * np.log(np.linalg.norm(X, axis=1))
    for _ in range(max_steps):
        if act.size == 0:
            break
        Xn, Pn, tn = _step(X, P, t, a, -eta)            # backwards in lambda
        zc = Xn[:, 2]
        cross = (np.sign(zc) != np.sign(z0))
        hit = np.zeros(act.size, bool)
        if cross.any():
            ci = np.where(cross)[0]
            fr = z0[ci] / (z0[ci] - zc[ci])
            xc = X[ci] + fr[:, None] * (Xn[ci] - X[ci])
            rr = bl_r(xc[:, 0], xc[:, 1], 0 * xc[:, 2], a)
            ok = (rr >= r_e[0]) & (rr <= r_e[-1])
            if ok.any():
                kk = ci[ok]
                tc = t[kk] + fr[ok] * (tn[kk] - t[kk])
                ph = np.mod(np.arctan2(xc[ok, 1], xc[ok, 0]), 2 * np.pi)
                jr = np.clip(np.searchsorted(r_e, rr[ok]) - 1, 0, disc.n_r - 1)
                jp = np.clip(np.searchsorted(p_e, ph) - 1, 0, disc.n_phi - 1)
                el = jr * disc.n_phi + jp
                # redshift of a prograde Keplerian disc: g = 1/(u^t (1 - Omega lambda)),
                # lambda = -p_phi/p_t, p_phi = x p_y - y p_x (Killing vector d/dphi)
                rrk = rr[ok]
                Om = 1 / (rrk ** 1.5 + a)
                ut = (rrk ** 1.5 + a) / (rrk ** 0.75 * np.sqrt(rrk ** 1.5 - 3 * rrk ** 0.5 + 2 * a))
                pphi = xc[ok, 0] * P[kk, 2] - xc[ok, 1] * P[kk, 1]
                lam = -pphi / P[kk, 0]
                g = 1 / (ut * (1 - Om * lam))
                wk = wgt[act[kk]]
                Tk = -tc + T0[act[kk]]
                gok = np.isfinite(g) & (g > 0) & (g < 5)          # drop numerically bad rays
                np.add.at(sT, el, wk * Tk); np.add.at(sw, el, wk)
                np.add.at(sg, el[gok], (wk * g)[gok]); np.add.at(sgw, el[gok], wk[gok])
                hit[kk] = True
        rn = bl_r(Xn[:, 0], Xn[:, 1], Xn[:, 2], a)
        done = hit | (rn < rh + 0.02) | (rn > 1.5 * D)
        keep = ~done
        X, P, t, act = Xn[keep], Pn[keep], tn[keep], act[keep]
        z0 = np.where(zc[keep] == 0, 1e-12, zc[keep])
    with np.errstate(invalid="ignore", divide="ignore"):
        return sT / sw, sg / sgw, sw


def disc_T_kerr_cached(disc, incl, a):
    tag = f"imgT2|{incl}|{a}|{np.round(disc.R,6).tobytes().hex()[:64]}|{disc.n_r}|{disc.n_phi}"
    cp = _cache(tag)
    if os.path.exists(cp):
        z = np.load(cp)
        return z["T"], z["g"], z["w"]
    T, g, w = image_plane_disc(incl, a, disc)
    # elements not hit by any image ray (hidden from the observer): nearest-neighbour T
    bad = ~np.isfinite(T)
    if bad.any():
        from scipy.interpolate import NearestNDInterpolator
        P = disc_points_ks(disc, a)
        T[bad] = NearestNDInterpolator(P[~bad], T[~bad])(P[bad])
        g[bad] = NearestNDInterpolator(P[~bad], g[~bad])(P[bad])
    np.savez(cp, T=T, g=g, w=w)
    return T, g, w
