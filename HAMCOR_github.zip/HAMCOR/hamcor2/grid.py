"""
Coronal and disc grids (self-contained; identical construction to
qcorona.geometry.grid so that results are directly comparable).

Units: lengths in r_g = GM/c^2.

Cell ordering: flat index  i = ir * n_z * n_phi + iz * n_phi + iphi.
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass


@dataclass
class CoronalGrid:
    R: np.ndarray
    z: np.ndarray
    phi: np.ndarray
    n_r: int
    n_z: int
    n_phi: int
    r_edges: np.ndarray
    z_edges: np.ndarray
    pairs: np.ndarray          # (N_pairs, 2) unique nearest-neighbour pairs <i,j>

    @property
    def n_cells(self) -> int:
        return self.n_r * self.n_z * self.n_phi

    @property
    def x(self):
        return self.R * np.cos(self.phi)

    @property
    def y(self):
        return self.R * np.sin(self.phi)

    def get_cartesian(self) -> np.ndarray:
        return np.column_stack([self.x, self.y, self.z])

    @property
    def R_centers(self):
        return np.sqrt(self.r_edges[:-1] * self.r_edges[1:])

    @property
    def z_centers(self):
        return np.sqrt(self.z_edges[:-1] * self.z_edges[1:])

    def rz_map(self, w: np.ndarray) -> np.ndarray:
        """Azimuthally summed emissivity, shape (n_r, n_z)."""
        return w.reshape(self.n_r, self.n_z, self.n_phi).sum(axis=2)


@dataclass
class DiscGrid:
    R: np.ndarray
    phi: np.ndarray
    areas: np.ndarray
    n_r: int
    n_phi: int

    @property
    def n_elements(self) -> int:
        return self.n_r * self.n_phi

    def get_cartesian(self) -> np.ndarray:
        return np.column_stack([self.R * np.cos(self.phi),
                                self.R * np.sin(self.phi),
                                np.zeros_like(self.R)])


def _neighbour_pairs(n_r, n_z, n_phi) -> np.ndarray:
    idx = np.arange(n_r * n_z * n_phi).reshape(n_r, n_z, n_phi)
    p = [np.stack([idx[:-1].ravel(), idx[1:].ravel()], 1),            # R
         np.stack([idx[:, :-1].ravel(), idx[:, 1:].ravel()], 1)]      # z
    if n_phi > 2:
        p.append(np.stack([idx.ravel(), np.roll(idx, -1, axis=2).ravel()], 1))
    elif n_phi == 2:
        p.append(np.stack([idx[..., 0].ravel(), idx[..., 1].ravel()], 1))
    return np.concatenate(p, 0)


def build_grid(r_in=3.0, r_out=30.0, z_min=0.1, z_max=20.0,
               n_r=10, n_z=10, n_phi=8) -> CoronalGrid:
    r_e = np.logspace(np.log10(r_in), np.log10(r_out), n_r + 1)
    z_e = np.logspace(np.log10(z_min), np.log10(z_max), n_z + 1)
    p_e = np.linspace(0, 2 * np.pi, n_phi + 1)
    rc = np.sqrt(r_e[:-1] * r_e[1:])
    zc = np.sqrt(z_e[:-1] * z_e[1:])
    pc = 0.5 * (p_e[:-1] + p_e[1:])
    R, Z, P = np.meshgrid(rc, zc, pc, indexing='ij')
    return CoronalGrid(R.ravel(), Z.ravel(), P.ravel(), n_r, n_z, n_phi,
                       r_e, z_e, _neighbour_pairs(n_r, n_z, n_phi))


def build_disc_grid(r_in=6.0, r_out=100.0, n_r=30, n_phi=18) -> DiscGrid:
    r_e = np.logspace(np.log10(r_in), np.log10(r_out), n_r + 1)
    p_e = np.linspace(0, 2 * np.pi, n_phi + 1)
    rc = np.sqrt(r_e[:-1] * r_e[1:])
    pc = 0.5 * (p_e[:-1] + p_e[1:])
    R, P = np.meshgrid(rc, pc, indexing='ij')
    dr = np.diff(r_e)[:, None] * np.ones((1, n_phi))
    dp = np.diff(p_e)[None, :] * np.ones((n_r, 1))
    areas = (R * dr * dp).ravel()
    return DiscGrid(R.ravel(), P.ravel(), areas, n_r, n_phi)


def solid_angles(grid: CoronalGrid, disc: DiscGrid) -> np.ndarray:
    """Omega_ik = |cos theta_ik| dA_k / d_ik^2   (N_c, N_d), flat space."""
    d = disc.get_cartesian()[None, :, :] - grid.get_cartesian()[:, None, :]
    d2 = np.sum(d * d, axis=2)
    return np.abs(d[:, :, 2]) / np.sqrt(d2) * disc.areas[None, :] / d2
