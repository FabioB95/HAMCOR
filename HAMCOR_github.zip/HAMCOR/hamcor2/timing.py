"""
timing.py — cross-spectral lag estimators (Vaughan & Nowak 1997; Nowak et al. 1999;
Uttley et al. 2014, sect. 2).

Conventions
  * Non-overlapping segments of M bins (independent realisations), each end-matched
    (Fougere 1985): the straight line joining the first and last points is removed
    before the FFT. This suppresses red-noise leakage, which otherwise biases lags
    low by ~15 per cent for steep power spectra (tested in s00_tests.py).
  * Cross spectrum C = < H~* S~ >, averaged over K Fourier frequencies x M segments.
  * Lag-frequency: tau = arg C / (2 pi f): negative => soft lags hard (paper eq. 7).
  * sigma_phi = sqrt[(1 - g2_raw) / (2 g2_raw K M)] with the raw (noise-inclusive)
    coherence g2_raw = |C|^2 / (P_s P_h)  (Bendat & Piersol 2010; Uttley+2014 eq. 18).
  * Intrinsic coherence with Poisson-noise bias correction (Vaughan & Nowak 1997).
  * Lag-energy: channel of interest vs reference = all other channels;
    sign convention for lag-energy: positive => channel lags the reference.
"""
from __future__ import annotations

import numpy as np
from dataclasses import dataclass, asdict


def find_segments(time, valid, dt, seg_len):
    """Start indices of non-overlapping segments of seg_len contiguous valid bins."""
    t = np.asarray(time)
    ok = np.asarray(valid, bool)
    gap = np.ones_like(ok)
    gap[1:] = np.abs(np.diff(t) - dt) > 1e-3 * dt
    starts, i, n = [], 0, len(t)
    while i < n:
        if not ok[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and ok[j + 1] and not gap[j + 1]:
            j += 1
        run = j - i + 1
        for m in range(run // seg_len):
            starts.append(i + m * seg_len)
        i = j + 1
    return np.array(starts, int)


def _ffts(x, err, starts, seg_len):
    X, N = [], []
    ramp = np.arange(seg_len) / (seg_len - 1)
    for s0 in starts:
        seg = x[s0:s0 + seg_len]
        seg = seg - (seg[0] + (seg[-1] - seg[0]) * ramp)
        X.append(np.fft.rfft(seg - seg.mean())[1:])
        N.append(np.sum(err[s0:s0 + seg_len] ** 2))
    return np.array(X), np.array(N)


@dataclass
class CrossResult:
    f: np.ndarray
    f_lo: np.ndarray
    f_hi: np.ndarray
    tau: np.ndarray
    sig_tau: np.ndarray
    phase: np.ndarray
    g2_raw: np.ndarray
    g2_int: np.ndarray
    n_avg: np.ndarray
    n_seg: int
    fk: np.ndarray = None        # Fourier frequencies used (all bins)
    pk: np.ndarray = None        # noise-subtracted hard-band power at fk (model weights)
    bin_k: np.ndarray = None     # bin index of each fk

    def as_dict(self):
        return {k: (v.tolist() if isinstance(v, np.ndarray) else v)
                for k, v in asdict(self).items()}


def _bin_stats(S, H, Ns, Nh, freqs, masks):
    out = {k: [] for k in ("f", "tau", "sig", "ph", "g2r", "g2i", "n")}
    M = S.shape[0]
    for m in masks:
        K = int(m.sum())
        if K == 0:
            for k in out:
                out[k].append(np.nan)
            continue
        n = K * M
        C = np.mean(np.conj(H[:, m]) * S[:, m])
        Ps = np.mean(np.abs(S[:, m]) ** 2)
        Ph = np.mean(np.abs(H[:, m]) ** 2)
        ns, nh = np.mean(Ns), np.mean(Nh)
        g2r = np.abs(C) ** 2 / (Ps * Ph)
        nb2 = (Ps * nh + Ph * ns - ns * nh) / n
        g2i = (np.abs(C) ** 2 - nb2) / ((Ps - ns) * (Ph - nh))
        fc = np.mean(freqs[m])
        ph = np.angle(C)
        sp = np.sqrt((1 - min(g2r, 0.999999)) / (2 * g2r * n))
        out["f"].append(fc); out["ph"].append(ph)
        out["tau"].append(ph / (2 * np.pi * fc)); out["sig"].append(sp / (2 * np.pi * fc))
        out["g2r"].append(g2r); out["g2i"].append(g2i); out["n"].append(n)
    return {k: np.array(v, float) for k, v in out.items()}


def lag_frequency(time, s, s_err, h, h_err, dt, seg_len, f_edges):
    valid = np.isfinite(s) & np.isfinite(h) & np.isfinite(s_err) & np.isfinite(h_err)
    starts = find_segments(time, valid, dt, seg_len)
    if len(starts) == 0:
        raise RuntimeError("no complete segments: reduce seg_len")
    S, Ns = _ffts(s, s_err, starts, seg_len)
    H, Nh = _ffts(h, h_err, starts, seg_len)
    freqs = np.fft.rfftfreq(seg_len, dt)[1:]
    masks = [(freqs >= lo) & (freqs < hi) for lo, hi in zip(f_edges[:-1], f_edges[1:])]
    b = _bin_stats(S, H, Ns, Nh, freqs, masks)
    Ph = np.mean(np.abs(H) ** 2, axis=0) - np.mean(Nh)
    Ph = np.maximum(Ph, 1e-3 * Ph.max())
    fk, pk, bk = [], [], []
    for j, m in enumerate(masks):
        fk.append(freqs[m]); pk.append(Ph[m]); bk.append(np.full(m.sum(), j))
    return CrossResult(b["f"], np.array(f_edges[:-1]), np.array(f_edges[1:]), b["tau"],
                       b["sig"], b["ph"], b["g2r"], b["g2i"], b["n"], len(starts),
                       np.concatenate(fk), np.concatenate(pk),
                       np.concatenate(bk)), freqs


def band_lag(time, s, s_err, h, h_err, dt, seg_len, f_lo, f_hi):
    r, _ = lag_frequency(time, s, s_err, h, h_err, dt, seg_len, np.array([f_lo, f_hi]))
    return r


def lag_energy(time, rates, errs, dt, seg_len, f_lo, f_hi):
    """
    rates, errs: (N_E, N_t). Returns per-channel lag (positive = lags reference),
    error, raw coherence, band-mean frequency and the Fourier frequencies used.
    """
    rates, errs = np.asarray(rates), np.asarray(errs)
    valid = np.all(np.isfinite(rates), 0) & np.all(np.isfinite(errs), 0)
    starts = find_segments(time, valid, dt, seg_len)
    freqs = np.fft.rfftfreq(seg_len, dt)[1:]
    m = (freqs >= f_lo) & (freqs < f_hi)
    tot, tot_e2 = rates.sum(0), (errs ** 2).sum(0)
    lag, sig, g2 = [], [], []
    for k in range(rates.shape[0]):
        ref = tot - rates[k]
        ref_e = np.sqrt(np.maximum(tot_e2 - errs[k] ** 2, 0))
        X, Nx = _ffts(rates[k], errs[k], starts, seg_len)
        R, Nr = _ffts(ref, ref_e, starts, seg_len)
        b = _bin_stats(X, R, Nx, Nr, freqs, [m])
        lag.append(-b["tau"][0]); sig.append(b["sig"][0]); g2.append(b["g2r"][0])
    R, Nr = _ffts(tot, np.sqrt(tot_e2), starts, seg_len)
    pw = np.maximum(np.mean(np.abs(R[:, m]) ** 2, 0) - np.mean(Nr), 0) + 1e-30
    return dict(lag=np.array(lag), sig=np.array(sig), g2_raw=np.array(g2),
                f_mean=float(freqs[m].mean()), freqs=freqs[m], weights=pw,
                n_seg=len(starts))
