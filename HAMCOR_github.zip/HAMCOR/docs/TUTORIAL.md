# HAMCOR tutorial

This tutorial goes from a synthetic corona to a full real-data analysis. Parts 1–5 need only
Python; parts 6–8 need SAS and XSPEC. Lengths are in units of r_g = GM/c², times in
r_g/c, frequencies as ν·t_g unless stated otherwise.

```python
import numpy as np
from hamcor2 import build_grid, build_disc_grid, ForwardModel, PointSourceModel, OptConfig
```

---

## 1. Grids

```python
grid = build_grid(r_in=3.0, r_out=30.0, z_min=0.1, z_max=20.0, n_r=10, n_z=10, n_phi=8)
disc = build_disc_grid(r_in=6.0, r_out=100.0, n_r=30, n_phi=18)
grid.n_cells, disc.n_elements            # 800, 540
grid.R, grid.z, grid.phi                 # cell centres (flattened arrays)
```

The corona is a vector `w` of `grid.n_cells` non-negative weights summing to one. The disc is
geometrically thin, from the ISCO (6 r_g at a = 0) outwards.

## 2. Forward model

```python
fm = ForwardModel(grid, disc, incl_deg=45.0, metric="schwarzschild")
```

`metric` can be `"flat"`, `"weakfield"`, `"schwarzschild"` (exact ray tracing) or `"kerr"`
(with `spin=...`, see part 5). The first Schwarzschild/Kerr call traces the rays and caches
the tables in `cache/`; later calls are instantaneous.

The forward model provides, for each cell i and disc element k, the solid angle Ω_ik, the
delay L_ik of the reflected path relative to the direct one, and the escape fraction E_i:

```python
w = np.ones(grid.n_cells) / grid.n_cells
fm.illumination(w)        # I = photons hitting the disc / (hitting + escaping) = R_f/(1+R_f)
fm.mean_lag(w)            # illumination-weighted mean delay <t>  [r_g/c]
```

## 3. Lags through the estimator

Real lags are averages over Fourier frequencies inside each frequency bin, weighted by the
cross power, and are diluted by the continuum present in each band (reflected-to-continuum
count ratios R_s in the soft and R_h in the hard band). The model reproduces both:

```python
from hamcor2.synthetic import estimator_grid
nu, nu_k, p_k, bin_k = estimator_grid(np.geomspace(2e-3, 6e-2, 6))
tau = fm.lag_model_binned(w, nu_k, p_k, bin_k, nu, R_s=0.6, R_h=0.15)
```

At low frequency `tau → −D <t>` with `D = R_s/(1+R_s) − R_h/(1+R_h)`: the measured soft lag is
the mean delay times the dilution factor, which is why the reflection fractions are needed.

## 4. Synthetic recovery

```python
from hamcor2.synthetic import column, make_observables
from hamcor2.fitting import fit
from hamcor2.metrics import recovery_metrics, fisher_spectrum

w_true = column(grid, z_min=1.0, z_max=5.0, radius=5.0)
obs = make_observables(fm, w_true, np.geomspace(2e-3, 6e-2, 6), R_s=0.6, R_h=0.15, noise_seed=1)

w_rec, diag, _, _ = fit(fm, obs, J=1.0, n_starts=8, cfg=OptConfig(n_iter=2000))
print(diag["chi2_lag"], diag["R_c"], diag["z_c"])
print(recovery_metrics(grid, w_true, w_rec))       # centroid offset, correlations, parity
```

How many parameters do the data really constrain?

```python
_, dtau = fm.lag_model_binned(w_rec, obs.nu_k, obs.p_k, obs.bin_k, obs.nu, obs.R_s, obs.R_h, grad=True)
J = np.vstack([dtau.T, fm.illumination_grad(w_rec)[None]])
fisher_spectrum(J, np.r_[obs.sigma_total(), obs.sig_I])["N_eff"]     # typically 3-6
```

`N_eff` is the number of emissivity combinations measured better than the prior; the rest of
the map is the smoothest field compatible with the data (set by `J`, the coupling of the
smoothness prior). Robust outputs are therefore the centroid, the mean delay and the leading
Fisher modes, not the detailed map.

### The lamppost

```python
lp = PointSourceModel(disc, 45.0, "schwarzschild")
H = np.geomspace(2.5, 40.0, 40); lp.prepare(H)
W, L = lp.row(5.0)            # disc weights and delays of a point source at h = 5 r_g
lp.illumination(5.0)
```

`examples/quickstart.py` scans `h` and compares the two models with the AIC, penalising HAMCOR
by `N_eff` parameters.

## 5. Kerr spacetime and energy shifts

```python
from hamcor2.kerr import r_isco
a = 0.998
grid_k = build_grid(r_in=1.0, r_out=30.0, z_min=0.1, z_max=20.0)     # reach the inner region
disc_k = build_disc_grid(r_in=r_isco(a), r_out=100.0)                 # ISCO = 1.24 r_g
fm_k = ForwardModel(grid_k, disc_k, 45.0, "kerr", spin=a)            # ~30 min the first time
(~fm_k.invalid).sum()                                                 # cells outside the ergosphere
```

At a = 0.998 the maximum illumination fraction rises from 0.56 to 0.94: reflection fractions
R_f > 1.3 are reachable only around a spinning hole.

Energy-resolved transfer needs a rest-frame reflection spectrum (columns `E refl cont`,
produced by `scripts/s11_xillver_templates.py`):

```python
from hamcor2.energy import EnergyTransfer, LagEnergyTerm
et = EnergyTransfer(fm_k, "xillver_template.dat", E_lo, E_hi, R_E, R_ref, rates=rates)
tau_E = et.lag_energy_map(w, nu, nu_w, f_mean, mode="eres")   # or "visible", "grey"
```

`LagEnergyTerm` adds the lag-energy χ² (with a profiled offset) to the Hamiltonian for joint
fits: `obs.meta = {"le_term": LagEnergyTerm(et, nu, nu_w, f_mean, lag, sig)}` before `fit`.

## 6. Real data: from ODFs to lags

1. Put the ODFs in `data/raw/<obsid>.tar` and the source block in `config/sources.yaml`.
2. `python scripts/s01_sas_extract.py <key>` — runs `epproc`, flags flares, extracts source and
   background light curves in the soft, hard and 16 lag-energy bands (`epiclccorr`) and the
   pn spectrum; prints the header check and the exposures.
3. `python scripts/s02_lagfreq.py <key>` — interpolates short gaps, chooses the segment length,
   computes lag-frequency (Bendat & Piersol errors), the band lag in `fit_band` and the
   lag-energy spectrum with coherence. Output: `data/<key>/lagfreq.json`.

## 7. Real data: reflection fractions

`python scripts/s03_fit_spectra.py <key>` writes and runs an XSPEC/Tcl script with the model
in the config (e.g. `TBabs*(relxill + xillver + zgauss)`), then:

* splits the fitted model into reflected and continuum count rates in every band: R_s, R_h
  and the per-channel R_E;
* obtains `refl_frac` errors from covariance draws and a χ² profile, and refits at
  `spin_systematic_alt` (0.998) to measure the spin systematic;
* writes `data/<key>/spectral.json` with I = R_f/(1+R_f), D, their errors and all parameters.

`scripts/s13_reflection_robustness.py <key>` refits with alternative models (fixed emissivity
break, no distant reflector, no Gaussian, relxillCp, inclination 30°/60°) to quantify the model
dependence of I.

## 8. Fits, comparisons, tables

```bash
python scripts/s06_fit_sources.py <key> --jobs 4     # HAMCOR, bootstrap, variants, Fisher modes
python scripts/s07_lamppost.py <key>                 # lamppost and AIC
python scripts/s08_lag_energy.py <key>               # lag-energy predictive check
python scripts/s10_kerr.py <key> --spins 0.998,0.0   # Kerr
python scripts/s12_energy_resolved.py <key>          # joint lag-frequency + lag-energy fits
python scripts/s09_tables.py                         # LaTeX tables
```

Results are JSON files in `results/` and figure data (`.dat`) plus PGFPlots snippets (`.tex`)
in `results/figures/<key>/`.

## Interpreting the output

* `chi2_lag` / `n_lag`: lag-frequency fit quality (the continuum lag uses 2 parameters).
* `illumination_limited: true` means I_obs exceeds the maximum the transfer can produce; the fit
  then uses the lags only.
* `N_eff`: constrained parameters; `dAIC` > 0 favours HAMCOR over the lamppost.
* `parity_odd_response`: sensitivity of the lags to the left–right asymmetric part of the
  corona (zero in Schwarzschild, ~1 per cent at a = 0.998).
* Low lag-energy coherence (median raw γ² < 0.05) makes the Gaussian lag errors unreliable;
  `s12` then reports only the predictive check.
