# Paper source (A&A format)

`main.tex` with `aa.cls`/`aa.bst`; figures are PGFPlots (`figures/*.tex`, data in
`figures/data/`), tables in `tables/`. Compile with

    pdflatex main && bibtex main && pdflatex main && pdflatex main

`HAMCOR_AA.pdf` is the compiled version.
