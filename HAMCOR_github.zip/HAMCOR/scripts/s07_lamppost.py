"""
s07_lamppost.py — lamppost comparison with the same data, likelihood and spacetime.

An isotropic point source on the axis at height h (not limited to the coronal grid):
chi2(h) = chi2_lag(h) + chi2_I(h). Reports h_best with the Delta chi2 = 1 interval,
and an information-criterion comparison with the HAMCOR baseline, where the HAMCOR
number of effective parameters is N_eff from the Fisher spectrum at the solution.

Output: results/lamppost/<key>.json, results/figures/<key>/lamppost_chi2.dat
Usage : python scripts/s07_lamppost.py all
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import build_grid, build_disc_grid, ForwardModel, PointSourceModel, config as C, pgf
from hamcor2.io import build_obs
from hamcor2.metrics import fisher_spectrum
from hamcor2.hamiltonian import profile_continuum

TWO_PI = 2 * np.pi
cfg_all = C.load()
keys = list(cfg_all) if (len(sys.argv) < 2 or sys.argv[1] == "all") else sys.argv[1:]
H_GRID = np.geomspace(2.5, 40.0, 120)

for key in keys:
    src = cfg_all[key]
    rp = os.path.join(C.results_dir("sources"), f"{key}.json")
    try:
        ob = build_obs(src)
    except FileNotFoundError:
        print(f"{key}: missing products"); continue
    disc = build_disc_grid(**src["disc"])
    use_I = True
    if os.path.exists(rp):
        use_I = bool(C.load_json(rp).get("baseline_uses_I", True))   # same data as HAMCOR
    sig = np.sqrt(ob["sig_tau"] ** 2 + (ob["tau"] * ob["sig_D_frac"]) ** 2)
    out = {}
    for metric in ("schwarzschild", "weakfield", "flat"):
        lp = PointSourceModel(disc, src["incl"], metric)
        lp.prepare(H_GRID)
        chi = []
        for h in H_GRID:
            W, L = lp.row(h)
            if W.sum() <= 0:
                chi.append((np.inf, np.inf)); continue
            pt = (W[None] * np.exp(-1j * TWO_PI * ob["nu_k"][:, None] * L[None])).sum(1) / W.sum()
            Z = np.array([np.sum((ob["p_k"] * np.conj(1 + ob["R_h"] * pt) * (1 + ob["R_s"] * pt))
                                 [ob["bin_k"] == j]) for j in range(len(ob["nu"]))])
            tau = np.angle(Z) / (TWO_PI * ob["nu"])
            if ob["cont_lag"]:                      # same profiled continuum lag as HAMCOR
                tau = tau + profile_continuum(tau, ob["tau"], sig, ob["nu"])[2]
            c_lag = float(np.sum(((tau - ob["tau"]) / sig) ** 2))
            c_I = float(((lp.illumination(h) - ob["I_obs"]) / ob["sig_I"]) ** 2) if use_I else 0.0
            chi.append((c_lag, c_I))
        chi = np.array(chi)
        tot = chi.sum(1)
        i = int(np.argmin(tot))
        ok = H_GRID[np.isfinite(tot) & (tot <= tot[i] + 1.0)]
        out[metric] = dict(h_best=float(H_GRID[i]), h_lo=float(ok.min()), h_hi=float(ok.max()),
                           chi2_lag=float(chi[i, 0]), chi2_I=float(chi[i, 1]), chi2=float(tot[i]),
                           I_pred=float(lp.illumination(H_GRID[i])),
                           pinned_at_grid_edge=bool(i in (np.where(np.isfinite(tot))[0][[0, -1]])))
        fin = np.isfinite(tot)
        pgf.write_dat(os.path.join(C.results_dir("figures", key), f"lamppost_chi2_{metric}.dat"),
                      h=H_GRID[fin], chi2=tot[fin], chi2_lag=chi[fin, 0], chi2_I=chi[fin, 1])
    n_data = len(ob["tau"]) + (1 if use_I else 0)
    n_nuis = 2 if ob["cont_lag"] else 0
    out["n_data"] = n_data
    out["uses_I"] = use_I
    out["n_par_nuisance"] = n_nuis
    if os.path.exists(rp):
        r = C.load_json(rp)
        b = r["baseline"]
        w = np.array(b["w"])
        grid = build_grid(**src["grid"])
        fm = ForwardModel(grid, disc, src["incl"], "schwarzschild")
        _, dtau = fm.lag_model_binned(w, ob["nu_k"], ob["p_k"], ob["bin_k"], ob["nu"],
                                      ob["R_s"], ob["R_h"], grad=True)
        if use_I:
            jac = np.vstack([dtau.T, fm.illumination_grad(w)[None]])
            fs = fisher_spectrum(jac, np.r_[sig, ob["sig_I"]])
        else:
            fs = fisher_spectrum(dtau.T, sig)
        chi_h = b["chi2_lag"] + b.get("chi2_I", 0.0)
        lp_chi = out["schwarzschild"]["chi2"]
        out["hamcor"] = dict(chi2=chi_h, N_eff=fs["N_eff"], rank=fs["rank"],
                             AIC=chi_h + 2 * (fs["N_eff"] + n_nuis),
                             BIC=chi_h + (fs["N_eff"] + n_nuis) * np.log(n_data))
        out["lamppost_IC"] = dict(AIC=lp_chi + 2 * (1 + n_nuis), BIC=lp_chi + (1 + n_nuis) * np.log(n_data))
    C.dump_json(out, os.path.join(C.results_dir("lamppost"), f"{key}.json"))
    s = out["schwarzschild"]
    print(f"{key}: lamppost h = {s['h_best']:.1f} [{s['h_lo']:.1f},{s['h_hi']:.1f}] r_g  "
          f"chi2 = {s['chi2']:.2f}/{n_data - 1 - n_nuis}  (flat: h={out['flat']['h_best']:.1f})"
          + (f"  | HAMCOR chi2={out['hamcor']['chi2']:.2f}, N_eff={out['hamcor']['N_eff']:.2f}"
             if "hamcor" in out else ""))
