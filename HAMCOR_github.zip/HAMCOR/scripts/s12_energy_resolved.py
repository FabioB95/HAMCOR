"""
s12_energy_resolved.py — energy-resolved reverberation: lag-energy predictions and a joint
lag-frequency + lag-energy fit, HAMCOR vs lamppost.

For each source and each spacetime (Schwarzschild main fit; Kerr a = 0.998 from s10):
  1. posterior-predictive check of the lag-energy spectrum with three transfer modes
       grey    : one psi(t) for all channels, illumination-weighted (= s08)
       visible : one psi(t), elements weighted by their observed reflected photons
       eres    : channel-dependent psi_E(t) with g-factors and the xillver template
     for the HAMCOR baseline map and the best lamppost;
  2. joint fit (eres): H = H_mag + chi2_lagfreq/2 + chi2_I/2 + chi2_lagenergy/2 for HAMCOR,
     and the same likelihood on the lamppost height grid; Fisher N_eff of the joint data;
     Delta AIC (positive = HAMCOR preferred).
Needs data/<key>/xillver_template.dat (s11).  --template PATH overrides (tests).
Output: results/energy/<key>_<metric>.json, results/energy/summary.json,
        results/figures/<key>/lagenergy_eres_<metric>.dat
Usage : python scripts/s12_energy_resolved.py all --jobs N
"""
import argparse
import copy
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import build_grid, build_disc_grid, ForwardModel, PointSourceModel, OptConfig, config as C, pgf
from hamcor2.energy import EnergyTransfer, LagEnergyTerm
from hamcor2.fitting import fit, bootstrap, summarize_boot
from hamcor2.hamiltonian import profile_continuum
from hamcor2.io import build_obs, targets
from hamcor2.kerr import r_isco
from hamcor2.metrics import fisher_spectrum

ap = argparse.ArgumentParser()
ap.add_argument("keys", nargs="*", default=["all"])
ap.add_argument("--jobs", type=int, default=None)
ap.add_argument("--starts", type=int, default=8)
ap.add_argument("--boot", type=int, default=0)
ap.add_argument("--metrics", type=str, default="schwarzschild,kerr")
ap.add_argument("--template", type=str, default=None)
args = ap.parse_args()
cfg = C.load()
keys = [k for k in cfg if k != "cygx1"] if args.keys == ["all"] else args.keys
METRICS = args.metrics.split(",")
CFG = OptConfig(n_iter=3000)
TWO_PI = 2 * np.pi
H_GRID_K = np.r_[np.geomspace(1.12, 1.45, 8), np.geomspace(1.5, 40, 50)]   # = s10 (a = 0.998)
H_GRID_S = np.geomspace(2.5, 40.0, 120)       # = s07 (cached)
A_KERR = 0.998
# lag-energy quality: the Gaussian (Bendat & Piersol) lag errors underestimate the scatter at low
# coherence and few segments (Epitropakis & Papadakis 2016); channels with raw coherence < G2_CH are
# dropped and observations with median raw coherence < G2_OBS get the PPC only (no joint fit).
G2_CH, G2_OBS = 0.01, 0.05
out_dir = C.results_dir("energy")
summary = {}


def offset_chi2(model, data, sig):
    wts = 1 / sig ** 2
    c = np.sum(wts * (data - model)) / np.sum(wts)
    return float(np.sum(wts * (data - model - c) ** 2)), float(c)


def lp_lagfreq_chi2(W, L, ob, use_I, I_lp):
    sig = np.sqrt(np.asarray(ob["sig_tau"]) ** 2 + (np.asarray(ob["tau"]) * ob["sig_D_frac"]) ** 2)
    pt = (W[None] * np.exp(-1j * TWO_PI * ob["nu_k"][:, None] * L[None])).sum(1) / W.sum()
    Zk = ob["p_k"] * np.conj(1 + ob["R_h"] * pt) * (1 + ob["R_s"] * pt)
    Z = np.bincount(ob["bin_k"], weights=Zk.real) + 1j * np.bincount(ob["bin_k"], weights=Zk.imag)
    tau = np.angle(Z) / (TWO_PI * ob["nu"])
    if ob["cont_lag"]:
        tau = tau + profile_continuum(tau, ob["tau"], sig, ob["nu"])[2]
    c = float(np.sum(((tau - ob["tau"]) / sig) ** 2))
    cI = float(((I_lp - ob["I_obs"]) / ob["sig_I"]) ** 2) if use_I else 0.0
    return c, cI


for metric in METRICS:
    for key in keys:
        src = cfg[key]
        tp = args.template or os.path.join(C.data_dir(key), "xillver_template.dat")
        if not os.path.exists(tp):
            print(f"{key}: missing {tp} — run s11 first"); continue
        ob = build_obs(src)
        lf = C.load_json(os.path.join(C.data_dir(key), "lagfreq.json"))
        rates = lf["lag_energy"].get("rate")
        if metric == "kerr":
            kp = os.path.join(C.results_dir("kerr"), f"{key}_a{A_KERR}.json")
            if not os.path.exists(kp):
                print(f"{key}: run s10 first"); continue
            prev = C.load_json(kp)
            sp = C.load_json(os.path.join(C.data_dir(key), "spectral.json"))
            ob["I_obs"] = float(sp["I_spinalt"])
            y = float(sp["D_spinalt"]) + ob["R_h"] / (1 + ob["R_h"])
            Rs_new = float(y / max(1 - y, 1e-6))
            fR = Rs_new / ob["R_s"] if ob["R_s"] > 0 else 1.0
            ob["R_s"] = Rs_new; ob["D"] = float(sp["D_spinalt"])
            # lag-energy channel amplitudes: same common reflection renormalisation as the soft band
            ob["R_E"] = list(np.asarray(ob["R_E"], float) * fR)
            ob["R_ref"] = list(np.asarray(ob["R_ref"], float) * fR)
            grid = build_grid(r_in=1.0, r_out=30.0, z_min=0.1, z_max=20.0, n_r=10, n_z=10, n_phi=8)
            disc = build_disc_grid(r_in=r_isco(A_KERR), r_out=100.0, n_r=30, n_phi=18)
            fm = ForwardModel(grid, disc, src["incl"], "kerr", spin=A_KERR)
            lp = PointSourceModel(disc, src["incl"], "kerr", spin=A_KERR)
            lim = bool(prev["illumination_limited"])
            w0 = np.array(prev["baseline"]["w"])
            h0 = prev["lamppost"]["h_best"]
        else:
            prev = C.load_json(os.path.join(C.results_dir("sources"), f"{key}.json"))
            lpj = C.load_json(os.path.join(C.results_dir("lamppost"), f"{key}.json"))
            grid = build_grid(**src["grid"]); disc = build_disc_grid(**src["disc"])
            fm = ForwardModel(grid, disc, src["incl"], "schwarzschild")
            lp = PointSourceModel(disc, src["incl"], "schwarzschild")
            lim = bool(prev.get("illumination_limited", False))
            w0 = np.array(prev["baseline"]["w"])
            h0 = lpj["schwarzschild"]["h_best"]
        H_GRID = H_GRID_K if metric == "kerr" else H_GRID_S
        lp.prepare(H_GRID)
        et = EnergyTransfer(fm, tp, ob["le_E_lo"], ob["le_E_hi"], ob["R_E"], ob["R_ref"], rates=rates)
        nu, wt, fb, tg = ob["le_nu"], ob["le_w"], ob["le_f_mean_nu"], ob["t_g"]
        data, sig = np.array(ob["le_lag"], float), np.array(ob["le_sig"], float)
        g2 = np.asarray(lf["lag_energy"]["g2_raw"], float)
        ok = np.isfinite(data) & np.isfinite(sig) & (sig > 0) & (g2 >= G2_CH)
        data = np.where(ok, data, np.nan)
        n_le = int(ok.sum())
        good_le = bool(np.median(g2) >= G2_OBS)
        chi2_null = offset_chi2(np.zeros(ok.sum()), data[ok], sig[ok])[0]
        # ── 1. PPC with the lag-frequency-only fits ───────────────────────────────────
        Wl, Ll = lp.row(h0)
        ppc = {}
        curves = {}
        for mode in ("grey", "visible", "eres"):
            th = et.lag_energy_map(w0, nu, wt, fb, mode)
            tl = et.lag_energy_row(Wl, Ll, nu, wt, fb, mode)
            ch, cc = offset_chi2(th[ok], data[ok], sig[ok])
            cl, lc = offset_chi2(tl[ok], data[ok], sig[ok])
            ppc[mode] = dict(chi2_hamcor=ch, chi2_lamppost=cl)
            curves[f"hamcor_{mode}"] = (th + cc) * tg
            curves[f"lamppost_{mode}"] = (tl + lc) * tg
        if not good_le:
            res = dict(key=key, metric=metric, illumination_limited=lim, n_le=n_le, ppc=ppc,
                       chi2_null=chi2_null, g2_median=float(np.median(g2)), joint=None,
                       note="median raw coherence below %.2f: lag-energy errors unreliable" % G2_OBS)
            C.dump_json(res, os.path.join(out_dir, f"{key}_{metric}.json"))
            summary[f"{key}_{metric}"] = dict(ppc=ppc, chi2_null=chi2_null, joint=None)
            p = ppc
            print(f"{key} [{metric}] PPC chi2/{n_le - 1}: HAMCOR eres {p['eres']['chi2_hamcor']:.1f} | LP eres "
                  f"{p['eres']['chi2_lamppost']:.1f} | const {chi2_null:.1f}  -- low coherence "
                  f"(median g2 {np.median(g2):.3f}): no joint fit", flush=True)
            continue
        # ── 2. joint fit ─────────────────────────────────────────────────────────────
        obs = targets(ob, use_rad=not lim)
        term = LagEnergyTerm(et, nu, wt, fb, data, sig, "eres")
        obs.meta = dict(obs.meta or {}, le_term=term)
        w1, d1, _, _ = fit(fm, obs, J=1.0, n_starts=args.starts, cfg=CFG, n_jobs=args.jobs, w_starts=[w0])
        _, dtau = fm.lag_model_binned(w1, ob["nu_k"], ob["p_k"], ob["bin_k"], ob["nu"],
                                      ob["R_s"], ob["R_h"], grad=True)
        _, dle = term.tau(w1, grad=True)
        s_le = sig[ok]
        Jle = dle[:, ok].T
        wle = 1 / s_le ** 2
        Jle = Jle - (wle @ Jle)[None] / wle.sum()                     # offset profiled out
        blocks, sigs = [dtau.T, Jle], [obs.sigma_total(), s_le]
        if not lim:
            blocks.append(fm.illumination_grad(w1)[None]); sigs.append(np.array([ob["sig_I"]]))
        fs = fisher_spectrum(np.vstack(blocks), np.concatenate(sigs))
        fs_lf = fisher_spectrum(np.vstack(blocks[:1] + blocks[2:]), np.concatenate(sigs[:1] + sigs[2:]))
        chi_h = d1["chi2_lag"] + d1["chi2_le"] + ((d1.get("chi2_I") or 0.0) if not lim else 0.0)
        # lamppost joint scan
        best = None
        rows = []
        for h in H_GRID:
            W, L = lp.row(h)
            if W.sum() <= 0:
                continue
            c_lf, c_I = lp_lagfreq_chi2(W, L, ob, not lim, lp.illumination(h))
            c_le, _ = offset_chi2(et.lag_energy_row(W, L, nu, wt, fb, "eres")[ok], data[ok], sig[ok])
            tot = c_lf + c_I + c_le
            rows.append((h, tot, c_lf, c_I, c_le))
            if best is None or tot < best[1]:
                best = (h, tot, c_lf, c_I, c_le)
        nn = 2 if ob["cont_lag"] else 0
        dAIC = (best[1] + 2 * (1 + nn + 1)) - (chi_h + 2 * (fs["N_eff"] + nn + 1))
        res = dict(key=key, metric=metric, illumination_limited=lim, n_le=n_le,
                   ppc=ppc, chi2_null=chi2_null, g2_median=float(np.median(g2)),
                   joint=dict(chi2_lag=d1["chi2_lag"], n_lag=d1["n_lag"], chi2_le=d1["chi2_le"],
                              chi2_I=d1.get("chi2_I"), R_c=d1["R_c"], z_c=d1["z_c"],
                              N_eff=fs["N_eff"], N_eff_lagfreq_only=fs_lf["N_eff"], w=w1),
                   lamppost=dict(h_best=best[0], chi2=best[1], chi2_lag=best[2], chi2_I=best[3],
                                 chi2_le=best[4]),
                   dAIC=dAIC, g_range=[float(np.nanmin(et.g)), float(np.nanmax(et.g))])
        if args.boot:
            sb = summarize_boot(bootstrap(fm, obs, J=1.0, n_boot=args.boot, n_starts=4, n_jobs=args.jobs))
            res["bootstrap"] = {k_: v for k_, v in sb.items() if not k_.startswith("w_")}
        C.dump_json(res, os.path.join(out_dir, f"{key}_{metric}.json"))
        E = 0.5 * (np.asarray(ob["le_E_lo"]) + np.asarray(ob["le_E_hi"]))
        th_j = term.chi2(w1)[2] * tg
        tl_j = et.lag_energy_row(*lp.row(best[0]), nu, wt, fb, "eres")
        tl_j = (tl_j + offset_chi2(tl_j[ok], data[ok], sig[ok])[1]) * tg
        pgf.write_dat(os.path.join(C.results_dir("figures", key), f"lagenergy_eres_{metric}.dat"),
                      E=E, data=data * tg, sig=sig * tg, hamcor_joint=th_j, lamppost_joint=tl_j,
                      **curves)
        summary[f"{key}_{metric}"] = dict(ppc=ppc, chi2_joint_hamcor=chi_h, chi2_joint_lamppost=best[1],
                                          N_eff=fs["N_eff"], N_eff_lagfreq_only=fs_lf["N_eff"], dAIC=dAIC)
        p = ppc
        print(f"{key} [{metric}] PPC chi2/{n_le - 1}: HAMCOR grey {p['grey']['chi2_hamcor']:.1f} "
              f"vis {p['visible']['chi2_hamcor']:.1f} eres {p['eres']['chi2_hamcor']:.1f} | LP grey "
              f"{p['grey']['chi2_lamppost']:.1f} vis {p['visible']['chi2_lamppost']:.1f} eres "
              f"{p['eres']['chi2_lamppost']:.1f} const {chi2_null:.1f}  || joint: HAMCOR lag {d1['chi2_lag']:.1f} le "
              f"{d1['chi2_le']:.1f} (R_c={d1['R_c']:.1f} z_c={d1['z_c']:.1f}, N_eff {fs_lf['N_eff']:.1f}"
              f"->{fs['N_eff']:.1f})  LP h={best[0]:.1f} lag {best[2]:.1f} le {best[4]:.1f}  "
              f"dAIC={dAIC:+.1f}", flush=True)
C.dump_json(summary, os.path.join(out_dir, "summary.json"))
print("ENERGY_DONE")
