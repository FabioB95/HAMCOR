"""
s05_synthetic.py — synthetic validation (points #1, #6, #7, #8 of the revision plan).

  A. Recovery of compact / column / ring coronae (Schwarzschild data, Schwarzschild fit),
     N_noise noise realisations each; same grid as the real-data fits.
  B. GR impact: Schwarzschild data fitted with the flat-space model (bias), and the
     Omega-weighted Shapiro fraction for each geometry.
  C. Coupling scan J in {0, 0.1, 0.3, 1, 3, 10} (noiseless data).
  D. Information content: Fisher spectrum, N_eff of data-constrained modes,
     multistart ensemble at J = 0 (the degenerate manifold).
  E. Azimuthal parity: exact invariance of psi~ under phi -> -phi, recovery of the
     even/odd parts for the ring and an off-plane blob.
  F. Prior / likelihood robustness: legacy psi-prior mode with Gaussian, top-hat and
     uniform priors (same mean and width) and the mean-lag-only likelihood, compared
     with the lag-frequency likelihood.

Output: results/synthetic/*.json, results/figures/synthetic/*.{dat,tex}
Usage : python scripts/s05_synthetic.py [--quick]
"""
import os
import sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import argparse
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import (build_grid, build_disc_grid, ForwardModel, Hamiltonian, OptConfig,
                     multistart, config as C, pgf)
from hamcor2.synthetic import GEOMETRIES, make_observables
from hamcor2.metrics import recovery_metrics, fisher_spectrum, mirror_index, pearson
from hamcor2.fitting import fit, export_map
from hamcor2.hamiltonian import ObsTargets

ap = argparse.ArgumentParser()
ap.add_argument("--quick", action="store_true", help="few realisations (test run)")
ap.add_argument("--jobs", type=int, default=None)
args = ap.parse_args()

N_NOISE = 3 if args.quick else 10
N_START = 4 if args.quick else 8
CFG = OptConfig(n_iter=1500 if args.quick else 3000)
INCL = 30.0
J0 = 1.0
# Reverberation band of Mrk 335 in units of c^3/GM: 2-7e-4 Hz x 64 s  -> 0.013-0.045
NU_EDGES = np.geomspace(0.0128, 0.045, 4)
NOISE = dict(sig_tau_frac=0.30, sig_tau_floor=0.05, R_s=0.6, R_h=0.15,
             sig_D_frac=0.10, sig_I=0.05)
OUT = C.results_dir("synthetic")
FIG = C.results_dir("figures", "synthetic")

grid, disc = build_grid(), build_disc_grid()
fm_gr = ForwardModel(grid, disc, INCL, "schwarzschild")
fm_fl = ForwardModel(grid, disc, INCL, "flat")
GEOMS = ["lamppost", "column", "ring"]
t0 = time.time()
summary = {}


def stats(vals):
    v = np.array(vals, float)
    return dict(median=float(np.nanmedian(v)), p16=float(np.nanpercentile(v, 16)),
                p84=float(np.nanpercentile(v, 84)))


# ── A + B: recovery and GR bias ─────────────────────────────────────────────────
for g in GEOMS:
    w_t = GEOMETRIES[g](grid)
    rec = {"gr": [], "flat": []}
    for k in range(N_NOISE):
        obs = make_observables(fm_gr, w_t, NU_EDGES, noise_seed=k, **NOISE)
        for lab, fm in (("gr", fm_gr), ("flat", fm_fl)):
            w, d, _, _ = fit(fm, obs, J=J0, n_starts=N_START, cfg=CFG, n_jobs=args.jobs)
            m = recovery_metrics(grid, w_t, w)
            m.update(chi2=d["chi2_lag"], chi2_I=d.get("chi2_I", np.nan),
                     lag_err=float(np.mean(np.abs(d["tau_model"] - obs.tau) / np.abs(obs.tau))))
            rec[lab].append(m)
            if k == 0:
                export_map(grid, w, os.path.join(FIG, f"rec_{g}_{lab}.dat"),
                           os.path.join(FIG, f"rec_{g}_{lab}.tex"), title=f"{g} ({lab})")
    export_map(grid, w_t, os.path.join(FIG, f"true_{g}.dat"),
               os.path.join(FIG, f"true_{g}.tex"), title=f"{g} (true)")
    m_ = fm_gr.Xi > 0
    Wt = (w_t[:, None] * fm_gr.W)[m_]
    shap = float(np.sum(Wt * (fm_gr.L - fm_fl.L)[m_]) / np.sum(Wt * fm_fl.L[m_]))
    summary[g] = dict(
        true=dict(I=fm_gr.illumination(w_t), mean_lag_gr=fm_gr.mean_lag(w_t),
                  mean_lag_flat=fm_fl.mean_lag(w_t), shapiro_frac=shap,
                  R_c=float(w_t @ grid.R), z_c=float(w_t @ grid.z)),
        **{lab: {k: stats([r[k] for r in rec[lab]]) for k in rec[lab][0]} for lab in rec})
    s = summary[g]["gr"]
    print(f"[A] {g:9s} rho3d={s['rho_3d']['median']:.2f} rho_rz={s['rho_rz']['median']:.2f} "
          f"d_cen={s['d_centroid']['median']:.2f}  | flat-fit d_cen="
          f"{summary[g]['flat']['d_centroid']['median']:.2f}  Shapiro={100*shap:.1f}%  "
          f"({time.time()-t0:.0f}s)")
C.dump_json(summary, os.path.join(OUT, "recovery.json"))

# ── C: coupling scan ────────────────────────────────────────────────────────────
scan = {}
for g in GEOMS:
    w_t = GEOMETRIES[g](grid)
    obs = make_observables(fm_gr, w_t, NU_EDGES, noise_seed=None, **NOISE)
    scan[g] = []
    for J in (0.0, 0.1, 0.3, 1.0, 3.0, 10.0):
        w, d, _, _ = fit(fm_gr, obs, J=J, n_starts=N_START, cfg=CFG, n_jobs=args.jobs)
        m = recovery_metrics(grid, w_t, w)
        scan[g].append(dict(J=J, chi2=d["chi2_lag"], rho_3d=m["rho_3d"], rho_rz=m["rho_rz"],
                            d_centroid=m["d_centroid"]))
    print(f"[C] {g}: " + "  ".join(f"J={r['J']}:rho={r['rho_3d']:.2f}" for r in scan[g]))
C.dump_json(scan, os.path.join(OUT, "J_scan.json"))
for g in GEOMS:
    pgf.write_dat(os.path.join(FIG, f"Jscan_{g}.dat"),
                  J=[max(r["J"], 0.03) for r in scan[g]], rho=[r["rho_3d"] for r in scan[g]],
                  rho_rz=[r["rho_rz"] for r in scan[g]], dcen=[r["d_centroid"] for r in scan[g]])

# ── D: information content ──────────────────────────────────────────────────────
info = {}
for g in GEOMS:
    w_t = GEOMETRIES[g](grid)
    obs = make_observables(fm_gr, w_t, NU_EDGES, noise_seed=None, **NOISE)
    _, dtau = fm_gr.lag_model_binned(w_t, obs.nu_k, obs.p_k, obs.bin_k, obs.nu,
                                     obs.R_s, obs.R_h, grad=True)
    jac = np.vstack([dtau.T, fm_gr.illumination_grad(w_t)[None, :]])
    sig = np.r_[obs.sigma_total(), obs.sig_I]
    fs = fisher_spectrum(jac, sig)
    H = Hamiltonian(fm_gr, obs, J=0.0)
    ens = multistart(H, range(20), CFG, args.jobs)
    good = [r for r in ens if 2 * H.diagnostics(r.w)["H_lag"] < len(obs.tau) + 1]
    rhos = [pearson(w_t, r.w) for r in good]
    w_mean = np.mean([r.w for r in good], 0) if good else ens[0].w
    info[g] = dict(eigvals=fs["eigvals"][:6], rank=fs["rank"], N_eff=fs["N_eff"],
                   N_obs=fs["N_obs"], N_params=fs["N_params"], n_good=len(good),
                   rho_members=stats(rhos), rho_ensemble_mean=pearson(w_t, w_mean))
    print(f"[D] {g}: rank={fs['rank']}  N_eff={fs['N_eff']:.2f} of {fs['N_params']}  "
          f"members rho={info[g]['rho_members']['median']:.2f}  "
          f"mean-of-ensemble rho={info[g]['rho_ensemble_mean']:.2f}")
C.dump_json(info, os.path.join(OUT, "information.json"))

# ── E: parity ───────────────────────────────────────────────────────────────────
mi = mirror_index(grid)
rng = np.random.default_rng(7)
dw = rng.normal(size=grid.n_cells); dw = 0.5 * (dw - dw[mi])      # pure odd
Gm = fm_gr.G(NU_EDGES)
inv = float(np.max(np.abs(dw @ Gm)) / np.max(np.abs(np.abs(dw) @ np.abs(Gm))))
inv_I = float(abs(dw @ fm_gr.a) / (np.abs(dw) @ fm_gr.a))
par = dict(odd_response_lag=inv, odd_response_I=inv_I)
for g in ("ring", "blob"):
    w_t = GEOMETRIES[g](grid)
    obs = make_observables(fm_gr, w_t, NU_EDGES, noise_seed=None, **NOISE)
    w, d, _, _ = fit(fm_gr, obs, J=J0, n_starts=N_START, cfg=CFG, n_jobs=args.jobs)
    par[g] = recovery_metrics(grid, w_t, w)
    export_map(grid, w, os.path.join(FIG, f"parity_{g}.dat"),
               os.path.join(FIG, f"parity_{g}.tex"), title=g)
print(f"[E] odd-mode response: lag {inv:.1e}, I {inv_I:.1e};  ring rho3d/rz/even = "
      f"{par['ring']['rho_3d']:.2f}/{par['ring']['rho_rz']:.2f}/{par['ring']['rho_even']:.2f};"
      f" blob odd power true/rec = {par['blob']['odd_power_true']:.2f}/"
      f"{par['blob']['odd_power_rec']:.2f}")
C.dump_json(par, os.path.join(OUT, "parity.json"))

# ── F: prior / likelihood robustness ────────────────────────────────────────────
rob = {}
edges = np.linspace(0.0, 40.0, 81)
tc = 0.5 * (edges[1:] + edges[:-1])
for g in GEOMS:
    w_t = GEOMETRIES[g](grid)
    obs = make_observables(fm_gr, w_t, NU_EDGES, noise_seed=0, **NOISE)
    mu = fm_gr.mean_lag(w_t)              # first moment the scalar lag constrains
    sd = 0.3 * mu
    priors = {
        "gaussian": np.exp(-0.5 * ((tc - mu) / sd) ** 2),
        "tophat": (np.abs(tc - mu) <= np.sqrt(3) * sd).astype(float),
        "uniform": ((tc >= 0) & (tc <= 2 * mu)).astype(float),
    }
    rob[g] = {}
    for name, p in priors.items():
        o = ObsTargets(nu=obs.nu, tau=obs.tau, sig_tau=obs.sig_tau, R_s=obs.R_s, R_h=obs.R_h,
                       I_obs=obs.I_obs, sig_I=obs.sig_I,
                       psi_prior=np.r_[p / p.sum(), 0.0], psi_edges=edges)
        H = Hamiltonian(fm_gr, o, J=0.1, alpha=50.0, beta=10.0, mode="psi")
        w = multistart(H, range(N_START), CFG, args.jobs)[0].w
        rob[g][f"psi_{name}"] = recovery_metrics(grid, w_t, w)
    o = ObsTargets(nu=obs.nu[:1], tau=np.array([-obs.D * mu]), sig_tau=np.array([0.3 * obs.D * mu]),
                   R_s=obs.R_s, R_h=obs.R_h, I_obs=obs.I_obs, sig_I=obs.sig_I)
    w, _, _, _ = fit(fm_gr, o, J=J0, n_starts=N_START, cfg=CFG, n_jobs=args.jobs, mode="meanlag")
    rob[g]["meanlag"] = recovery_metrics(grid, w_t, w)
    w, _, _, _ = fit(fm_gr, obs, J=J0, n_starts=N_START, cfg=CFG, n_jobs=args.jobs)
    rob[g]["lagfreq"] = recovery_metrics(grid, w_t, w)
    print(f"[F] {g}: " + "  ".join(f"{k}: rho={v['rho_3d']:.2f},cen=({v['R_c_rec']:.1f},"
                                   f"{v['z_c_rec']:.1f})" for k, v in rob[g].items()))
C.dump_json(rob, os.path.join(OUT, "robustness.json"))
print(f"\nDone in {time.time()-t0:.0f} s. Results in results/synthetic/")
