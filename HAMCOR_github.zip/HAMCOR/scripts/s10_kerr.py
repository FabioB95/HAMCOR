"""
s10_kerr.py — spin test: HAMCOR and lamppost with exact Kerr transfer.

For a = 0 and a = 0.998 (Kerr module, Kerr-Schild ray tracing) on an extended grid
(R from 1 r_g, cells inside the ergosphere masked), with the disc from the ISCO:
  * I_max of single cells and of the lamppost;
  * HAMCOR baseline (+ bootstrap) for every source, with I_obs and dilution from the
    spectral fit at the same spin (a=0: main fit; a=0.998: spin-systematic refit);
  * lamppost chi2(h), AIC comparison;
  * parity: response of the lags to the odd part of the emissivity (non-zero for a != 0).
Output: results/kerr/<key>_a<spin>.json, results/kerr/summary.json, figure data.
Usage : python scripts/s10_kerr.py all --jobs N
"""
import argparse
import copy
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import build_grid, build_disc_grid, ForwardModel, PointSourceModel, OptConfig, config as C, pgf
from hamcor2.fitting import fit, bootstrap, summarize_boot
from hamcor2.hamiltonian import profile_continuum
from hamcor2.io import build_obs, targets
from hamcor2.kerr import r_isco, r_horizon
from hamcor2.metrics import fisher_spectrum

ap = argparse.ArgumentParser()
ap.add_argument("keys", nargs="*", default=["all"])
ap.add_argument("--jobs", type=int, default=None)
ap.add_argument("--boot", type=int, default=10)
ap.add_argument("--starts", type=int, default=8)
ap.add_argument("--spins", type=str, default="0.0,0.998")
args = ap.parse_args()
cfg = C.load()
keys = [k for k in cfg if k != "cygx1"] if args.keys == ["all"] else args.keys
SPINS = [float(s) for s in args.spins.split(",")]
CFG = OptConfig(n_iter=3000)
TWO_PI = 2 * np.pi
H_ALL = np.r_[np.geomspace(1.12, 1.45, 8), np.geomspace(1.5, 40, 50)]
out_dir = C.results_dir("kerr")
summary = {}


def grid_ext():
    return build_grid(r_in=1.0, r_out=30.0, z_min=0.1, z_max=20.0, n_r=10, n_z=10, n_phi=8)


def lp_scan(lp, ob, use_I):
    sig = np.sqrt(np.asarray(ob["sig_tau"]) ** 2 + (np.asarray(ob["tau"]) * ob["sig_D_frac"]) ** 2)
    best = None
    rows = []
    for h in H_GRID:
        W, L = lp.row(h)
        if W.sum() <= 0:
            continue
        nu_k, p_k, bin_k = ob["nu_k"], ob["p_k"], ob["bin_k"]
        pt = (W[None] * np.exp(-1j * TWO_PI * nu_k[:, None] * L[None])).sum(1) / W.sum()
        Zk = p_k * np.conj(1 + ob["R_h"] * pt) * (1 + ob["R_s"] * pt)
        Z = np.bincount(bin_k, weights=Zk.real) + 1j * np.bincount(bin_k, weights=Zk.imag)
        tau = np.angle(Z) / (TWO_PI * ob["nu"])
        if ob["cont_lag"]:
            tau = tau + profile_continuum(tau, ob["tau"], sig, ob["nu"])[2]
        c = float(np.sum(((tau - ob["tau"]) / sig) ** 2))
        cI = float(((lp.illumination(h) - ob["I_obs"]) / ob["sig_I"]) ** 2) if use_I else 0.0
        rows.append((h, c + cI, c, cI, lp.illumination(h)))
        if best is None or c + cI < best[1]:
            best = (h, c + cI)
    return np.array(rows), best


for a in SPINS:
    H_GRID = H_ALL[H_ALL > r_horizon(a) + (0.05 if a > 0.5 else 0.4)]   # static source outside the horizon
    grid = grid_ext()
    disc = build_disc_grid(r_in=r_isco(a), r_out=100.0, n_r=30, n_phi=18)
    for key in keys:
        src = cfg[key]
        sp = C.load_json(os.path.join(C.data_dir(key), "spectral.json"))
        ob = build_obs(src)
        if a > 0.5:                                   # spectral quantities at a = 0.998
            ob["I_obs"] = float(sp["I_spinalt"])
            D_new = float(sp["D_spinalt"])
            # keep R_h, solve R_s for the refitted dilution factor
            y = D_new + ob["R_h"] / (1 + ob["R_h"])
            ob["R_s"] = float(y / max(1 - y, 1e-6))
            ob["D"] = D_new
        fm = ForwardModel(grid, disc, src["incl"], "kerr", spin=a)
        valid = ~fm.invalid
        Icell = np.where(valid, fm.a / np.maximum(fm.a + fm.E, 1e-30), 0.0)
        I_max = float(Icell.max())
        lim = bool(ob["I_obs"] - 2 * ob["sig_I"] > I_max)
        obs = targets(ob, use_rad=not lim)
        w0, d0, _, _ = fit(fm, obs, J=1.0, n_starts=args.starts, cfg=CFG, n_jobs=args.jobs)
        boot = bootstrap(fm, obs, J=1.0, n_boot=args.boot, n_starts=4, n_jobs=args.jobs)
        sb = summarize_boot(boot)
        _, dtau = fm.lag_model_binned(w0, ob["nu_k"], ob["p_k"], ob["bin_k"], ob["nu"],
                                      ob["R_s"], ob["R_h"], grad=True)
        sig = obs.sigma_total()
        if lim:
            fs = fisher_spectrum(dtau.T, sig)
        else:
            fs = fisher_spectrum(np.vstack([dtau.T, fm.illumination_grad(w0)[None]]), np.r_[sig, ob["sig_I"]])
        # parity: odd part of the baseline map
        g = grid
        mirror = (np.arange(g.n_cells).reshape(g.n_r, g.n_z, g.n_phi)[:, :, ::-1]).ravel()
        tau_w = fm.lag_model_binned(w0, ob["nu_k"], ob["p_k"], ob["bin_k"], ob["nu"], ob["R_s"], ob["R_h"])
        tau_m = fm.lag_model_binned(w0[mirror], ob["nu_k"], ob["p_k"], ob["bin_k"], ob["nu"], ob["R_s"], ob["R_h"])
        parity = float(np.max(np.abs(tau_w - tau_m)) / max(np.max(np.abs(tau_w)), 1e-12))
        # lamppost
        lp = PointSourceModel(disc, src["incl"], "kerr", spin=a)
        lp.prepare(H_GRID)
        rows, best = lp_scan(lp, ob, not lim)
        chi_h = d0["chi2_lag"] + (d0.get("chi2_I", 0.0) if not lim else 0.0)
        nn = 2 if ob["cont_lag"] else 0
        dAIC = (best[1] + 2 * (1 + nn)) - (chi_h + 2 * (fs["N_eff"] + nn))
        res = dict(key=key, spin=a, I_obs=ob["I_obs"], D=ob["D"], I_max=I_max,
                   I_max_lamppost=float(rows[:, 4].max()), illumination_limited=lim,
                   baseline=dict(R_c=d0["R_c"], z_c=d0["z_c"], chi2_lag=d0["chi2_lag"],
                                 n_lag=d0["n_lag"], chi2_I=d0.get("chi2_I"),
                                 I_pred=fm.illumination(w0), mean_lag=d0["mean_lag"], w=w0),
                   bootstrap={k_: v for k_, v in sb.items() if not k_.startswith("w_")},
                   N_eff=fs["N_eff"], parity_odd_response=parity,
                   lamppost=dict(h_best=best[0], chi2=best[1]), dAIC=dAIC)
        C.dump_json(res, os.path.join(out_dir, f"{key}_a{a}.json"))
        fd = C.results_dir("figures", key)
        Zm = grid.rz_map(np.asarray(sb["w_mean"]))
        pgf.write_matrix_dat(os.path.join(fd, f"map_kerr_a{a}.dat"), grid.R_centers, grid.z_centers,
                             Zm / Zm.max())
        summary[f"{key}_a{a}"] = {k_: res[k_] for k_ in ("I_obs", "I_max", "I_max_lamppost",
                                                         "illumination_limited", "N_eff",
                                                         "parity_odd_response", "dAIC")}
        b = res["bootstrap"]
        print(f"{key} a={a}: I_obs={ob['I_obs']:.3f} I_max={I_max:.3f} (LP {res['I_max_lamppost']:.3f}) "
              f"{'LAGS ONLY' if lim else 'lags+I'}  chi2_lag={d0['chi2_lag']:.2f} chi2_I="
              f"{(d0.get('chi2_I') or 0):.2f}  R_c={b['R_c']['median']:.1f} [{b['R_c']['p16']:.1f},"
              f"{b['R_c']['p84']:.1f}] z_c={b['z_c']['median']:.1f} [{b['z_c']['p16']:.1f},"
              f"{b['z_c']['p84']:.1f}]  N_eff={fs['N_eff']:.1f}  LP h={best[0]:.1f}  dAIC={dAIC:+.1f}  "
              f"parity={parity:.2e}", flush=True)
    if a == 0.998 or len(SPINS) == 1:
        pass
    # I(h) for the lamppost and I_max map of this spin (figure data)
    lp0 = PointSourceModel(disc, 30.0, "kerr", spin=a); lp0.prepare(H_GRID)
    pgf.write_dat(os.path.join(out_dir, f"lamppost_I_a{a}.dat"), h=H_GRID,
                  I=np.array([lp0.illumination(h) for h in H_GRID]))
C.dump_json(summary, os.path.join(out_dir, "summary.json"))
print("KERR_DONE")
