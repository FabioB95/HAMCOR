"""
s06_fit_sources.py — HAMCOR fits to the real sources (Schwarzschild baseline).

Per source:
  baseline   : Schwarzschild lags, lag-frequency likelihood in the reverberation band,
               measured I_obs and dilution (R_s, R_h), J = 1, 16 starts
  flat       : same with flat-space lags (GR impact on the inferred geometry)
  J = 0.3, 3 : prior-strength sensitivity
  M +/- 1 sig: black-hole-mass systematic
  no-I       : without the illumination term (what the lags alone say)
  bootstrap  : n_boot replicas (lags, I_obs, dilution resampled) -> centroid errors

Output: results/sources/<key>.json, results/figures/<key>/{map,lagmodel}.*
Usage : python scripts/s06_fit_sources.py all [--boot 30] [--jobs N]
"""
import os
import sys
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import argparse
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import build_grid, build_disc_grid, ForwardModel, OptConfig, config as C, pgf
from hamcor2.io import build_obs, targets
from hamcor2.fitting import fit, bootstrap, summarize_boot, export_map

ap = argparse.ArgumentParser()
ap.add_argument("keys", nargs="*", default=["all"])
ap.add_argument("--boot", type=int, default=30)
ap.add_argument("--starts", type=int, default=16)
ap.add_argument("--jobs", type=int, default=None)
args = ap.parse_args()
cfg_all = C.load()
keys = list(cfg_all) if args.keys == ["all"] else args.keys
CFG = OptConfig(n_iter=3000)


def light(d):
    return {k: v for k, v in d.items() if k not in ("w",)}


for key in keys:
    src = cfg_all[key]
    try:
        ob = build_obs(src)
    except FileNotFoundError as e:
        print(f"{key}: missing products ({e}); run s01-s03"); continue
    t0 = time.time()
    g = src["grid"]; dd = src["disc"]
    grid = build_grid(**g)
    disc = build_disc_grid(**dd)
    fm = ForwardModel(grid, disc, src["incl"], "schwarzschild")
    fm_flat = ForwardModel(grid, disc, src["incl"], "flat")
    fm_wf = ForwardModel(grid, disc, src["incl"], "weakfield")
    # Largest illumination fraction any coronal configuration can produce (single cell,
    # exact Schwarzschild transfer).  If the measured I_obs exceeds it by > 2 sigma the
    # spectrum cannot be reproduced by an isotropic corona around a Schwarzschild hole
    # with the disc truncated at the ISCO (cf. Dauser et al. 2014): the illumination term
    # is then excluded from the baseline (lags only) and reported as a variant.
    I_max = float(np.max(fm.a / (fm.a + fm.E)))
    illum_limited = bool(ob["I_obs"] - 2 * ob["sig_I"] > I_max)
    obs = targets(ob, use_rad=not illum_limited)
    res = dict(key=key, name=src["name"], M_bh=ob["M_bh"], incl=src["incl"],
               data=dict(f=ob["f"], tau_s=ob["tau_s"], sig_s=ob["sig_tau_s"],
                         tau=ob["tau"], sig=ob["sig_tau"], R_s=ob["R_s"], R_h=ob["R_h"],
                         D=ob["D"], I_obs=ob["I_obs"], sig_I=ob["sig_I"]),
               I_max=I_max, illumination_limited=illum_limited, baseline_uses_I=not illum_limited)
    if illum_limited:
        print(f"{key}: I_obs = {ob['I_obs']:.3f} +/- {ob['sig_I']:.3f} > I_max = {I_max:.3f} "
              f"(Schwarzschild): baseline from the lags only")

    w0, d0, ens, H = fit(fm, obs, J=1.0, n_starts=args.starts, cfg=CFG, n_jobs=args.jobs)
    res["baseline"] = d0
    res["baseline"]["w"] = w0
    res["baseline"]["n_data"] = len(obs.tau) + 1
    res["ensemble_spread"] = dict(
        R_c=float(np.std([r.w @ grid.R for r in ens[:8]])),
        z_c=float(np.std([r.w @ grid.z for r in ens[:8]])))
    ndof = d0['n_lag'] - d0.get('n_par_nuisance', 0)
    cl = (f"  cont: A={d0['cont_A']*ob['t_g']:.0f} s, a={d0['cont_index']:.1f}"
          if d0.get("cont_lag") else "")
    print(f"{key}: baseline chi2_lag={d0['chi2_lag']:.2f}/{ndof}{cl}  "
          f"chi2_I={d0.get('chi2_I', np.nan):.2f}  (R_c,z_c)=({d0['R_c']:.2f},{d0['z_c']:.2f})"
          f"  <t>={d0['mean_lag']:.2f} r_g/c")

    # ── information content: Fisher modes of the data at the baseline solution ──
    _, dtau = fm.lag_model_binned(w0, ob["nu_k"], ob["p_k"], ob["bin_k"], ob["nu"],
                                  ob["R_s"], ob["R_h"], grad=True)
    sig_l = obs.sigma_total()
    jac, sig_all = dtau.T, sig_l
    if not illum_limited:
        jac = np.vstack([jac, fm.illumination_grad(w0)[None]])
        sig_all = np.r_[sig_l, ob["sig_I"]]
    Nc = grid.n_cells
    P = np.eye(Nc) - np.ones((Nc, Nc)) / Nc
    U, S, Vt = np.linalg.svd((jac / sig_all[:, None]) @ P, full_matrices=False)
    lam = S ** 2
    # per-cell physical descriptors used to interpret the modes
    tcell = np.where(fm.a > 0, fm.aL / np.maximum(fm.a, 1e-300), 0.0)
    Icell = fm.a / (fm.a + fm.E)
    rcell = np.sqrt(grid.R ** 2 + grid.z ** 2)
    desc = dict(mean_delay=tcell, illumination=Icell, radius=rcell, height=grid.z,
                cyl_radius=grid.R)
    modes = []
    fd0 = C.results_dir("figures", key)
    for m in range(min(4, len(S))):
        v = Vt[m]
        cor = {k_: float(np.corrcoef(v, d_)[0, 1]) for k_, d_ in desc.items()}
        Z = grid.rz_map(v)
        Z = Z / np.max(np.abs(Z))
        if Z.ravel()[np.argmax(np.abs(Z))] < 0:
            Z = -Z
            cor = {k_: -c_ for k_, c_ in cor.items()}
        pgf.write_matrix_dat(os.path.join(fd0, f"mode{m+1}.dat"), grid.R_centers, grid.z_centers, Z)
        modes.append(dict(eigval=float(lam[m]), corr=cor))
    res["fisher"] = dict(eigvals=lam.tolist(), N_eff=float(np.sum(lam / (lam + 1.0))), modes=modes)
    print(f"   Fisher: N_eff={res['fisher']['N_eff']:.2f}  " + "  ".join(
        f"mode{m+1}: lam={md['eigval']:.2g}, corr(<t>)={md['corr']['mean_delay']:+.2f}, "
        f"corr(r)={md['corr']['radius']:+.2f}" for m, md in enumerate(modes)))

    variants = {"flat": (fm_flat, obs, 1.0), "weakfield": (fm_wf, obs, 1.0),
                "J0.3": (fm, obs, 0.3), "J3": (fm, obs, 3.0),
                ("withI" if illum_limited else "noI"):
                    (fm, targets(ob, use_rad=illum_limited), 1.0)}
    for lab, (f_, o_, J_) in variants.items():
        w, d, _, _ = fit(f_, o_, J=J_, n_starts=max(4, args.starts // 2), cfg=CFG,
                         n_jobs=args.jobs)
        res[lab] = d
        res[lab]["w"] = w
    for lab, Ms in (("M_lo", src["M_bh"] - src["M_bh_err"]), ("M_hi", src["M_bh"] + src["M_bh_err"])):
        o_ = targets(build_obs(src, M_bh=Ms), use_rad=not illum_limited)
        w, d, _, _ = fit(fm, o_, J=1.0, n_starts=max(4, args.starts // 2), cfg=CFG,
                         n_jobs=args.jobs)
        res[lab] = d
        res[lab]["M_bh"] = Ms
    for lab in ("flat", "weakfield", "J0.3", "J3", "withI" if illum_limited else "noI", "M_lo", "M_hi"):
        print(f"   {lab:9s} (R_c,z_c)=({res[lab]['R_c']:.2f},{res[lab]['z_c']:.2f}) "
              f"chi2_lag={res[lab]['chi2_lag']:.2f}")

    if args.boot > 0:
        boot = bootstrap(fm, obs, J=1.0, n_boot=args.boot, n_starts=4, n_jobs=args.jobs)
        sb = summarize_boot(boot)
        res["bootstrap"] = {k: v for k, v in sb.items() if not k.startswith("w_")}
        res["bootstrap"]["w_mean"] = sb["w_mean"]
        res["bootstrap"]["w_std"] = sb["w_std"]
        b = res["bootstrap"]
        print(f"   bootstrap: R_c={b['R_c']['median']:.2f} [{b['R_c']['p16']:.2f},"
              f"{b['R_c']['p84']:.2f}]  z_c={b['z_c']['median']:.2f} [{b['z_c']['p16']:.2f},"
              f"{b['z_c']['p84']:.2f}]")

    # ── figures ─────────────────────────────────────────────────────────────
    fd = C.results_dir("figures", key)
    export_map(grid, w0, os.path.join(fd, "map.dat"), os.path.join(fd, "map.tex"),
               title=src["name"])
    if "bootstrap" in res:
        wm, ws = np.asarray(res["bootstrap"]["w_mean"]), np.asarray(res["bootstrap"]["w_std"])
        Zm, Zs = grid.rz_map(wm), grid.rz_map(ws)
        pgf.write_matrix_dat(os.path.join(fd, "map_bootmean.dat"), grid.R_centers, grid.z_centers,
                             Zm / Zm.max())
        pgf.write_matrix_dat(os.path.join(fd, "map_bootcv.dat"), grid.R_centers, grid.z_centers,
                             Zs / np.maximum(Zm, 1e-3 * Zm.max()))
    export_map(grid, res["flat"]["w"], os.path.join(fd, "map_flat.dat"),
               os.path.join(fd, "map_flat.tex"), title=src["name"] + " (flat)")
    pgf.write_dat(os.path.join(fd, "lagfit.dat"), f=ob["f"], tau=ob["tau_s"], sig=ob["sig_tau_s"],
                  model=np.array(d0["tau_model"]) * ob["t_g"])
    fgrid = np.geomspace(src["fit_band"][0] / 3, src["fit_band"][1] * 3, 80)
    curve_rev = fm.lag_model(w0, fgrid * ob["t_g"], ob["R_s"], ob["R_h"]) * ob["t_g"]
    curve_c = np.zeros_like(fgrid)
    if d0.get("cont_lag"):
        curve_c = d0["cont_A"] * ob["t_g"] * (fgrid * ob["t_g"] / d0["cont_nu0"]) ** (-d0["cont_index"])
    curve = curve_rev + curve_c
    pgf.write_dat(os.path.join(fd, "lagmodel.dat"), f=fgrid, tau=curve, rev=curve_rev, cont=curve_c)
    pgf.write_tex(os.path.join(fd, "lagfit.tex"),
                  pgf.errorbar_snippet(f"figures/{key}/lagfit.dat",
                                       model_dat=f"figures/{key}/lagmodel.dat",
                                       title=src["name"]))
    for lab in list(res):
        if isinstance(res[lab], dict) and "w" in res[lab] and lab != "baseline":
            res[lab].pop("w")
    C.dump_json(res, os.path.join(C.results_dir("sources"), f"{key}.json"))
    print(f"   done in {time.time()-t0:.0f} s")
