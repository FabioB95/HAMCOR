"""
s13_reflection_robustness.py — model dependence of the illumination fraction at a = 0.998.

Refits the spectrum of one observation (default Mrk 335 2006) at a = 0.998 with alternative
spectral models and reports I = R_f/(1+R_f), its statistical error and the dilution factor
for each, plus the spread.  Each variant runs in its own copy of the data directory
(data/<key>__<variant>, private copy of the spectra), so the production spectral.json is untouched.

Usage : python scripts/s13_reflection_robustness.py [key]
Output: results/robustness/<key>_reflection.json (+ printed table)
"""
import copy
import importlib.util
import json
import os
import shutil
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import config as C

spec = importlib.util.spec_from_file_location("s03", os.path.join(os.path.dirname(__file__), "s03_fit_spectra.py"))
s03 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s03)

key = sys.argv[1] if len(sys.argv) > 1 else "mrk335_2006"
cfg = C.load()
base = copy.deepcopy(cfg[key])
base["key"] = key
base["spin"] = 0.998
base["spin_systematic_alt"] = "none"

M = base["model"]
VARIANTS = {
    "baseline":      {},                                                   # broken q, R_br free
    "q_fixedRbr":    {"free_Rbr": False},                                  # R_br fixed at 6 r_g
    "no_distant":    {"model": M.replace(" + xillver", "")},               # no distant reflector
    "no_gauss":      {"model": M.replace(" + zgauss", "")},                # no extra Gaussian
    "relxillCp":     {"model": M.replace("relxill ", "relxillCp ").replace("relxill+", "relxillCp+"),
                      "free_logN": True, "refl_frac_max": 100.0},          # Comptonisation + density
    "incl30":        {"incl": 30.0},
    "incl60":        {"incl": 60.0},
}

src_dir = C.data_dir(key)
rows = {}
for name, over in VARIANTS.items():
    vkey = f"{key}__{name}"
    vdir = C.data_dir(vkey)
    os.makedirs(vdir, exist_ok=True)
    # spectra and responses: private copy (XSPEC writes into this directory)
    for root, dirs, files in os.walk(os.path.join(src_dir, "spec")):
        rel = os.path.relpath(root, src_dir)
        os.makedirs(os.path.join(vdir, rel), exist_ok=True)
        for f in files:
            if f == "spectral.json" or f.endswith((".log", ".tcl")):
                continue
            dst = os.path.join(vdir, rel, f)
            if not os.path.exists(dst):
                shutil.copy2(os.path.join(root, f), dst)
    src = copy.deepcopy(base)
    src.update(over)
    src["key"] = vkey
    print(f"=== {name}: {src['model']}  incl={src['incl']}", flush=True)
    try:
        s03.fit(src)
        sp = C.load_json(os.path.join(vdir, "spectral.json"))
        rows[name] = dict(model=src["model"], incl=src["incl"], chi2=sp["chi2"], dof=sp["dof"],
                          refl_frac=sp["refl_frac"], I=sp["I_obs"], sig_I=sp["sig_I"], D=sp["D"])
    except Exception as e:                                                # keep going
        print(f"  {name} FAILED: {e}", flush=True)
        rows[name] = dict(error=str(e))

ok = {k: v for k, v in rows.items() if "I" in v}
I = np.array([v["I"] for v in ok.values()])
summary = dict(key=key, variants=rows,
               I_min=float(I.min()) if I.size else None, I_max=float(I.max()) if I.size else None,
               I_spread_half=float(0.5 * (I.max() - I.min())) if I.size else None)
out = C.results_dir("robustness")
C.dump_json(summary, os.path.join(out, f"{key}_reflection.json"))
print("\nvariant        chi2/dof      R_f      I       sig_I    D")
for k, v in rows.items():
    if "I" in v:
        print(f"{k:13s} {v['chi2']:7.0f}/{v['dof']:<4d} {v['refl_frac']:7.2f} {v['I']:7.3f} {v['sig_I']:7.3f} {v['D']:7.3f}")
    else:
        print(f"{k:13s} FAILED")
if I.size:
    print(f"\nI range {I.min():.3f}-{I.max():.3f}  (half-spread {0.5*(I.max()-I.min()):.3f}; "
          f"threshold for the Mrk 335 2006 result: 0.06)")
print("ROBUST_DONE")
