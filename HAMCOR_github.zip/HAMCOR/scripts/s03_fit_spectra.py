"""
s03_fit_spectra.py — reflection-fraction measurement with command-line XSPEC (HEASoft 6.36).

PyXspec cannot load the relxill local model in this installation, so Python writes a
Tcl script per source and runs `xspec` on it; results come back as a key/value file.

For each source:
  1. Baseline fit (config 'model', default TBabs*relxill) over spec_range.
     relxill refl_frac R_f = (coronal flux hitting the disc)/(flux escaping)
     (Dauser et al. 2016)  =>  intercepted fraction  I_obs = R_f / (1 + R_f).
  2. Band dilution factors from the folded model (count space, like the light curves):
        R_X = rate_refl(X) / rate_cont(X)     soft, hard and every lag-energy channel
     (refl_frac = 0 -> continuum only; refl_frac < 0 -> reflection only).
  3. Uncertainties: NDRAW parameter draws from the fit covariance (tclout simpars)
     -> std of I, R_s, R_h, D.  Fallback: D evaluated at the refl_frac error bounds.
  4. Cross-check TBabs*(pexrav + zgauss) over 3-10 keV; R = Omega/2pi => I = R/2.
     Systematic on I: |I_relxill - I_pexrav| added in quadrature.

Environment: RELXILL_DIR (compiled relxill), NDRAW (default 100), XSPEC_TIMEOUT (s).
Output: data/<key>/spectral.json ; data/<key>/spec/{fit.tcl,fit.log,fit_out.txt}
        results/figures/<key>/spec_{eeuf,ratio}.dat
Usage : python scripts/s03_fit_spectra.py all | <key> ...
"""
import os
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import config as C, pgf

NDRAW = int(os.environ.get("NDRAW", "100"))
TIMEOUT = int(os.environ.get("XSPEC_TIMEOUT", "7200"))

TCL_PROCS = r"""
# tclout writes xspec_tclout in the caller's scope (local inside a proc)
proc hc_get {} {
    upvar 1 xspec_tclout v
    if {[info exists v]} { return $v }
    return $::xspec_tclout
}
proc hc_ncomp {} { tclout modcomp; return [hc_get] }
proc hc_compinfo {n} { tclout compinfo $n; return [hc_get] }
proc hc_pname {i} { tclout pinfo $i; return [lindex [hc_get] 0] }
proc hc_npar {} { tclout modpar; return [hc_get] }

# indices of parameter <pn> in every component whose name starts with <cb>
proc hc_findpars {cb pn} {
    set out {}
    for {set n 1} {$n <= [hc_ncomp]} {incr n} {
        set ci [hc_compinfo $n]
        set cn [lindex $ci 0]; set s [lindex $ci 1]; set k [lindex $ci 2]
        if {[string first $cb $cn] != 0} continue
        for {set i $s} {$i < [expr {$s + $k}]} {incr i} {
            if {[hc_pname $i] eq $pn} { lappend out $i }
        }
    }
    return $out
}

proc hc_setp {cb pn val frz {lo ""} {hi ""}} {
    foreach i [hc_findpars $cb $pn] {
        if {$lo ne ""} {
            newpar $i $val 0.01 $lo $lo $hi $hi
        } else {
            newpar $i $val
        }
        if {$frz} { freeze $i } else { thaw $i }
    }
}

proc hc_pval {i} { tclout param $i; return [lindex [hc_get] 0] }

proc hc_isfree {i} {
    tclout param $i
    if {[lindex [hc_get] 1] <= 0} { return 0 }
    tclout plink $i
    if {[lindex [hc_get] 0] eq "T"} { return 0 }
    return 1
}

proc hc_restore_range {} {
    notice all
    ignore bad
    ignore **-$::EMIN $::EMAX-**
}

proc hc_bandrate {lo hi} {
    notice all
    ignore bad
    ignore **-$lo $hi-**
    tclout rate 1
    set r [lindex [hc_get] 2]
    hc_restore_range
    return $r
}

# folded-model count rates in all bands for continuum-only and reflection-only
# the distant (xillver) reflector does not respond on reverberation time-scales:
# it is switched off while the band rates of the variable components are computed
proc hc_split_rates {} {
    set R0 [hc_pval $::IR]
    set xn {}
    foreach i $::XN { lappend xn [hc_pval $i]; newpar $i 0.0 }
    set out {}
    foreach val [list 0.0 [expr {-abs($R0)}]] {
        newpar $::IR $val 0.01 [expr {-$::RMAX}] [expr {-$::RMAX}] $::RMAX $::RMAX
        set rr {}
        foreach b $::BANDS { lappend rr [hc_bandrate [lindex $b 0] [lindex $b 1]] }
        lappend out $rr
    }
    newpar $::IR $R0 0.01 0 0 $::RMAX $::RMAX
    foreach i $::XN v $xn { newpar $i $v }
    return $out
}

proc hc_crossing {pts R} {
    # pts: {v dchi2} ordered away from the best fit; linear interpolation of dchi2 = 1
    set pv $R; set pd 0.0
    foreach p $pts {
        set v [lindex $p 0]; set d [lindex $p 1]
        if {$d >= 1.0} {
            if {$d == $pd} { return [list $v 1] }
            return [list [expr {$pv + ($v - $pv) * (1.0 - $pd) / ($d - $pd)}] 1]
        }
        if {$d > $pd} { set pv $v; set pd $d }
    }
    return [list $pv 0]
}

proc hc_profile {i} {
    # profile of chi2 in refl_frac; at every point also the soft/hard dilution rates,
    # so that D is profiled with all other parameters re-fitted.  Tracks the lowest
    # chi2 found (::PBEST) in case the starting fit was not the global minimum.
    tclout stat; set c0 [hc_get]
    set R [hc_pval $i]
    set best {}; set free {}
    for {set k 1} {$k <= [hc_npar]} {incr k} {
        lappend best [hc_pval $k]
        if {[hc_isfree $k]} { lappend free $k }
    }
    set ::PBESTD 0.0; set ::PBEST $best
    set saveB $::BANDS
    set ::BANDS [lrange $saveB 0 1]
    set low {}; set high {}
    foreach f {0.97 0.92 0.85 0.75 0.6 0.4 1.03 1.08 1.15 1.25 1.4 1.7 2.2} {
        set v [expr {$R * $f}]
        if {$v > $::RMAX} continue
        foreach k $free { catch {newpar $k [lindex $best [expr {$k - 1}]]} }
        newpar $i $v
        freeze $i
        catch {fit 200}
        tclout stat; set d [expr {[hc_get] - $c0}]
        thaw $i
        if {$d < $::PBESTD} {
            set ::PBESTD $d; set ::PBEST {}
            for {set k 1} {$k <= [hc_npar]} {incr k} { lappend ::PBEST [hc_pval $k] }
        }
        set sr [hc_split_rates]
        hc_emit prof $v $d [lindex $sr 0] [lindex $sr 1]
        if {$f < 1} { lappend low [list $v $d] } else { lappend high [list $v $d] }
    }
    set ::BANDS $saveB
    foreach k $free { catch {newpar $k [lindex $best [expr {$k - 1}]]} }
    set lo [hc_crossing $low $R]; set hi [hc_crossing $high $R]
    set flag "PROFILE"
    if {![lindex $lo 1] || ![lindex $hi 1]} { set flag "PROFILE_OPEN" }
    return [list [lindex $lo 0] [lindex $hi 0] $flag]
}

proc hc_emit_stats {} {
    tclout stat; hc_emit chi2 [hc_get]
    systematic 0
    tclout stat; hc_emit chi2_statonly [hc_get]
    systematic $::SYS
    tclout dof; hc_emit dof [lindex [hc_get] 0]
}

proc hc_emit {args} { puts $::OUT [join $args " "] }

proc hc_dump_plot {kind tag} {
    plot $kind
    foreach a {x xerr y yerr model} {
        if {[catch {tclout plot $kind $a 1}]} continue
        hc_emit ${tag}_$a [hc_get]
    }
}
"""

TCL_MAIN = r"""
query yes
chatter 10
cpd /null
abund wilm
xsect vern
statistic chi
@@LMOD@@
set OUT [open fit_out.txt w]
set EMIN @@EMIN@@
set EMAX @@EMAX@@
set SYS @@SYS@@
set RMAX @@RMAX@@
set BANDS {@@BANDS@@}
@@PROCS@@
if {[catch {
data 1:1 src_grp.pha
ignore bad
ignore **-$EMIN $EMAX-**
model @@MODEL@@ & /*
@@SETUP@@
@@MAINSETUP@@
set IR [lindex [concat [hc_findpars relxill refl_frac] [hc_findpars pexrav rel_refl]] 0]
# non-variable distant components (xillver, narrow photoionised lines)
set XN [concat [hc_findpars xillver norm] [hc_findpars zgauss norm]]
if {$IR eq ""} { hc_emit error no_reflection_component; close $OUT; exit }
systematic @@SYS@@
fit 500
fit 500
tclout stat; hc_emit chi2 $xspec_tclout
systematic 0
tclout stat; hc_emit chi2_statonly $xspec_tclout
systematic @@SYS@@
tclout dof;  hc_emit dof [lindex $xspec_tclout 0]
set RF [hc_pval $IR]
hc_emit refl_frac $RF
# 1-sigma interval of refl_frac from a profile (refit at fixed refl_frac): robust where
# XSPEC 'error' fails on the q1/Rbr/refl_frac degeneracy
set EB [hc_profile $IR]
set it 0
while {$PBESTD < -0.5 && $it < 3} {
    # the profile found a lower minimum: restart from it and redo the profile
    hc_emit profreset $PBESTD
    for {set k 1} {$k <= [hc_npar]} {incr k} {
        if {[hc_isfree $k] || $k == $IR} { catch {newpar $k [lindex $PBEST [expr {$k - 1}]]} }
    }
    thaw $IR
    fit 500
    fit 500
    hc_emit_stats
    set RF [hc_pval $IR]
    hc_emit refl_frac $RF
    set EB [hc_profile $IR]
    incr it
}
hc_emit refl_frac_err [lindex $EB 0] [lindex $EB 1] [lindex $EB 2]
for {set i 1} {$i <= [hc_npar]} {incr i} {
    tclout param $i
    hc_emit par $i [hc_pname $i] [lindex $xspec_tclout 0] [hc_isfree $i]
}
set sr [hc_split_rates]
hc_emit rates_cont [lindex $sr 0]
hc_emit rates_refl [lindex $sr 1]

setplot energy
hc_dump_plot eeufspec eeuf
hc_dump_plot ratio ratio

# covariance draws
fit 500
set best {}
set free {}
for {set i 1} {$i <= [hc_npar]} {incr i} {
    lappend best [hc_pval $i]
    if {[hc_isfree $i]} { lappend free $i }
}
set saveB $BANDS
set BANDS [lrange $saveB 0 1]
# draw all parameter sets first: changing a parameter invalidates the covariance
set SP {}
for {set d 0} {$d < @@NDRAW@@} {incr d} {
    if {[catch {tclout simpars}]} break
    lappend SP $xspec_tclout
}
hc_emit nsimpars [llength $SP]
set ok 0
if {[llength $SP] > 0} { hc_emit simpars_len [llength [lindex $SP 0]] [hc_npar] [llength $free] }
foreach sp $SP {
    if {[llength $sp] == [hc_npar]} {
        foreach i $free { catch {newpar $i [lindex $sp [expr {$i - 1}]]} }
    } elseif {[llength $sp] == [llength $free]} {
        foreach i $free v $sp { catch {newpar $i $v} }
    } else { break }
    set rf [hc_pval $IR]
    if {$rf < 0} { set rf 0.0; newpar $IR 0.0 }
    set sr [hc_split_rates]
    hc_emit draw $rf [lindex $sr 0] [lindex $sr 1]
    incr ok
}
for {set i 1} {$i <= [hc_npar]} {incr i} {
    if {[lsearch $free $i] >= 0} { newpar $i [lindex $best [expr {$i - 1}]] }
}
hc_emit ndraw $ok

# fallback: dilution at the refl_frac error bounds
set elo [lindex $EB 0]; set ehi [lindex $EB 1]
foreach tag {lo hi} v [list $elo $ehi] {
    if {$v <= 0} { set v 1e-3 }
    newpar $IR $v
    set sr [hc_split_rates]
    hc_emit bound_$tag $v [lindex $sr 0] [lindex $sr 1]
}
newpar $IR $RF
set BANDS $saveB

# spin systematic: the same model refitted at a = SPINALT (HAMCOR is Schwarzschild;
# the spectra may prefer a spinning hole).  |I(a_alt) - I(a)| and |D(a_alt) - D(a)| are
# added in quadrature to the uncertainties.
set ia [lindex [hc_findpars relxill a] 0]
if {$ia ne "" && "@@SPINALT@@" ne "none"} {
    if {[catch {
        newpar $ia @@SPINALT@@
        catch {fit 500}
        catch {fit 500}
        tclout stat; hc_emit chi2_spinalt [hc_get]
        hc_emit refl_frac_spinalt [hc_pval $IR]
        set BANDS [lrange $saveB 0 1]
        set sr [hc_split_rates]
        hc_emit rates_spinalt [lindex $sr 0] [lindex $sr 1]
        set BANDS $saveB
    } smsg]} { hc_emit spinalt_failed [string map {"\n" " "} $smsg]; set BANDS $saveB }
}

# pexrav 3-10 keV cross-check (non-essential: failures are reported, not fatal)
if {[catch {
model clear
set XN {}
set EMIN 3.0
set EMAX 10.0
hc_restore_range
model @@PEXMODEL@@ & /*
@@SETUP@@
set IR [lindex [hc_findpars pexrav rel_refl] 0]
systematic @@SYS@@
renorm
if {[catch {fit 500}]} {
    hc_emit pexrav_retry nan_with_systematic
    systematic 0
    foreach i [hc_findpars zgauss Sigma] { newpar $i 0.1; freeze $i }
    renorm
    fit 500
}
fit 500
tclout stat; hc_emit chi2_pexrav $xspec_tclout
tclout dof;  hc_emit dof_pexrav [lindex $xspec_tclout 0]
hc_emit pexrav_R [hc_pval $IR]
if {![catch {error stopat 20 0.05 maximum 50 1.0 $IR}]} {
    tclout error $IR; hc_emit pexrav_R_err $xspec_tclout
}
} pmsg]} { hc_emit pexrav_failed [string map {"\n" " "} $pmsg] }
hc_emit done 1
} msg]} { hc_emit tclerror [string map {"\n" " "} $msg] [string map {"\n" " | "} $::errorInfo] }
close $OUT
exit
"""


def setup_block(src):
    z, incl = src["z"], src["incl"]
    nh_frz = 0 if src["key"] == "cygx1" else 1
    cosi = float(np.cos(np.radians(incl)))
    spin = src.get("spin", 0.998)
    # Schwarzschild (a = 0): the disc starts at 6 r_g, so a broken emissivity with
    # R_br < 6 r_g is unconstrained (singular covariance).  A single power law q is used.
    single_q = spin < 0.5
    L = [
        f"hc_setp TBabs nH {src['nH_gal']} {nh_frz}",
        "hc_setp zxipcf Nh 5.0 0", "hc_setp zxipcf log_xi 1.0 0", "hc_setp zxipcf CvrFract 0.5 0",
        f"hc_setp zxipcf z {z} 1", f"hc_setp zxipcf Redshift {z} 1",
        f"hc_setp relxill Index1 {3.0 if single_q else 4.0} 0 {float(src.get('q1_min', 0.0 if single_q else 3.0))} 10.0",
        "hc_setp relxill Index2 3.0 1",
        ("hc_setp relxill Rbr 15.0 1" if single_q else
         ("hc_setp relxill Rbr 6.0 0 2.0 30.0" if src.get("free_Rbr", True) else "hc_setp relxill Rbr 6.0 1")),
        f"hc_setp relxill a {spin} 1", f"hc_setp relxill Incl {incl} 1",
        "hc_setp relxill Rin -1.0 1", "hc_setp relxill Rout 400.0 1", f"hc_setp relxill z {z} 1",
        "hc_setp relxill gamma 2.2 0 1.4 3.4", "hc_setp relxill logxi 2.0 0 0.0 4.7",
        "hc_setp relxill Afe 3.0 0 0.5 10.0", "hc_setp relxill Ecut 300.0 1",
        f"hc_setp relxill refl_frac 1.0 0 0.0 {float(src.get('refl_frac_max', 20.0))}",
        "hc_setp relxill logN 17.0 0 15.0 20.0" if src.get("free_logN", False) else "hc_setp relxill logN 15.0 1",
        "hc_setp pexrav PhoIndex 2.0 0", "hc_setp pexrav foldE 300.0 1",
        "hc_setp pexrav rel_refl 1.0 0 0.0 10.0", f"hc_setp pexrav Redshift {z} 1",
        f"hc_setp pexrav cosIncl {cosi:.5f} 1",
        "hc_setp zgauss LineE 6.4 0 6.0 7.0", "hc_setp zgauss Sigma 0.2 0 0.0 1.0",
        f"hc_setp zgauss Redshift {z} 1",
        "hc_setp diskbb Tin 0.3 0",
        # distant neutral reflector (narrow Fe K alpha + Compton hump): xillver,
        # reflection only, Gamma and A_Fe tied to the relativistic component
        "hc_setp xillver logxi 0.0 1", "hc_setp xillver Ecut 300.0 1",
        f"hc_setp xillver Incl {incl} 1", f"hc_setp xillver z {z} 1",
        "hc_setp xillver refl_frac -1.0 1 -10.0 10.0", "hc_setp xillver norm 1e-4 0",
        "foreach pn {gamma Afe A_Fe} {",
        "    set rg [lindex [hc_findpars relxill $pn] 0]",
        "    foreach xc [hc_findpars xillver $pn] { if {$rg ne \"\"} { newpar $xc = p$rg } }",
        "}",
    ]
    return "\n".join(L)


def main_setup(src):
    """Main-model-only settings: second absorber starting values, Fe XXVI line, relxillCp."""
    z = src["z"]
    L = [
        # a second partial coverer starts from a different (more ionised, thicker) state
        "set zx [hc_findpars zxipcf Nh]",
        "if {[llength $zx] > 1} {",
        "    newpar [lindex $zx 1] 20.0",
        "    newpar [lindex [hc_findpars zxipcf log_xi] 1] 2.5",
        "    newpar [lindex [hc_findpars zxipcf CvrFract] 1] 0.7",
        "}",
        "hc_setp relxill kTe 60.0 1",
    ]
    if src.get("spin", 0.998) < 0.5:                       # single emissivity index
        L += ["set i1 [lindex [hc_findpars relxill Index1] 0]",
              "set i2 [lindex [hc_findpars relxill Index2] 0]",
              "if {$i1 ne \"\" && $i2 ne \"\"} { newpar $i2 = p$i1 }"]
    if "zgauss" in src["model"]:
        L += ["hc_setp zgauss LineE 6.97 0 6.8 7.1", "hc_setp zgauss Sigma 0.01 1",
              f"hc_setp zgauss Redshift {z} 1", "hc_setp zgauss norm 1e-5 0 0.0 1.0"]
    return "\n".join(L)


def make_tcl(src, bands):
    rd = os.environ.get("RELXILL_DIR", "")
    lmod = f"lmod relxill {rd}" if ("relxill" in src["model"] and rd) else ""
    emin, emax = src["spec_range"]
    rep = {
        "@@LMOD@@": lmod, "@@EMIN@@": str(emin), "@@EMAX@@": str(emax),
        "@@BANDS@@": " ".join(f"{{{lo} {hi}}}" for lo, hi in bands),
        "@@PROCS@@": TCL_PROCS, "@@MODEL@@": src["model"],
        "@@PEXMODEL@@": src["pexrav_model"], "@@SETUP@@": setup_block(src),
        "@@MAINSETUP@@": main_setup(src), "@@SYS@@": str(src.get("spec_systematic", 0.0)),
        "@@RMAX@@": str(float(src.get("refl_frac_max", 20.0))),
        "@@SPINALT@@": str(src.get("spin_systematic_alt", "none")),
        "@@NDRAW@@": str(NDRAW),
    }
    s = TCL_MAIN
    for k, v in rep.items():
        s = s.replace(k, v)
    return s


def parse(path):
    out = {}
    with open(path) as f:
        for line in f:
            t = line.split()
            if not t:
                continue
            k, v = t[0], t[1:]
            if k == "profreset":
                out["prof"] = []
                out.setdefault("profreset", []).append(v)
            elif k in ("par", "draw", "bound_lo", "bound_hi", "prof"):
                out.setdefault(k, []).append(v)
            else:
                out[k] = v
    return out


def ratio(refl, cont):
    refl, cont = np.asarray(refl, float), np.asarray(cont, float)
    return refl / np.maximum(cont, 1e-30)


def Dfac(rs, rh):
    return rs / (1 + rs) - rh / (1 + rh)


def fit(src):
    key = src["key"]
    sd = os.path.join(C.data_dir(key), "spec")
    if not os.path.exists(os.path.join(sd, "src_grp.pha")):
        print(f"  {key}: no spectrum (run s01)"); return
    eb = src["lag_energy_bins"]
    bands = [tuple(src["soft_band"]), tuple(src["hard_band"])] + \
            [(eb[i], eb[i + 1]) for i in range(len(eb) - 1)]
    nb = len(bands)
    with open(os.path.join(sd, "fit.tcl"), "w") as f:
        f.write(make_tcl(src, bands))
    outp = os.path.join(sd, "fit_out.txt")
    if os.path.exists(outp):
        os.remove(outp)
    print(f"  {key}: running xspec (log: data/{key}/spec/fit.log) ...", flush=True)
    with open(os.path.join(sd, "fit.log"), "w") as lg:
        subprocess.run(["xspec", "-", "fit.tcl"], cwd=sd, input="exit\n", text=True,
                       stdout=lg, stderr=subprocess.STDOUT, timeout=TIMEOUT)
    if not os.path.exists(outp):
        print(f"  ERROR {key}: no fit_out.txt — see fit.log"); return
    r = parse(outp)
    if "error" in r:
        print(f"  ERROR {key}: {' '.join(r['error'])}"); return
    if "pexrav_failed" in r or "pexrav_retry" in r:
        print(f"  {key}: pexrav cross-check: "
              f"{'failed' if 'pexrav_failed' in r else 'refit without systematic'}")
    if "tclerror" in r:
        print(f"  Tcl error in {key}: {' '.join(r['tclerror'])}")
    if "done" not in r:
        print(f"  WARNING {key}: xspec stopped early — see fit.log (partial results used)")

    if "chi2" not in r or "dof" not in r or "refl_frac_err" not in r:
        print(f"  ERROR {key}: fit did not complete — see data/{key}/spec/fit.log"); return
    chi2, dof = float(r["chi2"][0]), int(float(r["dof"][0]))
    Rf = float(r["refl_frac"][0])
    Rf_lo, Rf_hi = float(r["refl_frac_err"][0]), float(r["refl_frac_err"][1])
    prof = np.array(r.get("prof", []), float)
    if prof.size and prof[:, 1].min() < -0.5:
        print(f"  WARNING {key}: profile found a lower chi2 (dchi2={prof[:,1].min():.1f}): "
              f"fit not at the global minimum")
    rc = np.array(r["rates_cont"], float)
    rr = np.array(r["rates_refl"], float)
    Rb = ratio(rr, rc)
    R_s, R_h, R_E = float(Rb[0]), float(Rb[1]), Rb[2:]
    rcE, rrE = rc[2:], rr[2:]
    R_ref = (rrE.sum() - rrE) / np.maximum(rcE.sum() - rcE, 1e-30)
    D0 = Dfac(R_s, R_h)
    I_rx = Rf / (1 + Rf)

    # uncertainties: (i) covariance draws, (ii) chi2 profile in refl_frac with all other
    # parameters re-fitted (D evaluated at every profile point).  The larger is used:
    # draws miss non-Gaussian degeneracies, the profile misses directions orthogonal to R_f.
    sI_prof = 0.5 * abs(Rf_hi / (1 + Rf_hi) - Rf_lo / (1 + Rf_lo))
    sD_prof = np.nan
    if prof.ndim == 2 and prof.shape[1] >= 6:
        dch = prof[:, 1]
        Dp = Dfac(ratio(prof[:, 4], prof[:, 2]), ratio(prof[:, 5], prof[:, 3]))
        side = np.sign(prof[:, 0] - Rf)
        Dlim = [D0]
        for sgn in (-1, 1):
            m = side == sgn
            if not m.any():
                continue
            o = np.argsort(np.abs(prof[m, 0] - Rf))
            dd, DD = np.r_[0.0, dch[m][o]], np.r_[D0, Dp[m][o]]
            for j in range(1, len(dd)):
                if dd[j] <= 1.0:
                    Dlim.append(DD[j])
                    continue
                w = (1.0 - dd[j - 1]) / max(dd[j] - dd[j - 1], 1e-12)
                Dlim.append(DD[j - 1] + np.clip(w, 0, 1) * (DD[j] - DD[j - 1]))
                break
        sD_prof = 0.5 * (max(Dlim) - min(Dlim)) / abs(D0)
    draws = np.array(r.get("draw", []), float)
    if draws.ndim == 2 and len(draws) > 10 and draws.shape[1] == 5:
        Id = draws[:, 0] / (1 + draws[:, 0])
        Dd = Dfac(ratio(draws[:, 3], draws[:, 1]), ratio(draws[:, 4], draws[:, 2]))
        sI_d, sD_d, unc = float(np.std(Id)), float(np.std(Dd) / abs(D0)), f"{len(draws)} draws + profile"
    else:
        sI_d, sD_d, unc = 0.0, 0.0, "profile only"
    sI_stat = float(max(sI_d, sI_prof))
    sD_stat = float(np.nanmax([sD_d, sD_prof, 0.0]))
    I_alt = D_alt = chi2_alt = np.nan
    if "refl_frac_spinalt" in r and "rates_spinalt" in r:
        ra = float(r["refl_frac_spinalt"][0])
        v = np.array(r["rates_spinalt"], float)          # cont(2) refl(2)
        I_alt = ra / (1 + ra)
        D_alt = Dfac(v[2] / max(v[0], 1e-30), v[3] / max(v[1], 1e-30))
        chi2_alt = float(r["chi2_spinalt"][0])
    sI_spin = abs(I_alt - I_rx) if np.isfinite(I_alt) else 0.0
    sD_spin = abs(D_alt - D0) / abs(D0) if np.isfinite(D_alt) else 0.0
    sI = float(np.hypot(sI_stat, sI_spin))
    sD_frac = float(np.hypot(sD_stat, sD_spin))

    Rp = float(r["pexrav_R"][0]) if "pexrav_R" in r else np.nan
    I_px = min(Rp / 2.0, 0.999) if np.isfinite(Rp) else np.nan
    # pexrav (Newtonian slab, R = Omega/2pi) is reported only: for R_f > 1 it is not a
    # like-for-like estimate of the intercepted fraction, so it is not used in sig_I
    sig_I = sI

    fd = C.results_dir("figures", key)
    if "eeuf_x" in r:
        pgf.write_dat(os.path.join(fd, "spec_eeuf.dat"),
                      E=np.array(r["eeuf_x"], float), dE=np.array(r["eeuf_xerr"], float),
                      y=np.array(r["eeuf_y"], float), dy=np.array(r["eeuf_yerr"], float),
                      model=np.array(r["eeuf_model"], float))
    if "ratio_x" in r:
        pgf.write_dat(os.path.join(fd, "spec_ratio.dat"),
                      E=np.array(r["ratio_x"], float), dE=np.array(r["ratio_xerr"], float),
                      r=np.array(r["ratio_y"], float), dr=np.array(r["ratio_yerr"], float))

    params = {f"{p[1]}_{p[0]}": float(p[2]) for p in r.get("par", [])}

    def pget(name):
        for k, v in params.items():
            if k.rsplit("_", 1)[0] == name:
                return v
        return float("nan")
    out = dict(key=key, model=src["model"], chi2=chi2, dof=dof,
               spec_systematic=float(src.get("spec_systematic", 0.0)),
               chi2_statonly=float(r["chi2_statonly"][0]) if "chi2_statonly" in r else np.nan,
               refl_frac=Rf, refl_frac_err=[Rf_lo, Rf_hi], refl_frac_profile=prof, I_relxill=I_rx, sig_I_stat=sI,
               pexrav_R=Rp, I_pexrav=I_px,
               chi2_pexrav=float(r["chi2_pexrav"][0]) if "chi2_pexrav" in r else np.nan,
               dof_pexrav=int(float(r["dof_pexrav"][0])) if "dof_pexrav" in r else 0,
               I_obs=I_rx, sig_I=sig_I,
               R_s=R_s, R_h=R_h, D=D0, sig_D_frac=sD_frac, uncertainty_method=unc,
               sig_D_frac_draws=sD_d, sig_D_frac_profile=sD_prof, sig_I_draws=sI_d, sig_I_profile=sI_prof,
               spin=float(src.get("spin", 0.998)), spin_alt=src.get("spin_systematic_alt"),
               I_spinalt=I_alt, D_spinalt=D_alt, chi2_spinalt=chi2_alt,
               sig_I_spin=sI_spin, sig_D_frac_spin=sD_spin,
               n_profile_restarts=len(r.get("profreset", [])),
               R_E=R_E, R_ref=R_ref, bands=bands, params=params)
    assert len(R_E) == nb - 2
    C.dump_json(out, os.path.join(C.data_dir(key), "spectral.json"))
    print(f"  {key}: chi2/dof={chi2:.0f}/{dof} (sys {100*out['spec_systematic']:.0f}%, "
          f"stat-only {out['chi2_statonly']:.0f})  Rbr={pget('Rbr'):.1f} q1={pget('Index1'):.1f} "
          f"logN={pget('logN'):.1f}\n    R_f={Rf:.2f} [{Rf_lo:.2f},{Rf_hi:.2f}]  "
          f"I={I_rx:.3f}+/-{sig_I:.3f} (pexrav I={I_px:.3f})  R_s={R_s:.3f} R_h={R_h:.3f} "
          f"D={D0:.3f} (+/-{100*sD_frac:.0f}%, {unc})\n    spin a={src.get('spin_systematic_alt')}: "
          f"chi2={chi2_alt:.0f}  I={I_alt:.3f}  D={D_alt:.3f}")


if __name__ == "__main__":
    cfg = C.load()
    keys = list(cfg) if (len(sys.argv) < 2 or sys.argv[1] == "all") else sys.argv[1:]
    for k in keys:
        try:
            fit(cfg[k])
        except Exception as e:
            print(f"  ERROR {k}: {e}")
