"""
s01_sas_extract.py — EPIC-pn reduction: events, flares, regions, background-subtracted
light curves (soft, hard, lag-energy channels) and spectra with responses.

Requires HEASoft + SAS initialised in the shell (heainit; source $SAS_DIR/setsas.sh).
Input:   data/raw/<obsid>/  containing the extracted ODF (any depth), or data/raw/<obsid>.tar
Output:  data/<key>/sas/...           SAS products + sas.log
         data/<key>/lightcurves.npz   time, rate/err per band (net, epiclccorr-corrected)
         data/<key>/spec/{src_grp.pha, src.pha, bkg.pha, src.rmf, src.arf}
         data/<key>/regions.reg       ds9 region file: CHECK IT
         data/<key>/header.json       OBJECT / DATE-OBS / SUBMODE / FILTER / exposure

Usage:   python scripts/s01_sas_extract.py mrk335_2006 [more keys ...]   (or 'all')
"""
import glob
import os
import re
import shutil
import subprocess
import sys
import tarfile

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import config as C

ARCSEC_PER_PHYS = 0.05


def sh(cmd, cwd, env, log):
    with open(log, "a") as L:
        L.write(f"\n$ {cmd}\n")
        r = subprocess.run(cmd, shell=True, cwd=cwd, env=env, executable="/bin/bash",
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        L.write(r.stdout)
    if r.returncode != 0:
        print(r.stdout[-3000:])
        raise RuntimeError(f"failed: {cmd.split()[0]}  (see {log})")
    return r.stdout


def sky_xy(evt, ra, dec, ecoord_out=""):
    """Sky (X,Y) of (ra,dec): parse ecoordconv, else TAN projection from the event header."""
    m = re.search(r"\bX\s*[:=]\s*([-\d.eE+]+)[\s,]+Y\s*[:=]\s*([-\d.eE+]+)", ecoord_out)
    if m:
        return float(m.group(1)), float(m.group(2))
    from astropy.io import fits
    h = fits.getheader(evt, "EVENTS")
    col = {h[f"TTYPE{i}"].strip(): i for i in range(1, h["TFIELDS"] + 1)}
    ix, iy = col["X"], col["Y"]
    a0, d0 = np.radians(h[f"TCRVL{ix}"]), np.radians(h[f"TCRVL{iy}"])
    a, d = np.radians(ra), np.radians(dec)
    cosc = np.sin(d0) * np.sin(d) + np.cos(d0) * np.cos(d) * np.cos(a - a0)
    xi = np.cos(d) * np.sin(a - a0) / cosc
    eta = (np.cos(d0) * np.sin(d) - np.sin(d0) * np.cos(d) * np.cos(a - a0)) / cosc
    X = h[f"TCRPX{ix}"] + np.degrees(xi) / h[f"TCDLT{ix}"]
    Y = h[f"TCRPX{iy}"] + np.degrees(eta) / h[f"TCDLT{iy}"]
    return float(X), float(Y)


def _coverage(H, xc, yc, X, Y, r):
    m = (xc[:, None] - X) ** 2 + (yc[None, :] - Y) ** 2 < r ** 2
    return (H[m] > 0).mean() if m.any() else 0.0, (np.median(H[m]) if m.any() else np.inf)


def place_bkg(evt, X0, Y0, r_s, r_b, Xp, Yp, binsz=320.0):
    """Background circle fully on the source CCD/window, away from the source.

    Occupancy map of all events on the source CCD in 16" pixels; a candidate circle is
    acceptable if >= 98% of its pixels contain events.  The configured circle is kept if
    acceptable and >= 3 r_s + r_b from the source; otherwise (e.g. Small Window) the
    radius is reduced if needed (down to 20") and the acceptable candidate, edge >= 2 r_s
    from the source, whose median pixel count is closest to the CCD median (no source
    wings, no serendipitous sources) and nearest to the source is used."""
    from astropy.io import fits
    ev = fits.getdata(evt, 1)
    x, y, ccd = ev["X"].astype(float), ev["Y"].astype(float), ev["CCDNR"]
    near = (x - X0) ** 2 + (y - Y0) ** 2 < r_s ** 2
    c0 = np.bincount(ccd[near]).argmax()
    sel = (ccd == c0) & (x > 0) & (y > 0)
    xs, ys = x[sel], y[sel]
    pad = 2 * r_b                     # circles crossing the CCD edge must count as uncovered
    xe = np.arange(xs.min() - pad, xs.max() + pad + binsz, binsz)
    ye = np.arange(ys.min() - pad, ys.max() + pad + binsz, binsz)
    H, _, _ = np.histogram2d(xs, ys, bins=[xe, ye])
    xc, yc = 0.5 * (xe[1:] + xe[:-1]), 0.5 * (ye[1:] + ye[:-1])
    far = (xc[:, None] - X0) ** 2 + (yc[None, :] - Y0) ** 2 > (4 * r_s) ** 2
    ref = np.median(H[far & (H > 0)]) if (far & (H > 0)).any() else 1.0
    cov, _ = _coverage(H, xc, yc, Xp, Yp, r_b)
    if cov >= 0.98 and np.hypot(Xp - X0, Yp - Y0) >= 3 * r_s + r_b:
        return Xp, Yp, r_b, cov
    # small windows: shrink the circle (down to 20") and allow its edge >= 2 r_s from the source
    for rb in [r_b] + [v / ARCSEC_PER_PHYS for v in (40.0, 35.0, 30.0, 25.0, 20.0)
                       if v / ARCSEC_PER_PHYS < r_b]:
        best = None
        for d in np.arange(2 * r_s + rb, 12000.0, 100.0):
            for a in np.radians(np.arange(0, 360, 10)):
                X, Y = X0 + d * np.cos(a), Y0 + d * np.sin(a)
                c, med = _coverage(H, xc, yc, X, Y, rb)
                if c < 0.98:
                    continue
                score = (round(abs(med - ref) / max(ref, 1.0), 1), d)
                if best is None or score < best[0]:
                    best = (score, X, Y, c)
        if best is not None:
            print(f"  background moved: configured circle coverage {100*cov:.0f}% -> "
                  f"r={rb*ARCSEC_PER_PHYS:.0f}\" at {best[0][1]*ARCSEC_PER_PHYS:.0f}\" from source")
            return best[1], best[2], rb, best[3]
    print("  WARNING: no background circle fully on the source CCD; keeping configured one")
    return Xp, Yp, r_b, cov


def find_odf(obsid):
    raw = os.path.join(C.WORK, "data", "raw")
    tar = os.path.join(raw, f"{obsid}.tar")
    d = os.path.join(raw, obsid)
    if not os.path.isdir(d) and os.path.exists(tar):
        os.makedirs(d)
        with tarfile.open(tar) as t:
            t.extractall(d)
    for inner in glob.glob(os.path.join(d, "**", "*.TAR"), recursive=True) + \
            glob.glob(os.path.join(d, "**", "*.tar.gz"), recursive=True):
        with tarfile.open(inner) as t:
            t.extractall(os.path.dirname(inner))
        os.remove(inner)
    sums = glob.glob(os.path.join(d, "**", "*SUM.ASC"), recursive=True)
    if not sums:
        raise FileNotFoundError(f"no ODF (*SUM.ASC) under {d}")
    return os.path.dirname(sums[0])


def header_info(evt):
    from astropy.io import fits
    h = fits.getheader(evt, 1)
    keys = ["OBJECT", "DATE-OBS", "DATE-END", "SUBMODE", "FILTER", "TSTART", "TSTOP",
            "RA_OBJ", "DEC_OBJ", "OBS_ID"]
    return {k: h.get(k) for k in keys}


def pi_range(band):
    return int(round(band[0] * 1000)), int(round(band[1] * 1000))


def process(src):
    key, obsid = src["key"], src["obsid"]
    out = C.data_dir(key)
    wd = os.path.join(out, "sas")
    os.makedirs(wd, exist_ok=True)
    os.makedirs(os.path.join(out, "spec"), exist_ok=True)
    log = os.path.join(wd, "sas.log")
    env = dict(os.environ)
    if "SAS_DIR" not in env:
        raise EnvironmentError("SAS not initialised: run heainit and setsas first")

    # ── 1. CCF, ODF ingestion, epproc ──────────────────────────────────────
    evts = glob.glob(os.path.join(wd, "*EPN*Evts.ds"))
    if not evts:
        odf = find_odf(obsid)
        env["SAS_ODF"] = odf
        sh("cifbuild", wd, env, log)
        env["SAS_CCF"] = os.path.join(wd, "ccf.cif")
        sh("odfingest outdir=.", wd, env, log)
        env["SAS_ODF"] = glob.glob(os.path.join(wd, "*SUM.SAS"))[0]
        sh("epproc", wd, env, log)
        evts = glob.glob(os.path.join(wd, "*EPN*Evts.ds"))
    else:
        env["SAS_CCF"] = os.path.join(wd, "ccf.cif")
        env["SAS_ODF"] = glob.glob(os.path.join(wd, "*SUM.SAS"))[0]
    # several pn exposures can exist in one observation (e.g. an interrupted exposure):
    # list them and use the longest (TSTOP - TSTART), not the largest file
    from astropy.io import fits as _f
    def _dur(e):
        h = _f.getheader(e, 1)
        return float(h["TSTOP"]) - float(h["TSTART"])
    evts = sorted(evts, key=_dur)[::-1]
    for e in evts:
        h = _f.getheader(e, 1)
        print(f"  pn exposure {os.path.basename(e)}: {_dur(e)/1e3:.1f} ks, "
              f"SUBMODE={h.get('SUBMODE', '?')}, start {h.get('DATE-OBS', '?')}")
    evt = evts[0]
    hdr = header_info(evt)
    print(f"  OBJECT={hdr['OBJECT']}  DATE-OBS={hdr['DATE-OBS']}  SUBMODE={hdr['SUBMODE']}"
          f"  FILTER={hdr['FILTER']}   <-- VERIFY against config")
    timing = src["mode"] == "timing" or "Timing" in evt or "Burst" in evt
    C.dump_json(dict(header=hdr, event_file=os.path.basename(evt), timing=timing),
                os.path.join(out, "header.json"))

    # ── 2. soft-proton flares ──────────────────────────────────────────────
    if not timing:
        sh(f"evselect table={evt} withrateset=Y rateset=flare.lc maketimecolumn=Y "
           f"timebinsize=100 makeratecolumn=Y "
           f"expression='#XMMEA_EP&&(PI>10000&&PI<12000)&&(PATTERN==0)'", wd, env, log)
        sh(f"tabgtigen table=flare.lc expression='RATE<={src['flare_rate']}' gtiset=gti.fits",
           wd, env, log)
    gti = "&&GTI(gti.fits,TIME)" if not timing else ""

    # ── 3. regions ─────────────────────────────────────────────────────────
    if not timing:
        sh(f"evselect table={evt} imagebinning=binSize imageset=img.fits withimageset=yes "
           f"xcolumn=X ycolumn=Y ximagebinsize=80 yimagebinsize=80 "
           f"expression='#XMMEA_EP&&PATTERN<=4&&PI in [300:10000]'", wd, env, log)
        o = sh(f"ecoordconv imageset=img.fits x={src['ra']} y={src['dec']} coordtype=eqpos",
               wd, env, log)
        X0, Y0 = sky_xy(evt, src["ra"], src["dec"], o)
        print(f"  source sky position X={X0:.1f} Y={Y0:.1f}")
        r_s = src["src_radius_arcsec"] / ARCSEC_PER_PHYS
        r_b = src["bkg_radius_arcsec"] / ARCSEC_PER_PHYS
        dx, dy = src["bkg_offset_arcsec"]
        Xb, Yb = X0 - dx / ARCSEC_PER_PHYS, Y0 + dy / ARCSEC_PER_PHYS   # sky X grows to west
        Xb, Yb, r_b, cov = place_bkg(evt, X0, Y0, r_s, r_b, Xb, Yb)
        print(f"  background circle coverage on source CCD: {100*cov:.1f}%")
        src_reg = f"((X,Y) IN circle({X0:.1f},{Y0:.1f},{r_s:.1f}))"
        bkg_reg = f"((X,Y) IN circle({Xb:.1f},{Yb:.1f},{r_b:.1f}))"
        with open(os.path.join(out, "regions.reg"), "w") as f:
            f.write("# Region file format: DS9\nphysical\n"
                    f"circle({X0:.1f},{Y0:.1f},{r_s:.1f}) # color=green text={{src}}\n"
                    f"circle({Xb:.1f},{Yb:.1f},{r_b:.1f}) # color=red text={{bkg}}\n")
        flt = "#XMMEA_EP&&PATTERN<=4&&FLAG==0"
    else:
        from astropy.io import fits
        ev = fits.getdata(evt, 1)
        sel = (ev["PI"] > 500) & (ev["PI"] < 10000)
        cx = int(np.bincount(ev["RAWX"][sel]).argmax())
        hw, ex = int(src["rawx_halfwidth"]), int(src.get("exclude_core_rawx", 0))
        src_reg = f"(RAWX in [{cx-hw}:{cx+hw}])"
        if ex > 0:
            src_reg += f"&&!(RAWX in [{cx-ex}:{cx+ex}])"
        bkg_reg = "(RAWX in [3:5])"
        with open(os.path.join(out, "regions.reg"), "w") as f:
            f.write(f"# timing mode: src {src_reg}  bkg {bkg_reg}  peak RAWX={cx}\n")
        flt = "PATTERN<=4&&FLAG==0"
    print(f"  src: {src_reg}\n  bkg: {bkg_reg}   (check data/{key}/regions.reg)")

    if not timing:   # pile-up diagnostic (inspect epat.ps)
        sh(f"evselect table={evt} withfilteredset=yes filteredset=src_filt.ds "
           f"keepfilteroutput=yes expression='{flt}&&{src_reg}{gti}'", wd, env, log)
        try:
            sh("epatplot set=src_filt.ds plotfile=epat.ps useplotfile=yes", wd, env, log)
        except RuntimeError:
            print("  (epatplot failed; skipping pile-up plot)")

    # ── 4. light curves ────────────────────────────────────────────────────
    T0, T1 = float(hdr["TSTART"]), float(hdr["TSTOP"])
    dt = float(src["dt"])
    bands = {"soft": src["soft_band"], "hard": src["hard_band"]}
    eb = src["lag_energy_bins"]
    for i in range(len(eb) - 1):
        bands[f"E{i:02d}"] = [eb[i], eb[i + 1]]
    lc_gti = gti if src["gti_lightcurves"] else ""
    lcs = {}
    for name, band in bands.items():
        a, b = pi_range(band)
        reuse = os.environ.get("REUSE_LC") == "1" and \
            os.path.exists(os.path.join(wd, f"net_{name}.lc"))
        if not reuse:
            for tag, reg in (("src", src_reg), ("bkg", bkg_reg)):
                sh(f"evselect table={evt} energycolumn=PI withrateset=yes rateset={tag}_{name}.lc "
                   f"timebinsize={dt} maketimecolumn=yes makeratecolumn=yes "
                   f"timemin={T0} timemax={T1} "
                   f"expression='{flt}&&(PI in [{a}:{b}])&&{reg}{lc_gti}'", wd, env, log)
            sh(f"epiclccorr srctslist=src_{name}.lc eventlist={evt} outset=net_{name}.lc "
               f"bkgtslist=bkg_{name}.lc withbkgset=yes applyabsolutecorrections=yes",
               wd, env, log)
        from astropy.io import fits
        d = fits.getdata(os.path.join(wd, f"net_{name}.lc"), 1)
        rate, err = np.array(d["RATE"], float), np.array(d["ERROR"], float)
        if "FRACEXP" in d.names:
            # FRACEXP includes the live-time fraction (~0.71 in Small Window, ~0.03 in
            # Burst): cut relative to the typical value, not at an absolute 0.9
            fe = np.array(d["FRACEXP"], float)
            ref = np.median(fe[fe > 0]) if np.any(fe > 0) else 1.0
            bad = ~(fe >= 0.9 * ref)
            rate[bad] = np.nan; err[bad] = np.nan
            if name == "soft":
                print(f"  FRACEXP median {ref:.3f}; bins kept {100*(1-bad.mean()):.1f}%")
        bad = ~np.isfinite(rate) | ~np.isfinite(err)
        rate[bad] = np.nan; err[bad] = np.nan
        lcs[name] = (np.array(d["TIME"], float), rate, err, band)
    t = lcs["soft"][0]
    np.savez(os.path.join(out, "lightcurves.npz"), time=t, dt=dt,
             names=np.array(list(bands)), bands=np.array([lcs[n][3] for n in bands]),
             rate=np.array([lcs[n][1] for n in bands]),
             err=np.array([lcs[n][2] for n in bands]))
    print(f"  light curves: {len(bands)} bands, {len(t)} bins of {dt} s")

    # ── 5. spectra (always flare-filtered) ─────────────────────────────────
    for tag, reg in (("src", src_reg), ("bkg", bkg_reg)):
        sh(f"evselect table={evt} withspectrumset=yes spectrumset={tag}.pha energycolumn=PI "
           f"spectralbinsize=5 withspecranges=yes specchannelmin=0 specchannelmax=20479 "
           f"expression='{flt}&&{reg}{gti}'", wd, env, log)
        sh(f"backscale spectrumset={tag}.pha badpixlocation={evt}", wd, env, log)
    sh("rmfgen spectrumset=src.pha rmfset=src.rmf", wd, env, log)
    sh(f"arfgen spectrumset=src.pha arfset=src.arf withrmfset=yes rmfset=src.rmf "
       f"badpixlocation={evt} detmaptype=psf", wd, env, log)
    sh(f"specgroup spectrumset=src.pha mincounts={src['min_counts']} oversample=3 "
       f"rmfset=src.rmf arfset=src.arf backgndset=bkg.pha groupedset=src_grp.pha",
       wd, env, log)
    for f in ("src_grp.pha", "src.pha", "bkg.pha", "src.rmf", "src.arf"):
        shutil.copy(os.path.join(wd, f), os.path.join(out, "spec", f))
    print(f"  spectra -> data/{key}/spec/")


if __name__ == "__main__":
    cfg = C.load()
    keys = list(cfg) if (len(sys.argv) < 2 or sys.argv[1] == "all") else sys.argv[1:]
    for k in keys:
        print(f"\n=== {k} ({cfg[k]['obsid']}) ===")
        try:
            process(cfg[k])
        except Exception as e:                       # continue with the other sources
            print(f"  ERROR {k}: {e}")
