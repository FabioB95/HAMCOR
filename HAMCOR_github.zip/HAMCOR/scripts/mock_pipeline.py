"""
mock_pipeline.py — end-to-end dry run without SAS/XSPEC.

Simulates Mrk 335-like light curves (soft, hard and 16 lag-energy channels) from a
known corona through the HAMCOR forward model (red-noise continuum, Poisson noise),
writes fake spectral/header products, then runs s02, s06, s07, s08 and s09 on them
in a scratch work directory. Use it to check the installation before the real run.

Usage:  python scripts/mock_pipeline.py [--workdir /tmp/hamcor_mock]
"""
import argparse
import os
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
ap = argparse.ArgumentParser()
ap.add_argument("--workdir", default=os.path.join(HERE, "..", "_mock"))
ap.add_argument("--key", default="mrk335_2006")
args = ap.parse_args()
os.environ["HAMCOR_WORK"] = os.path.abspath(args.workdir)

from hamcor2 import config as C, build_grid, build_disc_grid, ForwardModel   # noqa: E402
from hamcor2.forward import t_g                                               # noqa: E402
from hamcor2.synthetic import compact                                         # noqa: E402

src = C.load()[args.key]
grid, disc = build_grid(**src["grid"]), build_disc_grid(**src["disc"])
fm = ForwardModel(grid, disc, src["incl"], "weakfield")   # dry run: fast metric
w_true = compact(grid, height=3.0, width=2.0)
tg = t_g(src["M_bh"])
rng = np.random.default_rng(42)

dt, N = src["dt"], 2 ** 12 * 4                        # 1.6 Ms: well-sampled mock
f = np.fft.rfftfreq(N, dt)
amp = np.zeros_like(f); amp[1:] = 1 / np.sqrt(f[1:] * (1 + f[1:] / 1e-4))
c = np.fft.irfft(amp * np.exp(2j * np.pi * rng.random(f.size)), N)
c = 1 + 0.3 * c / c.std()
pt = np.zeros(f.size, complex); pt[0] = 1
pt[1:] = fm.psi_tilde(w_true, f[1:] * tg)
C_f = np.fft.rfft(c)

eb = np.array(src["lag_energy_bins"]); Ec = 0.5 * (eb[1:] + eb[:-1])
R_E = 0.15 + 0.9 * np.exp(-Ec / 0.6) + 0.35 * np.exp(-0.5 * ((Ec - 6.4) / 0.6) ** 2)
cnt_E = 6.0 * Ec ** -1.2 * np.diff(eb)                # ct/s per channel
R_s, R_h = 0.55, 0.12


def band(R, rate):
    x = np.fft.irfft(C_f * (1 + R * pt), N) / (1 + R)
    x = np.clip(x * rate, 1e-3, None)
    obs = rng.poisson(x * dt) / dt
    return obs, np.sqrt(np.maximum(x, 1e-3) / dt)

names, bands, rates, errs = ["soft", "hard"], [src["soft_band"], src["hard_band"]], [], []
for R, r in ((R_s, 11.4), (R_h, 2.3)):
    a, e = band(R, r); rates.append(a); errs.append(e)
for i in range(len(Ec)):
    a, e = band(R_E[i], cnt_E[i]); rates.append(a); errs.append(e)
    names.append(f"E{i:02d}"); bands.append([eb[i], eb[i + 1]])
dd = C.data_dir(args.key)
np.savez(os.path.join(dd, "lightcurves.npz"), time=np.arange(N) * dt, dt=dt,
         names=np.array(names), bands=np.array(bands), rate=np.array(rates), err=np.array(errs))
I_true = fm.illumination(w_true)
cont_E, refl_E = cnt_E / (1 + R_E), cnt_E * R_E / (1 + R_E)    # cnt_E = total rate
R_ref = (refl_E.sum() - refl_E) / (cont_E.sum() - cont_E)
C.dump_json(dict(key=args.key, model="mock", chi2=1.0, dof=1, refl_frac=I_true / (1 - I_true),
                 refl_frac_err=[0.8 * I_true / (1 - I_true), 1.2 * I_true / (1 - I_true)],
                 I_relxill=I_true, sig_I_stat=0.03, pexrav_R=2 * I_true, I_pexrav=I_true,
                 I_obs=I_true, sig_I=0.05, R_s=R_s, R_h=R_h,
                 D=R_s / (1 + R_s) - R_h / (1 + R_h), sig_D_frac=0.1,
                 R_E=R_E, R_ref=R_ref), os.path.join(dd, "spectral.json"))
C.dump_json(dict(header={"OBJECT": "MOCK", "DATE-OBS": "2000-01-01", "SUBMODE": "PrimeFullWindow",
                         "TSTART": 0.0, "TSTOP": N * dt}, timing=False),
            os.path.join(dd, "header.json"))
print(f"mock truth: R_c={w_true @ grid.R:.2f} z_c={w_true @ grid.z:.2f}  "
      f"<t>={fm.mean_lag(w_true):.2f} r_g/c  I={I_true:.3f}")

py = sys.executable
for cmd in ([py, f"{HERE}/s02_lagfreq.py", args.key],
            [py, f"{HERE}/s06_fit_sources.py", args.key, "--boot", "4", "--starts", "4"],
            [py, f"{HERE}/s07_lamppost.py", args.key],
            [py, f"{HERE}/s08_lag_energy.py", args.key],
            [py, f"{HERE}/s09_tables.py"]):
    print("\n$", " ".join(os.path.basename(x) for x in cmd))
    r = subprocess.run(cmd, env=os.environ)
    if r.returncode:
        sys.exit(f"FAILED: {cmd[1]}")
print("\nMOCK PIPELINE OK  (outputs in", os.environ["HAMCOR_WORK"], ")")
