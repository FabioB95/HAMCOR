"""
s02_lagfreq.py — lag-frequency spectra (soft vs hard), band-averaged reverberation
lag and lag-energy spectrum in the reverberation band.

Input : data/<key>/lightcurves.npz           (s01)
Output: data/<key>/lagfreq.json
        results/figures/<key>/lagfreq.dat, lagfreq_coh.dat, lagenergy.dat, lagfreq.tex
Usage : python scripts/s02_lagfreq.py all
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import config as C, timing, pgf


def fill_short_gaps(rate, err, max_gap):
    """Linear interpolation over gaps of <= max_gap bins (common to all bands).

    Gaps are bins with FRACEXP < 0.9 or outside the flare GTI (NaN in s01).  Only gaps
    bracketed by valid bins are filled; errors are the mean of the bracketing errors.
    Returns filled copies and the fraction of bins filled."""
    rate, err = rate.copy(), err.copy()
    bad = ~np.all(np.isfinite(rate) & np.isfinite(err), axis=0)
    n, i, nfill = bad.size, 0, 0
    while i < n:
        if not bad[i]:
            i += 1; continue
        j = i
        while j + 1 < n and bad[j + 1]:
            j += 1
        L = j - i + 1
        if i > 0 and j < n - 1 and L <= max_gap:
            w = (np.arange(1, L + 1) / (L + 1))[None, :]
            rate[:, i:j + 1] = rate[:, [i - 1]] * (1 - w) + rate[:, [j + 1]] * w
            err[:, i:j + 1] = 0.5 * (err[:, [i - 1]] + err[:, [j + 1]])
            nfill += L
        i = j + 1
    return rate, err, nfill / n


def choose_seg(t, valid, dt, seg0, f_lo):
    """Largest segment length (seg0, seg0/2, ...) maximising the exposure in complete
    segments, subject to 1/(seg dt) <= f_lo/2 (the fit band keeps >= 1 octave margin)."""
    best, seg = None, int(seg0)
    while seg >= 16 and 1.0 / (seg * dt) <= 0.5 * f_lo:
        ns = len(timing.find_segments(t, valid, dt, seg))
        if ns >= 1 and (best is None or ns * seg > best[1] * best[0]):
            best = (seg, ns)
        seg //= 2
    return best


def run(src):
    key = src["key"]
    p = os.path.join(C.data_dir(key), "lightcurves.npz")
    if not os.path.exists(p):
        print(f"  {key}: no light curves (run s01)"); return
    d = np.load(p, allow_pickle=True)
    names = list(d["names"])
    t, dt = d["time"], float(d["dt"])
    rate, err = d["rate"], d["err"]
    iS, iH = names.index("soft"), names.index("hard")
    max_gap = int(src.get("max_gap_bins", 5))
    rate, err, ffill = fill_short_gaps(rate, err, max_gap)
    valid = np.all(np.isfinite(rate), axis=0)
    if valid.mean() < 0.5:
        fr = np.isfinite(d["rate"]).mean(axis=1)
        print(f"  {key}: valid fraction per band: " +
              " ".join(f"{n}={100*v:.0f}%" for n, v in zip(names, fr)))
    ch = choose_seg(t, valid, dt, src["seg_len"], src["fit_band"][0])
    if ch is None:
        print(f"  {key}: no usable segments (valid fraction {valid.mean():.2f}); skipped")
        return
    seg = ch[0]
    if seg != int(src["seg_len"]):
        print(f"  {key}: seg_len {src['seg_len']} -> {seg} bins ({seg*dt/1e3:.1f} ks, {ch[1]} segments)")
    print(f"  {key}: gaps <= {max_gap} bins interpolated: {100*ffill:.1f}% of bins; "
          f"valid {100*valid.mean():.1f}%")
    f_min = 1.0 / (seg * dt)
    edges = np.geomspace(f_min, src["f_max"], src["n_fbins"] + 1)

    lf, _ = timing.lag_frequency(t, rate[iS], err[iS], rate[iH], err[iH], dt, seg, edges)
    lo, hi = src["fit_band"]
    # bins used in the fit: those whose centre lies in the reverberation band;
    # recomputed with edges snapped to the band so no bin straddles it
    fb_edges = np.unique(np.r_[lo, edges[(edges > lo) & (edges < hi)], hi])
    if len(fb_edges) < 3:                                   # at least 2 bins
        fb_edges = np.geomspace(lo, hi, 3)
    fit, _ = timing.lag_frequency(t, rate[iS], err[iS], rate[iH], err[iH], dt, seg, fb_edges)
    band = timing.band_lag(t, rate[iS], err[iS], rate[iH], err[iH], dt, seg, lo, hi)

    eidx = [i for i, n in enumerate(names) if n.startswith("E")]
    le = timing.lag_energy(t, rate[eidx], err[eidx], dt, seg, lo, hi)
    E_lo = np.array([d["bands"][i][0] for i in eidx]); E_hi = np.array([d["bands"][i][1] for i in eidx])

    out = dict(key=key, dt=dt, seg_len=seg, n_seg=lf.n_seg, filled_fraction=ffill, max_gap_bins=max_gap, fit_band=[lo, hi],
               full=lf.as_dict(), fit=fit.as_dict(), band=band.as_dict(),
               lag_energy=dict(E_lo=E_lo, E_hi=E_hi, lag=le["lag"], sig=le["sig"],
                               g2_raw=le["g2_raw"], f_mean=le["f_mean"],
                               freqs=le["freqs"], weights=le["weights"],
                               rate=[float(np.nanmean(rate[i])) for i in eidx]),
               mean_rate=dict(soft=float(np.nanmean(rate[iS])), hard=float(np.nanmean(rate[iH]))))
    C.dump_json(out, os.path.join(C.data_dir(key), "lagfreq.json"))

    fd = C.results_dir("figures", key)
    good = np.isfinite(lf.tau)
    pgf.write_dat(os.path.join(fd, "lagfreq.dat"), f=lf.f[good], tau=lf.tau[good],
                  sig=lf.sig_tau[good], g2=lf.g2_int[good])
    pgf.write_dat(os.path.join(fd, "lagenergy.dat"), E=0.5 * (E_lo + E_hi),
                  dE=0.5 * (E_hi - E_lo), lag=le["lag"], sig=le["sig"])
    shade = pgf.band_fill(lo, hi)
    pgf.write_tex(os.path.join(fd, "lagfreq.tex"),
                  pgf.errorbar_snippet(f"figures/{key}/lagfreq.dat", title=src["name"],
                                       pre=shade))
    b = band.tau[0], band.sig_tau[0]
    print(f"  {key}: {lf.n_seg} segments; band lag [{lo:.1e},{hi:.1e}] Hz = "
          f"{b[0]:+.1f} +/- {b[1]:.1f} s; fit bins: {len(fit.f)}")


if __name__ == "__main__":
    cfg = C.load()
    keys = list(cfg) if (len(sys.argv) < 2 or sys.argv[1] == "all") else sys.argv[1:]
    for k in keys:
        run(cfg[k])
