"""
s08_lag_energy.py — posterior-predictive check with the lag-energy spectrum.

The lag-energy spectrum in the reverberation band is NOT used in the fit. Using the
HAMCOR baseline emissivity (and, for comparison, the best lamppost) together with
the per-channel dilution factors R_E and the complementary-reference R_ref from the
spectral fit, we predict
    tau(E) = - arg[ sum_f p(f) (1 + R_ref psi~)^* (1 + R_E psi~) ] / (2 pi f_mean)
and compare with the measured tau(E) (chi2, no free parameters except a common
additive offset, which lag-energy spectra are only defined up to).

Output: results/lag_energy/<key>.json, results/figures/<key>/lagenergy_model.dat/.tex
Usage : python scripts/s08_lag_energy.py all
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import build_grid, build_disc_grid, ForwardModel, PointSourceModel, config as C, pgf
from hamcor2.io import build_obs

TWO_PI = 2 * np.pi
cfg_all = C.load()
keys = list(cfg_all) if (len(sys.argv) < 2 or sys.argv[1] == "all") else sys.argv[1:]


def offset_chi2(model, data, sig):
    wts = 1 / sig ** 2
    c = np.sum(wts * (data - model)) / np.sum(wts)
    return float(np.sum(wts * (data - model - c) ** 2)), float(c)


for key in keys:
    src = cfg_all[key]
    rp = os.path.join(C.results_dir("sources"), f"{key}.json")
    lpp = os.path.join(C.results_dir("lamppost"), f"{key}.json")
    if not (os.path.exists(rp) and os.path.exists(lpp)):
        print(f"{key}: run s06 and s07 first"); continue
    ob = build_obs(src)
    r, lpj = C.load_json(rp), C.load_json(lpp)
    grid = build_grid(**src["grid"]); disc = build_disc_grid(**src["disc"])
    fm = ForwardModel(grid, disc, src["incl"], "schwarzschild")
    w = np.array(r["baseline"]["w"])
    nu, wt = ob["le_nu"], ob["le_w"] / np.sum(ob["le_w"])
    R_E, R_ref = np.array(ob["R_E"]), np.array(ob["R_ref"])
    fbar = ob["le_f_mean_nu"]
    Zh = fm.band_cross(w, nu, wt, R_E, R_ref)
    tau_h = -np.angle(Zh) / (TWO_PI * fbar)
    lp = PointSourceModel(disc, src["incl"], "schwarzschild")
    Wl, Ll = lp.row(lpj["schwarzschild"]["h_best"])
    pt = (Wl[None] * np.exp(-1j * TWO_PI * nu[:, None] * Ll[None])).sum(1) / Wl.sum()
    Zl = ((np.conj(1 + R_ref[:, None] * pt[None]) * (1 + R_E[:, None] * pt[None])) * wt[None]).sum(1)
    tau_l = -np.angle(Zl) / (TWO_PI * fbar)
    data, sig = ob["le_lag"], ob["le_sig"]
    ok = np.isfinite(data) & np.isfinite(sig) & (sig > 0)
    ch, ch_c = offset_chi2(tau_h[ok], data[ok], sig[ok])
    cl, cl_c = offset_chi2(tau_l[ok], data[ok], sig[ok])
    c0, _ = offset_chi2(np.zeros(ok.sum()), data[ok], sig[ok])
    tg = ob["t_g"]
    E = 0.5 * (np.array(ob["le_E_lo"]) + np.array(ob["le_E_hi"]))
    fd = C.results_dir("figures", key)
    pgf.write_dat(os.path.join(fd, "lagenergy_model.dat"), E=E,
                  hamcor=(tau_h + ch_c) * tg, lamppost=(tau_l + cl_c) * tg)
    snippet = pgf.errorbar_snippet(
        f"figures/{key}/lagenergy.dat", x="E", y="lag", e="sig",
        model_dat=f"figures/{key}/lagenergy_model.dat", mx="E", my="hamcor",
        xlabel=r"Energy [keV]", ylabel=r"Lag [s]", title=src["name"],
        extra=rf"\addplot[thick, dashed, red!70!black] table[x=E, y=lamppost] "
              rf"{{figures/{key}/lagenergy_model.dat}}; \addlegendentry{{lamppost}}")
    pgf.write_tex(os.path.join(fd, "lagenergy.tex"), snippet)
    n = int(ok.sum())
    out = dict(n=n, chi2_hamcor=ch, chi2_lamppost=cl, chi2_null=c0, dof=n - 1)
    C.dump_json(out, os.path.join(C.results_dir("lag_energy"), f"{key}.json"))
    print(f"{key}: lag-energy PPC  chi2/dof  HAMCOR {ch:.1f}/{n-1}   lamppost {cl:.1f}/{n-1}"
          f"   zero-lag {c0:.1f}/{n-1}")
