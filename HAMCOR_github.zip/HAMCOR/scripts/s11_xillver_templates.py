"""
s11_xillver_templates.py — rest-frame reflection templates for energy-resolved transfer.

For each source, evaluates with command-line XSPEC (dummy response, 0.1-100 keV) the
rest-frame, reflection-only xillver spectrum (xillverCp for the high-density fits) with the
best-fitting Gamma, A_Fe, log xi (and log n_e, kT_e) of the spectral fit, and the
illuminating continuum (cutoff power law / nthcomp), both in photons cm^-2 s^-1 keV^-1.
Output: data/<key>/xillver_template.dat with columns E refl cont.
Usage : python scripts/s11_xillver_templates.py all
"""
import os
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import config as C

TCL = r"""
query yes
chatter 5
@@LMOD@@
dummyrsp 0.1 100. 3000 log
model @@MODEL@@ & /*
proc setn {nm val} {
    tclout modpar; set np $xspec_tclout
    for {set i 1} {$i <= $np} {incr i} {
        tclout pinfo $i
        if {[lindex $xspec_tclout 0] eq $nm} { newpar $i $val }
    }
}
@@PARS@@
cpd /null
setplot energy
plot model
tclout plot model x
set X $xspec_tclout
tclout plot model y
set Y $xspec_tclout
set f [open @@OUT@@ w]
puts $f "x $X"
puts $f "y $Y"
close $f
exit
"""


def pget(params, name, default):
    for k, v in params.items():
        if k.rsplit("_", 1)[0] == name:
            return v
    return default


def run(key, model, pars, out, wd):
    rd = os.environ.get("RELXILL_DIR", "")
    s = (TCL.replace("@@LMOD@@", f"lmod relxill {rd}" if rd else "")
         .replace("@@MODEL@@", model).replace("@@PARS@@", "\n".join(pars)).replace("@@OUT@@", out))
    tcl = os.path.join(wd, "tmpl.tcl")
    open(tcl, "w").write(s)
    subprocess.run(["xspec", "-", "tmpl.tcl"], cwd=wd, input="exit\n", text=True,
                   stdout=open(os.path.join(wd, "tmpl.log"), "w"), stderr=subprocess.STDOUT, timeout=600)
    d = {}
    for line in open(os.path.join(wd, out)):
        t = line.split()
        d[t[0]] = np.array(t[1:], float)
    return d["x"], d["y"]


cfg = C.load()
keys = [k for k in cfg if k != "cygx1"] if (len(sys.argv) < 2 or sys.argv[1] == "all") else sys.argv[1:]
for key in keys:
    sp = C.load_json(os.path.join(C.data_dir(key), "spectral.json"))
    p = sp["params"]
    G, Afe, xi = pget(p, "gamma", 2.2), pget(p, "Afe", 1.0), pget(p, "logxi", 2.0)
    wd = os.path.join(C.data_dir(key), "spec")
    inc = float(cfg[key]["incl"])
    dense = "relxillCp" in cfg[key]["model"]
    if dense:
        logN = pget(p, "logN", 15.0)
        refl = ("xillverCp", [f"setn gamma {G}", f"setn Afe {Afe}", f"setn logxi {xi}", f"setn logN {logN}",
                              "setn kTe 60", "setn z 0", f"setn Incl {inc}", "setn refl_frac -1"])
        cont = ("nthcomp", [f"setn Gamma {G}", "setn kT_e 60", "setn kT_bb 0.05", "setn inp_type 1",
                            "setn Redshift 0"])
    else:
        refl = ("xillver", [f"setn gamma {G}", f"setn Afe {Afe}", "setn Ecut 300", f"setn logxi {xi}",
                            "setn z 0", f"setn Incl {inc}", "setn refl_frac -1"])
        cont = ("cutoffpl", [f"setn PhoIndex {G}", "setn HighECut 300"])
    E, R = run(key, refl[0], refl[1], "tmpl_refl.txt", wd)
    E2, Cn = run(key, cont[0], cont[1], "tmpl_cont.txt", wd)
    out = os.path.join(C.data_dir(key), "xillver_template.dat")
    np.savetxt(out, np.column_stack([E, R, np.interp(E, E2, Cn)]), header="E refl cont", comments="")
    print(f"{key}: {refl[0]} Gamma={G:.2f} Afe={Afe:.2f} logxi={xi:.2f} -> {out}")
