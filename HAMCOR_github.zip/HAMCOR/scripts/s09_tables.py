"""
s09_tables.py — LaTeX tables (MNRAS style, booktabs) from the results.

Output: results/tables/*.tex
  tab_obs.tex        observations (header-verified), exposure, rates
  tab_spectral.tex   relxill / pexrav reflection fractions, I_obs, dilution
  tab_lags.tex       band lags [s] and [r_g/c]
  tab_fits.tex       HAMCOR baseline + systematics (GR, J, M, no-I) + bootstrap
  tab_lamppost.tex   lamppost vs HAMCOR (h, chi2, AIC/BIC) + lag-energy PPC
  tab_synthetic.tex  recovery metrics, GR bias, N_eff
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import config as C
from hamcor2.forward import t_g

cfg = C.load()
TD = C.results_dir("tables")


def J(path):
    return C.load_json(path) if os.path.exists(path) else None


def pm(x, lo, hi, f="{:.2f}"):
    return f"${f.format(x)}^{{+{f.format(hi - x)}}}_{{-{f.format(x - lo)}}}$"


def write(name, cols, head, rows, caption, label):
    s = [r"\begin{table*}", r"\centering", rf"\caption{{{caption}}}", rf"\label{{{label}}}",
         rf"\begin{{tabular}}{{{cols}}}", r"\toprule", head + r" \\", r"\midrule"]
    s += [" & ".join(r) + r" \\" for r in rows]
    s += [r"\bottomrule", r"\end{tabular}", r"\end{table*}"]
    with open(os.path.join(TD, name), "w") as f:
        f.write("\n".join(s) + "\n")
    print(f"  wrote results/tables/{name} ({len(rows)} rows)")


rows_obs, rows_sp, rows_lag, rows_fit, rows_lp = [], [], [], [], []
for k, s in cfg.items():
    h = J(os.path.join(C.data_dir(k), "header.json"))
    lf = J(os.path.join(C.data_dir(k), "lagfreq.json"))
    sp = J(os.path.join(C.data_dir(k), "spectral.json"))
    fr = J(os.path.join(C.results_dir("sources"), f"{k}.json"))
    lp = J(os.path.join(C.results_dir("lamppost"), f"{k}.json"))
    le = J(os.path.join(C.results_dir("lag_energy"), f"{k}.json"))
    nm = s["name"].replace("-", "$-$")
    if h:
        hd = h["header"]
        rows_obs.append([nm, s["obsid"], str(hd.get("DATE-OBS", ""))[:10],
                         str(hd.get("SUBMODE", "")).replace("_", r"\_"),
                         f"{(hd['TSTOP'] - hd['TSTART']) / 1e3:.1f}",
                         f"{lf['mean_rate']['soft']:.2f}" if lf else "--",
                         f"{lf['mean_rate']['hard']:.2f}" if lf else "--"])
    if sp:
        rows_sp.append([nm, s["obsid"], f"{sp['chi2']:.0f}/{sp['dof']}",
                        pm(sp["refl_frac"], *sp["refl_frac_err"]),
                        f"${sp['I_relxill']:.2f}$", f"${sp['I_pexrav']:.2f}$",
                        f"${sp['I_obs']:.2f}\\pm{sp['sig_I']:.2f}$",
                        f"${sp['R_s']:.2f}$", f"${sp['R_h']:.2f}$",
                        f"${sp['D']:.2f}\\pm{abs(sp['D'])*sp['sig_D_frac']:.2f}$"])
    if lf:
        tg = t_g(s["M_bh"])
        b, e = lf["band"]["tau"][0], lf["band"]["sig_tau"][0]
        fb = lf["fit_band"]
        rows_lag.append([nm, s["obsid"], f"{fb[0]*1e3:.2g}--{fb[1]*1e3:.2g}" if fb[1] < 1
                         else f"{fb[0]:.2g}--{fb[1]:.2g} Hz", f"{lf['n_seg']}",
                         f"${b:+.1f}\\pm{e:.1f}$" if abs(b) > 1e-2 else f"${b*1e3:+.2f}\\pm{e*1e3:.2f}$ ms",
                         f"${b/tg:+.2f}\\pm{e/tg:.2f}$",
                         f"${b/tg/sp['D']:+.2f}$" if sp else "--"])
    if fr:
        bl = fr["baseline"]
        bs = fr.get("bootstrap")
        Rc = pm(bs["R_c"]["median"], bs["R_c"]["p16"], bs["R_c"]["p84"]) if bs else f"{bl['R_c']:.2f}"
        zc = pm(bs["z_c"]["median"], bs["z_c"]["p16"], bs["z_c"]["p84"]) if bs else f"{bl['z_c']:.2f}"
        dsys = max(abs(fr[v]["R_c"] - bl["R_c"]) for v in ("flat", "weakfield", "J0.3", "J3", "M_lo", "M_hi"))
        dsz = max(abs(fr[v]["z_c"] - bl["z_c"]) for v in ("flat", "weakfield", "J0.3", "J3", "M_lo", "M_hi"))
        lim = fr.get("illumination_limited", False)
        ndof = bl["n_lag"] - bl.get("n_par_nuisance", 0)
        cI = bl.get("chi2_I")
        Ip = bl.get("I_pred")
        rows_fit.append([nm + (r"$^\ddagger$" if lim else ""), s["obsid"], f"{bl['chi2_lag']:.1f}/{ndof}",
                         f"{cI:.2f}" if (cI is not None and np.isfinite(cI)) else "--",
                         f"{Ip:.2f}" if Ip is not None else "--", Rc, zc,
                         f"{dsys:.2f}, {dsz:.2f}",
                         f"({fr['flat']['R_c']:.1f}, {fr['flat']['z_c']:.1f})",
                         f"{bl['mean_lag']:.1f}"])
    if lp:
        sch = lp["schwarzschild"]
        hc = lp.get("hamcor", {})
        rows_lp.append([nm, s["obsid"], pm(sch["h_best"], sch["h_lo"], sch["h_hi"], "{:.1f}")
                        + (r"$^\dagger$" if sch["pinned_at_grid_edge"] else ""),
                        f"{sch['chi2']:.1f}", f"{hc.get('chi2', np.nan):.1f}",
                        f"{hc.get('N_eff', np.nan):.1f}",
                        f"{lp['lamppost_IC']['AIC'] - hc['AIC']:+.1f}" if hc else "--",
                        f"{le['chi2_hamcor']:.1f}/{le['dof']}" if le else "--",
                        f"{le['chi2_lamppost']:.1f}/{le['dof']}" if le else "--"])

write("tab_obs.tex", "lllllcc",
      r"Source & ObsID & Date & Mode & Duration (ks) & $\langle r_s\rangle$ & $\langle r_h\rangle$",
      rows_obs, r"\textit{XMM-Newton} EPIC-pn observations. Rates are background-subtracted "
      r"(ct\,s$^{-1}$) in 0.3--1 and 1.5--4 keV.", "tab:obs")
write("tab_spectral.tex", "llcccccccc",
      r"Source & ObsID & $\chi^2/\nu$ & $R_f$ & $I_{\rm relxill}$ & $I_{\rm pexrav}$ & "
      r"$I_{\rm obs}$ & $R_s$ & $R_h$ & $\mathcal{D}$",
      rows_sp, r"Reflection fits. $R_f$: \textsc{relxill} reflection fraction; "
      r"$I=R_f/(1+R_f)$; $I_{\rm pexrav}=R/2$ (3--10 keV); $I_{\rm obs}$ error includes "
      r"$|I_{\rm relxill}-I_{\rm pexrav}|$. $R_{s,h}$: reflected/continuum count ratios; "
      r"$\mathcal{D}=R_s/(1+R_s)-R_h/(1+R_h)$.", "tab:spectral")
write("tab_lags.tex", "llccccc",
      r"Source & ObsID & Band (mHz) & $N_{\rm seg}$ & $\tau$ (s) & $\tau$ ($r_g/c$) & "
      r"$\tau/\mathcal{D}$ ($r_g/c$)",
      rows_lag, r"Soft (0.3--1 keV) minus hard (1.5--4 keV) lags in the reverberation band "
      r"(negative: soft lags). $\tau/\mathcal{D}$ is the dilution-corrected first moment of "
      r"$\psi(t)$ in the low-frequency limit.", "tab:lags")
write("tab_fits.tex", "llcccccccc",
      r"Source & ObsID & $\chi^2_{\rm lag}/\nu$ & $\chi^2_I$ & $I_{\rm pred}$ & $R_c$ ($r_g$) & "
      r"$z_c$ ($r_g$) & sys. $(\Delta R_c,\Delta z_c)$ & flat $(R_c,z_c)$ & $\langle t\rangle$",
      rows_fit, r"HAMCOR fits (exact Schwarzschild transfer, $J=1$, profiled continuum lag). "
      r"$^\ddagger$: $I_{\rm obs}$ exceeds the Schwarzschild maximum $I_{\max}=0.56$ by $>2\sigma$; "
      r"baseline from the lags only, $I_{\rm pred}$ is the illumination of that solution. Centroids: bootstrap median and "
      r"16--84 percentiles; systematic: maximum shift over flat space, weak-field Schwarzschild, "
      r"$J\in\{0.3,3\}$, $M_{\rm BH}\pm1\sigma$.", "tab:fits")
write("tab_lamppost.tex", "llccccccc",
      r"Source & ObsID & $h$ ($r_g$) & $\chi^2_{\rm LP}$ & $\chi^2_{\rm H}$ & $N_{\rm eff}$ & "
      r"$\Delta{\rm AIC}$ & PPC$_{\rm H}$ & PPC$_{\rm LP}$",
      rows_lp, r"Lamppost (LP) versus HAMCOR (H) with identical data, likelihood and "
      r"spacetime. $\Delta$AIC $=$ AIC$_{\rm LP}-$AIC$_{\rm H}$ (positive favours HAMCOR). "
      r"PPC: lag-energy $\chi^2$/dof, not used in the fit. $^\dagger$ at the scan edge.",
      "tab:lamppost")

syn = J(os.path.join(C.results_dir("synthetic"), "recovery.json"))
inf = J(os.path.join(C.results_dir("synthetic"), "information.json"))
if syn:
    rows = []
    for g, v in syn.items():
        q = lambda d, k: pm(d[k]["median"], d[k]["p16"], d[k]["p84"])
        rows.append([g, q(v["gr"], "rho_3d"), q(v["gr"], "rho_rz"), q(v["gr"], "d_centroid"),
                     q(v["gr"], "lag_err"), q(v["flat"], "d_centroid"),
                     f"{100*v['true']['shapiro_frac']:.0f}\\%",
                     f"{inf[g]['N_eff']:.1f}" if inf else "--",
                     f"{inf[g]['rho_ensemble_mean']:.2f}" if inf else "--"])
    write("tab_synthetic.tex", "lcccccccc",
          r"Geometry & $\rho_{3D}$ & $\rho_{Rz}$ & $\Delta_{\rm cen}$ ($r_g$) & "
          r"$|\Delta\tau|/\tau$ & $\Delta_{\rm cen}^{\rm flat}$ & Shapiro & $N_{\rm eff}$ & "
          r"$\rho(\bar w)$",
          rows, r"Synthetic recovery (Schwarzschild data). Medians and 16--84 percentiles over "
          r"noise realisations. $\Delta^{\rm flat}_{\rm cen}$: same data fitted in flat space. "
          r"Shapiro: $\Omega$-weighted mean of $(\tau_{\rm GR}-\tau_{\rm flat})/\tau_{\rm flat}$. "
          r"$N_{\rm eff}$: data-constrained modes; $\rho(\bar w)$: ensemble-mean correlation.",
          "tab:synthetic")
