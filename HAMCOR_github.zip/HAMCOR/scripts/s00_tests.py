"""
s00_tests.py — unit tests for hamcor2. Run first:  python scripts/s00_tests.py
All must print PASS.
"""
import os, sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from hamcor2 import build_grid, build_disc_grid, ForwardModel, Hamiltonian, project_simplex
from hamcor2.gr import (shapiro_segment, shapiro_to_infinity, observer_hat,
                        compute_lag_matrix_schwarzschild)
from hamcor2.synthetic import ring, make_observables
from hamcor2.hamiltonian import ObsTargets
from hamcor2 import timing

rng = np.random.default_rng(0)
ok = True


def check(name, cond, info=""):
    global ok
    print(f"[{'PASS' if cond else 'FAIL'}] {name} {info}")
    ok &= bool(cond)


# 1. Shapiro segment vs quadrature (monotonic + V-shaped)
def quad(a, b, n=100001):
    t = np.linspace(0, 1, n)
    p = a + t[:, None] * (b - a)
    trap = getattr(np, "trapezoid", None) or np.trapz
    return trap(2 / np.linalg.norm(p, axis=1), t) * np.linalg.norm(b - a)

err = 0
for _ in range(300):
    a = rng.normal(size=3); a *= rng.uniform(4, 30) / np.linalg.norm(a)
    b = (a * rng.uniform(1.2, 3) if rng.random() < .5 else -a) + rng.normal(scale=3, size=3)
    if np.linalg.norm(np.cross(a, b - a)) / np.linalg.norm(b - a) < 3:
        continue
    q = quad(a, b)
    err = max(err, abs(shapiro_segment(np.linalg.norm(a), np.linalg.norm(b),
                                       np.linalg.norm(b - a)) - q) / q)
check("Shapiro segment = int 2/r ds", err < 1e-6, f"max rel err {err:.1e}")

# 2. Shapiro to infinity
n = observer_hat(45.0)
x = np.array([[8., 3, 0], [4, -2, 3], [-10, 1, 0]]); r = np.linalg.norm(x, axis=1)
D = 1e8
S = shapiro_segment(r, D, np.linalg.norm(D * n - x, axis=1)) - 2 * np.log(2 * D)
check("Shapiro to infinity limit", np.max(np.abs(S - shapiro_to_infinity(x, r, n))) < 1e-5)

# 3. flat lag vs finite observer
grid = build_grid(); disc = build_disc_grid()
fm_flat = ForwardModel(grid, disc, 45.0, "flat")
o = 1e7 * n
xi, xk = grid.get_cartesian(), disc.get_cartesian()
ref = (np.linalg.norm(xk[None] - xi[:, None], axis=2) + np.linalg.norm(o - xk, axis=1)[None]
       - np.linalg.norm(o - xi, axis=1)[:, None])
check("flat lag matrix (D=1e7)", np.max(np.abs(ref - fm_flat.L)) < 2e-3)

# 4. weak-field GR: positivity & visibility (the ray-traced metric is tested in 4b)
fm = ForwardModel(grid, disc, 45.0, "weakfield")
m = fm.Xi > 0
check("GR lags causal (>0) on visible pairs", np.all(fm.L[m] > 0),
      f"; GR>flat for {np.mean(fm.L[m] > fm_flat.L[m])*100:.1f}% of pairs")
check("GR visible fraction", 0.5 < m.mean() <= 1, f"{m.mean():.3f}")

# 4b. exact ray tracing: flat limit (M=0) and Schwarzschild sanity
from hamcor2.raytrace import trace_to_disc, observer_delay
rt = trace_to_disc(np.array([0, 0, 5.0]), 20000, 6, 100, M=0.0)
an = (5 / np.hypot(6, 5) - 5 / np.hypot(100, 5)) / 2
check("ray tracing, flat limit: solid angle", abs(rt["n_hit"] / rt["n_rays"] - an) < 2e-3,
      f"{rt['n_hit']/rt['n_rays']:.4f} vs {an:.4f}")
check("ray tracing, flat limit: delays", np.max(np.abs(rt["t"] - np.hypot(rt["r"], 5))) < 1e-8)
Pt = np.array([[10., 0, 0], [0, 0, 10.], [-15., 0, 0]])
check("ray tracing, flat limit: observer delay", np.max(np.abs(observer_delay(Pt, 45, M=0.0) + Pt @ n)) < 1e-6)
rt1 = trace_to_disc(np.array([0, 0, 5.0]), 20000, 6, 100, M=1.0)
check("ray tracing, Schwarzschild: light bending raises disc illumination",
      rt1["n_hit"] > rt["n_hit"] and rt1["n_cap"] > 0,
      f"hit {rt1['n_hit']/2e4:.3f} (flat {rt['n_hit']/2e4:.3f}), captured {rt1['n_cap']/2e4:.3f}")
# causality: source behind the hole (direct ray strongly bent), every reflected ray later
Sb = np.array([-8.0, 0.0, 0.5])
rtb = trace_to_disc(Sb, 6000, 6, 100, M=1.0)
Ph = np.column_stack([rtb["r"] * np.cos(rtb["phi"]), rtb["r"] * np.sin(rtb["phi"]), 0 * rtb["r"]])
Tall = observer_delay(np.vstack([Sb, Ph[::40]]), 30.0)
Lb = rtb["t"][::40] + Tall[1:] - Tall[0]
check("ray tracing: reflected rays arrive after the direct ray (source behind the hole)",
      Lb.min() > -1e-3, f"min lag {Lb.min():.3f} r_g/c over {Lb.size} rays")
psc = np.arcsin(3 * np.sqrt(3) / 5 * np.sqrt(1 - 2 / 5))
check("ray tracing, Schwarzschild: capture cone at r = 5 (analytic)",
      abs(rt1["n_cap"] / 2e4 - (1 - np.cos(psc)) / 2) < 3e-3,
      f"{rt1['n_cap']/2e4:.4f} vs {(1-np.cos(psc))/2:.4f}")
rtf = trace_to_disc(np.array([0, 0, 300.0]), 20000, 6, 100, M=1.0)
anf = (300 / np.hypot(6, 300) - 300 / np.hypot(100, 300)) / 2
check("ray tracing, Schwarzschild: weak-field limit at h = 300", abs(rtf["n_hit"] / 2e4 / anf - 1) < 0.08,
      f"{rtf['n_hit']/2e4:.4f} vs flat {anf:.4f}")

# 5. simplex projection
v = rng.normal(size=50); p = project_simplex(v, 0)
check("simplex projection", abs(p.sum() - 1) < 1e-12 and p.min() >= 0)

# 6. low-frequency limit tau -> -D <t>
w = ring(grid)
Rs, Rh = 0.7, 0.2
nu = np.array([1e-5])
tau = fm.lag_model(w, nu, Rs, Rh)[0]
Dl = Rs / (1 + Rs) - Rh / (1 + Rh)
check("low-f limit tau = -D<t>", abs(tau + Dl * fm.mean_lag(w)) < 1e-4 * abs(tau),
      f"{tau:.4f} vs {-Dl*fm.mean_lag(w):.4f}")

# 7. gradient checks (all modes)
nus = np.geomspace(2e-3, 2e-2, 6)
obs = make_observables(fm, w, nus, noise_seed=1)
# estimator-matched model with K=1 reduces to point evaluation
from hamcor2.synthetic import estimator_grid
nb, nk, pk, bk = estimator_grid(nus, k_per_bin=1)
check("binned model, K=1 == point model",
      np.allclose(fm.lag_model_binned(w, nk, pk, bk, nb, Rs, Rh), fm.lag_model(w, nb, Rs, Rh)))
edges = np.linspace(0, 15, 41)
obs.psi_edges = edges
obs.psi_prior = np.r_[np.exp(-0.5 * ((0.5 * (edges[1:] + edges[:-1]) - 4) / 1.) ** 2), 0]
obs.psi_prior /= obs.psi_prior.sum()
w0 = project_simplex(rng.exponential(size=grid.n_cells))
for mode in ("lagfreq", "meanlag", "psi"):
    H = Hamiltonian(fm, obs, J=1.0, mode=mode)
    f0, g = H.value_and_grad(w0)
    d = rng.normal(size=w0.size); d -= d.mean(); d *= 1e-6 / np.linalg.norm(d)
    num = (H.value(w0 + d) - H.value(w0 - d)) / 2
    check(f"gradient [{mode}]", abs(num - g @ d) < 1e-5 * max(abs(num), 1e-12),
          f"num {num:.4e} an {g@d:.4e}")

# 7b. continuum-lag nuisance: gradient (envelope theorem) and recovery of an injected term
import copy as _cp
from hamcor2.hamiltonian import profile_continuum
oc = _cp.copy(obs); oc.cont_lag = True
nu0 = np.exp(np.mean(np.log(oc.nu)))
oc.tau = obs.tau + 3.0 * np.abs(obs.tau).max() * (oc.nu / nu0) ** (-1.0)
H = Hamiltonian(fm, oc, J=1.0, mode="lagfreq")
f0, g = H.value_and_grad(w0)
d = rng.normal(size=w0.size); d -= d.mean(); d *= 1e-6 / np.linalg.norm(d)
num = (H.value(w0 + d) - H.value(w0 - d)) / 2
check("gradient [lagfreq + continuum lag]", abs(num - g @ d) < 1e-4 * max(abs(num), 1e-12),
      f"num {num:.4e} an {g@d:.4e}")
A, a, _ = profile_continuum(obs.tau, oc.tau, obs.sigma_total(), oc.nu)
check("continuum lag recovered", a == 1.0 and abs(A / (3.0 * np.abs(obs.tau).max()) - 1) < 1e-6,
      f"A ratio {A / (3.0 * np.abs(obs.tau).max()):.6f}, a={a}")

# 8. lag estimator + estimator-matched model on simulated red-noise light curves
#    (bending PSD, Poisson noise, 30 s soft delay)
dt, N = 10.0, 2 ** 17
t = np.arange(N) * dt
f = np.fft.rfftfreq(N, dt); amp = np.zeros_like(f)
amp[1:] = 1 / np.sqrt(f[1:] * (1 + f[1:] / 2e-4))
pulls = []
for trial in range(6):
    c = np.fft.irfft(amp * np.exp(2j * np.pi * rng.random(f.size)), N)
    c = 50 + 8 * c / c.std()
    delay = 30.0
    c_del = np.fft.irfft(np.fft.rfft(c) * np.exp(-2j * np.pi * f * delay), N)
    s_obs = rng.poisson(c_del * dt) / dt; h_obs = rng.poisson(c * dt) / dt
    es, eh = np.sqrt(c_del / dt), np.sqrt(c / dt)
    r, _ = timing.lag_frequency(t, s_obs, es, h_obs, eh, dt, 1024, np.array([3e-4, 1e-3]))
    Z = np.sum(r.pk * np.exp(-2j * np.pi * r.fk * delay))
    pulls.append((r.tau[0] - np.angle(Z) / (2 * np.pi * r.f[0])) / r.sig_tau[0])
pulls = np.array(pulls)
check("lag estimator vs matched model (pulls)", abs(pulls.mean()) < 1.0 and pulls.std() < 2,
      f"mean pull {pulls.mean():+.2f}, std {pulls.std():.2f}")

print("\nALL PASS" if ok else "\nSOME TESTS FAILED")
sys.exit(0 if ok else 1)
